import { runApi } from "../_adapter.js";

export default async function handler(req, res) {
  return runApi(req, res, "/api/referrals/claim");
}
