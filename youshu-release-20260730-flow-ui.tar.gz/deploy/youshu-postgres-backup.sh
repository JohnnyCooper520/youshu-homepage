#!/usr/bin/env bash
set -euo pipefail

CONTAINER_NAME="${YOUSHU_POSTGRES_CONTAINER:-youshu-postgres}"
ENV_FILE="${YOUSHU_POSTGRES_ENV_FILE:-/etc/youshu/postgres.env}"
BACKUP_DIR="${YOUSHU_POSTGRES_BACKUP_DIR:-/var/backups/youshu-postgres}"
RETENTION_DAYS="${YOUSHU_POSTGRES_BACKUP_RETENTION_DAYS:-7}"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "Missing PostgreSQL environment file: $ENV_FILE" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

install -d -m 700 "$BACKUP_DIR"
timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
final_path="$BACKUP_DIR/youshu-$timestamp.dump"
temporary_path="$final_path.partial"

umask 077
docker exec "$CONTAINER_NAME" \
  pg_dump \
  --username "$POSTGRES_USER" \
  --dbname "$POSTGRES_DB" \
  --format custom \
  --compress 9 \
  --no-owner \
  --no-acl >"$temporary_path"

docker exec -i "$CONTAINER_NAME" \
  pg_restore --list <"$temporary_path" >/dev/null
mv "$temporary_path" "$final_path"
find "$BACKUP_DIR" -type f -name 'youshu-*.dump' -mtime "+$RETENTION_DAYS" -delete

echo "PostgreSQL backup completed: $final_path"
