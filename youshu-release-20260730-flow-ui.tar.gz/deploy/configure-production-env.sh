#!/usr/bin/env bash
set -euo pipefail

ENV_FILE="${YOUSHU_ENV_FILE:-/etc/youshu/youshu.env}"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "Missing environment file: $ENV_FILE" >&2
  exit 1
fi

set_env() {
  local key="$1"
  local value="$2"
  local temp_file
  temp_file="$(mktemp)"
  awk -F= -v key="$key" -v value="$value" '
    BEGIN { replaced = 0 }
    $1 == key {
      if (!replaced) {
        print key "=" value
        replaced = 1
      }
      next
    }
    { print }
    END {
      if (!replaced) {
        print key "=" value
      }
    }
  ' "$ENV_FILE" > "$temp_file"
  install -o root -g root -m 600 "$temp_file" "$ENV_FILE"
  rm -f "$temp_file"
}

configured_value() {
  local key="$1"
  awk -F= -v key="$key" '$1 == key { print substr($0, index($0, "=") + 1); exit }' "$ENV_FILE"
}

set_env NODE_ENV production
set_env HOST 0.0.0.0
set_env PORT 8788
set_env ALLOW_RUNTIME_DEEPSEEK_KEY false
set_env REQUIRE_GENERATION_AUTH true
set_env ALIPAY_APP_ID 2021006178698341
set_env ALIPAY_APP_PRIVATE_KEY ""
set_env ALIPAY_APP_PRIVATE_KEY_FILE /run/secrets/alipay/app-private-key.pem
set_env ALIPAY_PUBLIC_KEY ""
set_env ALIPAY_PUBLIC_KEY_FILE /run/secrets/alipay/alipay-public-key.txt
set_env ALIPAY_SELLER_ID 2088780845332042
set_env ALIPAY_GATEWAY_URL https://openapi.alipay.com/gateway.do
set_env PUBLIC_SITE_URL https://dongfangyoushu.com.cn

admin_token="$(configured_value PAYMENT_ADMIN_TOKEN)"
if [[ ${#admin_token} -lt 32 || "$admin_token" == replace-* ]]; then
  set_env PAYMENT_ADMIN_TOKEN "$(openssl rand -hex 32)"
fi

for required_key in DEEPSEEK_API_KEY SUPABASE_URL SUPABASE_SERVICE_ROLE_KEY; do
  value="$(configured_value "$required_key")"
  if [[ -n "$value" && "$value" != replace-* ]]; then
    echo "OK $required_key"
  else
    echo "MISSING $required_key"
  fi
done

echo "Alipay identifiers, key-file paths, callback URL, and payment admin token are configured."
