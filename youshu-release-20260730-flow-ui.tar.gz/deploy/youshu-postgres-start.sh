#!/usr/bin/env bash
set -euo pipefail

CONTAINER_NAME="${YOUSHU_POSTGRES_CONTAINER:-youshu-postgres}"
IMAGE="${YOUSHU_POSTGRES_IMAGE:-postgres:16-alpine}"
ENV_FILE="${YOUSHU_POSTGRES_ENV_FILE:-/etc/youshu/postgres.env}"
NETWORK_NAME="${YOUSHU_NETWORK_NAME:-youshu-private}"
VOLUME_NAME="${YOUSHU_POSTGRES_VOLUME:-youshu-postgres-data}"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "Missing PostgreSQL environment file: $ENV_FILE" >&2
  exit 1
fi

docker network inspect "$NETWORK_NAME" >/dev/null 2>&1 \
  || docker network create "$NETWORK_NAME" >/dev/null
docker volume inspect "$VOLUME_NAME" >/dev/null 2>&1 \
  || docker volume create "$VOLUME_NAME" >/dev/null

docker pull "$IMAGE" >/dev/null
docker rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true
docker run -d \
  --name "$CONTAINER_NAME" \
  --restart unless-stopped \
  --env-file "$ENV_FILE" \
  --network "$NETWORK_NAME" \
  --memory 384m \
  --memory-swap 768m \
  --shm-size 64m \
  --log-opt max-size=20m \
  --log-opt max-file=3 \
  --mount "type=volume,src=$VOLUME_NAME,dst=/var/lib/postgresql/data" \
  --health-cmd='pg_isready -U "$POSTGRES_USER" -d "$POSTGRES_DB"' \
  --health-interval=10s \
  --health-timeout=5s \
  --health-retries=10 \
  "$IMAGE" \
  -c shared_buffers=96MB \
  -c effective_cache_size=256MB \
  -c maintenance_work_mem=32MB \
  -c work_mem=4MB \
  -c max_connections=40 >/dev/null

for _ in {1..60}; do
  status="$(docker inspect --format '{{.State.Health.Status}}' "$CONTAINER_NAME")"
  if [[ "$status" == "healthy" ]]; then
    echo "$CONTAINER_NAME is healthy"
    exit 0
  fi
  if [[ "$status" == "unhealthy" ]]; then
    break
  fi
  sleep 1
done

echo "$CONTAINER_NAME failed its health check" >&2
docker logs --tail 100 "$CONTAINER_NAME" >&2
exit 1
