#!/usr/bin/env bash
set -euo pipefail

ENV_FILE="${YOUSHU_ENV_FILE:-/etc/youshu/youshu.env}"

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Run this command as root." >&2
  exit 1
fi

if [[ ! -f "$ENV_FILE" ]]; then
  echo "Missing environment file: $ENV_FILE" >&2
  exit 1
fi

set_env() {
  local key="$1"
  local value="$2"
  local temp_file
  temp_file="$(mktemp)"
  awk -F= -v key="$key" -v value="$value" '
    BEGIN { replaced = 0 }
    $1 == key {
      if (!replaced) {
        print key "=" value
        replaced = 1
      }
      next
    }
    { print }
    END {
      if (!replaced) {
        print key "=" value
      }
    }
  ' "$ENV_FILE" > "$temp_file"
  install -o root -g root -m 600 "$temp_file" "$ENV_FILE"
  rm -f "$temp_file"
}

read -r -s -p "Alibaba Cloud RAM AccessKey ID: " access_key_id
printf "\n"
if [[ ${#access_key_id} -lt 16 || "$access_key_id" =~ [^A-Za-z0-9] ]]; then
  echo "AccessKey ID looks incomplete." >&2
  exit 1
fi

read -r -s -p "Alibaba Cloud RAM AccessKey Secret: " access_key_secret
printf "\n"
if [[ ${#access_key_secret} -lt 20 || "$access_key_secret" =~ [[:space:]] ]]; then
  echo "AccessKey Secret looks incomplete." >&2
  exit 1
fi

set_env ALIBABA_CLOUD_ACCESS_KEY_ID "$access_key_id"
set_env ALIBABA_CLOUD_ACCESS_KEY_SECRET "$access_key_secret"
set_env ALIYUN_SMS_SIGN_NAME "北京一叶泛舟文化科技"
set_env ALIYUN_SMS_TEMPLATE_CODE "SMS_510940173"

unset access_key_id access_key_secret
echo "SMS credentials, approved signature, and template code were saved with mode 600."
echo "No secret value was printed. Restart the application only after the SMS preflight passes."
