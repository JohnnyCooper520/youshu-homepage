#!/usr/bin/env bash
set -euo pipefail

ENV_FILE="${YOUSHU_ENV_FILE:-/etc/youshu/youshu.env}"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "Missing environment file: $ENV_FILE" >&2
  exit 1
fi

set_env() {
  local key="$1"
  local value="$2"
  local temp_file
  temp_file="$(mktemp)"
  awk -F= -v key="$key" -v value="$value" '
    BEGIN { replaced = 0 }
    $1 == key {
      if (!replaced) {
        print key "=" value
        replaced = 1
      }
      next
    }
    { print }
    END {
      if (!replaced) {
        print key "=" value
      }
    }
  ' "$ENV_FILE" > "$temp_file"
  install -o root -g root -m 600 "$temp_file" "$ENV_FILE"
  rm -f "$temp_file"
}

read -r -s -p "DeepSeek API key: " deepseek_key
printf "\n"
if [[ ${#deepseek_key} -lt 20 ]]; then
  echo "DeepSeek API key looks incomplete." >&2
  exit 1
fi

read -r -s -p "Supabase service role/secret key: " supabase_service_key
printf "\n"
if [[ ${#supabase_service_key} -lt 30 ]]; then
  echo "Supabase service role/secret key looks incomplete." >&2
  exit 1
fi

set_env DEEPSEEK_API_KEY "$deepseek_key"
set_env SUPABASE_SERVICE_ROLE_KEY "$supabase_service_key"
set_env MOCK_REPORTS false
set_env REQUIRE_GENERATION_AUTH true

unset deepseek_key supabase_service_key
echo "Production secrets saved with mode 600. Real report mode is enabled for the next container restart."
