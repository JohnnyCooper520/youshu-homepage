#!/usr/bin/env bash
set -euo pipefail

CONTAINER_NAME="${CONTAINER_NAME:-youshu-domestic}"
IMAGE="${YOUSHU_IMAGE:-youshu-domestic:current}"
ENV_FILE="${YOUSHU_ENV_FILE:-/etc/youshu/youshu.env}"
DATABASE_ENV_FILE="${YOUSHU_DATABASE_ENV_FILE:-/etc/youshu/database.env}"
ALIPAY_KEY_DIR="${YOUSHU_ALIPAY_KEY_DIR:-/etc/youshu/alipay}"
NETWORK_NAME="${YOUSHU_NETWORK_NAME:-youshu-private}"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "Missing environment file: $ENV_FILE" >&2
  exit 1
fi

docker network inspect "$NETWORK_NAME" >/dev/null 2>&1 \
  || docker network create "$NETWORK_NAME" >/dev/null

docker_args=(
  -d
  --name "$CONTAINER_NAME"
  --restart unless-stopped
  --env-file "$ENV_FILE"
  --network "$NETWORK_NAME"
  -p 127.0.0.1:8788:8788
)

if [[ -f "$DATABASE_ENV_FILE" ]]; then
  docker_args+=(--env-file "$DATABASE_ENV_FILE")
fi

if [[ -d "$ALIPAY_KEY_DIR" ]]; then
  docker_args+=(--mount "type=bind,src=$ALIPAY_KEY_DIR,dst=/run/secrets/alipay,readonly")
fi

docker rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true
docker run "${docker_args[@]}" "$IMAGE" >/dev/null

for _ in {1..30}; do
  if curl -fsS http://127.0.0.1:8788/healthz >/dev/null; then
    echo "$CONTAINER_NAME is healthy"
    exit 0
  fi
  sleep 1
done

echo "$CONTAINER_NAME failed its health check" >&2
docker logs --tail 80 "$CONTAINER_NAME" >&2 || true
exit 1
