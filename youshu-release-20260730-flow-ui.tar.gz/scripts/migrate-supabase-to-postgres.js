import { chmod, mkdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import pg from "pg";

const { Pool } = pg;

const TABLES = [
  "reports",
  "report_feedback",
  "user_entitlements",
  "payment_orders",
  "referral_codes",
  "referral_claims",
  "report_generation_reservations",
];

const TABLE_COLUMNS = {
  reports: [
    "id", "user_id", "report_key", "report_type", "title", "report_payload",
    "created_at", "updated_at",
  ],
  report_feedback: [
    "id", "user_id", "report_key", "report_type", "prompt_version", "rating",
    "reason_tags", "comment", "created_at", "updated_at",
  ],
  user_entitlements: [
    "id", "user_id", "product_key", "status", "included_quantity",
    "used_quantity", "starts_at", "expires_at", "source", "order_id",
    "metadata", "created_at", "updated_at",
  ],
  payment_orders: [
    "id", "order_no", "client_request_id", "user_id", "product_key", "subject",
    "amount", "currency", "status", "provider", "provider_trade_id", "paid_at",
    "refund_status", "refunded_amount", "raw_payment", "raw_refund",
    "created_at", "updated_at",
  ],
  referral_codes: ["id", "user_id", "code", "created_at"],
  referral_claims: [
    "id", "code_id", "referrer_user_id", "invitee_user_id", "created_at",
  ],
  report_generation_reservations: [
    "id", "request_id", "user_id", "entitlement_id", "product_key", "status",
    "response", "created_at", "updated_at", "completed_at", "released_at",
  ],
};

function requiredEnv(name) {
  const value = String(process.env[name] || "").trim();
  if (!value) {
    throw new Error(`${name} is required`);
  }
  return value;
}

function sourceHeaders(serviceKey, extra = {}) {
  return {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    ...extra,
  };
}

async function sourceJson(url, serviceKey, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: sourceHeaders(serviceKey, options.headers),
  });
  const text = await response.text();
  let body;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = text;
  }
  if (!response.ok) {
    const detail = body?.message || body?.msg || String(body || response.statusText);
    throw Object.assign(
      new Error(`Source request failed (${response.status}): ${detail}`),
      { status: response.status },
    );
  }
  return body;
}

async function exportUsers(baseUrl, serviceKey) {
  const users = [];
  for (let page = 1; ; page += 1) {
    const body = await sourceJson(
      `${baseUrl}/auth/v1/admin/users?page=${page}&per_page=1000`,
      serviceKey,
    );
    const rows = Array.isArray(body) ? body : body?.users || [];
    users.push(...rows);
    if (rows.length < 1000) {
      return users;
    }
  }
}

async function createUserAccessToken(baseUrl, serviceKey, user) {
  const link = await sourceJson(
    `${baseUrl}/auth/v1/admin/generate_link`,
    serviceKey,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "magiclink", email: user.email }),
    },
  );
  const tokenHash = link?.properties?.hashed_token || link?.hashed_token;
  if (!tokenHash) {
    throw new Error(`Unable to create a scoped migration session for ${user.id}`);
  }
  const session = await sourceJson(
    `${baseUrl}/auth/v1/verify`,
    serviceKey,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "magiclink", token_hash: tokenHash }),
    },
  );
  if (!session?.access_token) {
    throw new Error(`Unable to verify a scoped migration session for ${user.id}`);
  }
  return session.access_token;
}

async function exportUserScopedTable(baseUrl, serviceKey, table, users) {
  const rows = [];
  for (const user of users) {
    if (!user.email) {
      throw new Error(`Cannot export ${table} for user ${user.id} without an email`);
    }
    const accessToken = await createUserAccessToken(baseUrl, serviceKey, user);
    const page = await sourceJson(
      `${baseUrl}/rest/v1/${table}?select=*&user_id=eq.${encodeURIComponent(user.id)}&order=created_at.asc`,
      serviceKey,
      { headers: { Authorization: `Bearer ${accessToken}` } },
    );
    rows.push(...page);
    await sourceJson(
      `${baseUrl}/auth/v1/logout`,
      serviceKey,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${accessToken}` },
      },
    ).catch(() => {});
  }
  return rows;
}

async function exportTable(baseUrl, serviceKey, table, users) {
  const rows = [];
  const pageSize = 1000;
  try {
    for (let offset = 0; ; offset += pageSize) {
      const page = await sourceJson(
        `${baseUrl}/rest/v1/${table}?select=*&order=created_at.asc&offset=${offset}&limit=${pageSize}`,
        serviceKey,
      );
      rows.push(...page);
      if (page.length < pageSize) {
        return rows;
      }
    }
  } catch (error) {
    if (![401, 403].includes(error.status)) {
      throw error;
    }
    return exportUserScopedTable(baseUrl, serviceKey, table, users);
  }
}

function postgresSsl() {
  if (process.env.DATABASE_SSL === "false") {
    return false;
  }
  return {
    rejectUnauthorized: process.env.DATABASE_SSL_REJECT_UNAUTHORIZED !== "false",
  };
}

async function upsertUsers(client, users) {
  for (const user of users) {
    const email = String(user.email || "").trim().toLowerCase();
    if (!email) {
      throw new Error(`Source user ${user.id} has no email and needs manual migration`);
    }
    await client.query(
      `insert into auth.users
        (id, email, email_normalized, email_confirmed_at, created_at, updated_at)
       values ($1, $2, $2, $3, $4, $5)
       on conflict (id) do update
       set email = excluded.email,
           email_normalized = excluded.email_normalized,
           email_confirmed_at = excluded.email_confirmed_at,
           updated_at = excluded.updated_at`,
      [
        user.id,
        email,
        user.email_confirmed_at || user.confirmed_at || null,
        user.created_at,
        user.updated_at || user.created_at,
      ],
    );
  }
}

async function upsertRows(client, table, rows) {
  const columns = TABLE_COLUMNS[table];
  const quoted = columns.map((column) => `"${column}"`);
  const placeholders = columns.map((_, index) => `$${index + 1}`);
  const updates = columns
    .filter((column) => column !== "id")
    .map((column) => `"${column}" = excluded."${column}"`);
  const sql = `insert into public."${table}" (${quoted.join(", ")})
    values (${placeholders.join(", ")})
    on conflict (id) do update set ${updates.join(", ")}`;
  for (const row of rows) {
    await client.query(sql, columns.map((column) => row[column] ?? null));
  }
}

async function verifyCounts(client, backup) {
  const counts = {};
  const users = await client.query("select count(*)::int as count from auth.users");
  counts.users = users.rows[0].count;
  for (const table of TABLES) {
    const result = await client.query(`select count(*)::int as count from public."${table}"`);
    counts[table] = result.rows[0].count;
  }
  const expected = {
    users: backup.users.length,
    ...Object.fromEntries(TABLES.map((table) => [table, backup.tables[table].length])),
  };
  const mismatches = Object.entries(expected)
    .filter(([name, count]) => counts[name] < count)
    .map(([name, count]) => `${name}: expected at least ${count}, got ${counts[name]}`);
  if (mismatches.length) {
    throw new Error(`Migration verification failed: ${mismatches.join("; ")}`);
  }
  return counts;
}

async function main() {
  const sourceUrl = requiredEnv("SUPABASE_URL").replace(/\/+$/, "");
  const sourceKey = requiredEnv("SUPABASE_SERVICE_ROLE_KEY");
  const databaseUrl = requiredEnv("DATABASE_URL");
  const backupPath = resolve(
    process.env.MIGRATION_BACKUP_PATH
      || `artifacts/migration/supabase-backup-${new Date().toISOString().replace(/[:.]/g, "-")}.json`,
  );

  const backup = {
    format: "youshu-supabase-export-v1",
    exportedAt: new Date().toISOString(),
    users: await exportUsers(sourceUrl, sourceKey),
    tables: {},
  };
  for (const table of TABLES) {
    backup.tables[table] = await exportTable(
      sourceUrl,
      sourceKey,
      table,
      backup.users,
    );
  }

  await mkdir(dirname(backupPath), { recursive: true });
  await writeFile(backupPath, `${JSON.stringify(backup, null, 2)}\n`, { mode: 0o600 });
  await chmod(backupPath, 0o600);

  const pool = new Pool({
    connectionString: databaseUrl,
    ssl: postgresSsl(),
    max: 2,
    connectionTimeoutMillis: 10_000,
    statement_timeout: 30_000,
    application_name: "youshu-migration",
  });
  const client = await pool.connect();
  try {
    await client.query("begin");
    await upsertUsers(client, backup.users);
    for (const table of TABLES) {
      await upsertRows(client, table, backup.tables[table]);
    }
    await client.query("commit");
    const counts = await verifyCounts(client, backup);
    console.log(JSON.stringify({
      ok: true,
      backupPath,
      imported: counts,
    }, null, 2));
  } catch (error) {
    await client.query("rollback").catch(() => {});
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((error) => {
  console.error(`Migration failed: ${error.message}`);
  process.exitCode = 1;
});
