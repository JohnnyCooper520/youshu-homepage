import { createPrivateKey, createPublicKey } from "node:crypto";
import { readFile } from "node:fs/promises";
import { signAlipayFields, verifyAlipaySignature } from "../server/alipay.js";

async function loadSecret(value, filePath) {
  if (value) {
    return String(value).replace(/\\n/g, "\n");
  }
  if (filePath) {
    return readFile(filePath, "utf8");
  }
  return "";
}

function normalizePublicKey(value) {
  const normalized = String(value || "").trim().replace(/\\n/g, "\n");
  if (!normalized || normalized.includes("BEGIN PUBLIC KEY")) {
    return normalized;
  }
  return `-----BEGIN PUBLIC KEY-----\n${normalized.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
}

function status(label, ok, detail) {
  console.log(`${ok ? "OK" : "MISSING"}  ${label}${detail ? ` — ${detail}` : ""}`);
  return ok;
}

const privateKey = await loadSecret(
  process.env.ALIPAY_APP_PRIVATE_KEY,
  process.env.ALIPAY_APP_PRIVATE_KEY_FILE,
);
const platformPublicKey = normalizePublicKey(await loadSecret(
  process.env.ALIPAY_PUBLIC_KEY,
  process.env.ALIPAY_PUBLIC_KEY_FILE,
));
const appId = String(process.env.ALIPAY_APP_ID || "").trim();
const sellerId = String(process.env.ALIPAY_SELLER_ID || "").trim();
const publicSiteUrl = String(process.env.PUBLIC_SITE_URL || "").replace(/\/+$/, "");
const checks = [];

checks.push(status("ALIPAY_APP_ID", /^\d{16}$/.test(appId), appId ? "format checked" : ""));
checks.push(status("ALIPAY_SELLER_ID", /^\d{16}$/.test(sellerId), sellerId ? "format checked" : ""));
checks.push(status(
  "PUBLIC_SITE_URL",
  /^https:\/\/[^/]+/i.test(publicSiteUrl),
  publicSiteUrl || "",
));

let privateKeyValid = false;
if (privateKey) {
  try {
    createPrivateKey(privateKey);
    privateKeyValid = true;
  } catch {
    privateKeyValid = false;
  }
}
checks.push(status("ALIPAY_APP_PRIVATE_KEY", privateKeyValid, privateKey ? "RSA key parsed" : ""));

let platformKeyValid = false;
if (platformPublicKey) {
  try {
    createPublicKey(platformPublicKey);
    platformKeyValid = true;
  } catch {
    platformKeyValid = false;
  }
}
checks.push(status("ALIPAY_PUBLIC_KEY", platformKeyValid, platformPublicKey ? "RSA key parsed" : ""));

if (privateKeyValid) {
  const appPublicKey = createPublicKey(privateKey).export({ type: "spki", format: "pem" });
  const fields = {
    app_id: appId || "0000000000000000",
    method: "alipay.trade.page.pay",
    charset: "utf-8",
    sign_type: "RSA2",
    timestamp: "2026-07-28 12:00:00",
    version: "1.0",
    biz_content: '{"out_trade_no":"PREFLIGHT","total_amount":"0.01"}',
  };
  const signed = { ...fields, sign: signAlipayFields(fields, privateKey) };
  checks.push(status("RSA2 sign/verify", verifyAlipaySignature(signed, appPublicKey)));
}

checks.push(status(
  "SUPABASE service credentials",
  Boolean(
    (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL)
    && (process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SERVICE_KEY)
  ),
));
checks.push(status("PAYMENT_ADMIN_TOKEN", String(process.env.PAYMENT_ADMIN_TOKEN || "").length >= 32));

if (checks.every(Boolean)) {
  console.log("Alipay production configuration preflight passed.");
} else {
  console.error("Alipay production configuration is incomplete. No secret values were printed.");
  process.exitCode = 1;
}
