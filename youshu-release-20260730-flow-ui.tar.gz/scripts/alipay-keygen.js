import {
  createHash,
  createSign,
  createVerify,
  generateKeyPairSync,
} from "node:crypto";
import { chmod, mkdir, readFile, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

function parseOutputDir(argv) {
  const outputIndex = argv.indexOf("--output");
  if (outputIndex >= 0 && argv[outputIndex + 1]) {
    return path.resolve(argv[outputIndex + 1]);
  }
  return path.join(os.homedir(), ".config", "youshu", "alipay");
}

function publicKeyBody(publicKey) {
  return publicKey
    .replace(/-----BEGIN PUBLIC KEY-----|-----END PUBLIC KEY-----/g, "")
    .replace(/\s+/g, "");
}

const outputDir = parseOutputDir(process.argv.slice(2));
const privateKeyPath = path.join(outputDir, "app-private-key.pem");
const publicKeyPath = path.join(outputDir, "app-public-key.pem");
const alipayPublicKeyPath = path.join(outputDir, "app-public-key.alipay.txt");

await mkdir(outputDir, { recursive: true, mode: 0o700 });

try {
  await readFile(privateKeyPath);
  throw new Error(`Refusing to overwrite an existing private key: ${privateKeyPath}`);
} catch (error) {
  if (error.code !== "ENOENT") {
    throw error;
  }
}

const { privateKey, publicKey } = generateKeyPairSync("rsa", {
  modulusLength: 2048,
  publicExponent: 0x10001,
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
  publicKeyEncoding: { type: "spki", format: "pem" },
});

const selfTestPayload = "youshu-alipay-rsa2-key-self-test";
const signer = createSign("RSA-SHA256");
signer.update(selfTestPayload, "utf8");
signer.end();
const signature = signer.sign(privateKey);
const verifier = createVerify("RSA-SHA256");
verifier.update(selfTestPayload, "utf8");
verifier.end();
if (!verifier.verify(publicKey, signature)) {
  throw new Error("Generated RSA2 key pair failed its local sign/verify self-test.");
}

await writeFile(privateKeyPath, privateKey, { encoding: "utf8", mode: 0o600, flag: "wx" });
await writeFile(publicKeyPath, publicKey, { encoding: "utf8", mode: 0o644, flag: "wx" });
await writeFile(alipayPublicKeyPath, `${publicKeyBody(publicKey)}\n`, { encoding: "utf8", mode: 0o644, flag: "wx" });
await chmod(outputDir, 0o700);
await chmod(privateKeyPath, 0o600);

const fingerprint = createHash("sha256").update(publicKey).digest("hex").match(/.{1,4}/g).join(":");

console.log("Alipay RSA2 application key pair generated.");
console.log(`Private key (keep secret): ${privateKeyPath}`);
console.log(`Public key (PEM): ${publicKeyPath}`);
console.log(`Public key for Alipay console: ${alipayPublicKeyPath}`);
console.log(`Public-key SHA-256 fingerprint: ${fingerprint}`);
console.log("Local RSA2 sign/verify self-test: passed");
