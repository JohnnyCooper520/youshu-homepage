import { readFile } from "node:fs/promises";
import pg from "pg";

const { Pool } = pg;

function requiredEnv(name) {
  const value = String(process.env[name] || "").trim();
  if (!value) {
    throw new Error(`${name} is required`);
  }
  return value;
}

function postgresSsl() {
  if (process.env.DATABASE_SSL === "false") {
    return false;
  }
  return {
    rejectUnauthorized: process.env.DATABASE_SSL_REJECT_UNAUTHORIZED !== "false",
  };
}

async function main() {
  const pool = new Pool({
    connectionString: requiredEnv("DATABASE_URL"),
    ssl: postgresSsl(),
    max: 1,
    connectionTimeoutMillis: 10_000,
    statement_timeout: 60_000,
    application_name: "youshu-schema-init",
  });
  const bootstrap = await readFile(
    new URL("../docs/domestic-postgres-bootstrap.sql", import.meta.url),
    "utf8",
  );
  const applicationSchema = await readFile(
    new URL("../docs/supabase-schema.sql", import.meta.url),
    "utf8",
  );

  try {
    await pool.query(bootstrap);
    await pool.query(applicationSchema);
    const result = await pool.query(
      `select
         to_regclass('auth.users') is not null as auth_users,
         to_regclass('public.reports') is not null as reports,
         to_regclass('public.payment_orders') is not null as payment_orders,
         to_regprocedure('public.reserve_report_entitlement(uuid,text,text)') is not null
           as reserve_report_entitlement`,
    );
    const checks = result.rows[0];
    if (Object.values(checks).some((value) => value !== true)) {
      throw new Error(`Schema verification failed: ${JSON.stringify(checks)}`);
    }
    console.log(JSON.stringify({ ok: true, checks }, null, 2));
  } finally {
    await pool.end();
  }
}

main().catch((error) => {
  console.error(`Database initialization failed: ${error.message}`);
  process.exitCode = 1;
});
