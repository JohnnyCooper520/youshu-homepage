-- Run this file first on an Alibaba Cloud RDS PostgreSQL database.
-- Then run docs/supabase-schema.sql on the same database.
--
-- The compatibility roles/functions let the existing schema install cleanly.
-- The application never exposes PostgreSQL directly to browsers; all access
-- goes through the authenticated Node API.
--
-- Important: the Node API must connect as the database owner. RLS remains in
-- place for schema compatibility, while the owner performs all trusted access.

create extension if not exists pgcrypto;

do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'anon') then
    create role anon nologin;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'authenticated') then
    create role authenticated nologin;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'service_role') then
    create role service_role nologin;
  end if;
end
$$;

create schema if not exists auth;

create table if not exists auth.users (
  id uuid primary key default gen_random_uuid(),
  email text,
  email_normalized text unique,
  phone text,
  phone_normalized text unique,
  email_confirmed_at timestamptz,
  phone_confirmed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  disabled_at timestamptz,
  constraint users_email_length_check check (email is null or char_length(email) between 3 and 320),
  constraint users_phone_format_check check (phone is null or phone ~ '^\+861[3-9][0-9]{9}$'),
  constraint users_identity_check check (email_normalized is not null or phone_normalized is not null)
);

alter table auth.users alter column email drop not null;
alter table auth.users alter column email_normalized drop not null;
alter table auth.users add column if not exists phone text;
alter table auth.users add column if not exists phone_normalized text;
alter table auth.users add column if not exists phone_confirmed_at timestamptz;
alter table auth.users drop constraint if exists users_phone_format_check;
alter table auth.users
  add constraint users_phone_format_check
  check (phone is null or phone ~ '^\+861[3-9][0-9]{9}$');

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conrelid = 'auth.users'::regclass
      and conname = 'users_identity_check'
  ) then
    alter table auth.users
      add constraint users_identity_check
      check (email_normalized is not null or phone_normalized is not null);
  end if;
end
$$;

create unique index if not exists users_phone_normalized_uidx
on auth.users (phone_normalized)
where phone_normalized is not null;

create or replace function auth.uid()
returns uuid
language sql
stable
as $$
  select nullif(current_setting('app.user_id', true), '')::uuid
$$;

create table if not exists auth.email_codes (
  id uuid primary key default gen_random_uuid(),
  email_normalized text not null,
  purpose text not null default 'login',
  code_hash text not null,
  attempts integer not null default 0,
  expires_at timestamptz not null,
  consumed_at timestamptz,
  requested_ip inet,
  created_at timestamptz not null default now(),
  constraint email_codes_purpose_check check (purpose in ('login')),
  constraint email_codes_attempts_check check (attempts between 0 and 10)
);

create index if not exists email_codes_lookup_idx
on auth.email_codes (email_normalized, purpose, created_at desc);

create table if not exists auth.phone_codes (
  id uuid primary key default gen_random_uuid(),
  phone_normalized text not null,
  purpose text not null default 'login',
  code_hash text not null,
  attempts integer not null default 0,
  expires_at timestamptz not null,
  consumed_at timestamptz,
  requested_ip inet,
  provider_request_id text,
  created_at timestamptz not null default now(),
  constraint phone_codes_phone_check check (phone_normalized ~ '^\+861[3-9][0-9]{9}$'),
  constraint phone_codes_purpose_check check (purpose in ('login')),
  constraint phone_codes_attempts_check check (attempts between 0 and 10)
);

create index if not exists phone_codes_lookup_idx
on auth.phone_codes (phone_normalized, purpose, created_at desc);

alter table auth.phone_codes drop constraint if exists phone_codes_phone_check;
alter table auth.phone_codes
  add constraint phone_codes_phone_check
  check (phone_normalized ~ '^\+861[3-9][0-9]{9}$');

create table if not exists auth.sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  last_seen_at timestamptz not null default now(),
  created_ip inet,
  user_agent text,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists sessions_user_idx
on auth.sessions (user_id, created_at desc);

create index if not exists sessions_active_idx
on auth.sessions (token_hash, expires_at)
where revoked_at is null;

revoke all on schema auth from public, anon, authenticated;
revoke all on all tables in schema auth from public, anon, authenticated;
