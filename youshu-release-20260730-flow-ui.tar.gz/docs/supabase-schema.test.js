import { readFile } from "node:fs/promises";
import { describe, expect, it } from "vitest";

describe("Supabase schema", () => {
  it("defines server-owned payment orders with user read-only RLS", async () => {
    const schema = await readFile("docs/supabase-schema.sql", "utf8");

    expect(schema).toContain("create table if not exists public.payment_orders");
    expect(schema).toContain("unique (user_id, client_request_id)");
    expect(schema).toContain("payment_orders_product_check");
    expect(schema).toContain("payment_orders_status_check");
    expect(schema).toContain('create policy "Users can read their own payment orders"');
    expect(schema).toContain("grant select, insert, update, delete on table public.payment_orders to service_role");
    expect(schema).not.toContain("grant insert on table public.payment_orders to authenticated");
  });

  it("documents user entitlements with RLS and quantity tracking", async () => {
    const schema = await readFile("docs/supabase-schema.sql", "utf8");

    expect(schema).toContain("create table if not exists public.user_entitlements");
    expect(schema).toContain("product_key text not null");
    expect(schema).toContain("included_quantity integer");
    expect(schema).toContain("used_quantity integer not null default 0");
    expect(schema).toContain("alter table public.user_entitlements enable row level security");
    expect(schema).toContain("grant select, insert, update, delete on table public.user_entitlements to service_role");
    expect(schema).toContain('create policy "Users can read their own entitlements"');
    expect(schema).toContain("using (auth.uid() = user_id)");
    expect(schema).toContain("user_entitlements_user_product_idx");
    expect(schema).toContain("user_entitlements_order_product_uidx");
  });

  it("assigns stable client report keys for idempotent save and deletion", async () => {
    const schema = await readFile("docs/supabase-schema.sql", "utf8");

    expect(schema).toContain("add column if not exists report_key text");
    expect(schema).toContain("reports_user_report_key_uidx");
    expect(schema).toContain("report_payload->>'id'");
  });

  it("documents one-time referral rewards as an atomic database operation", async () => {
    const schema = await readFile("docs/supabase-schema.sql", "utf8");

    expect(schema).toContain("create table if not exists public.referral_codes");
    expect(schema).toContain("create table if not exists public.referral_claims");
    expect(schema).toContain("invitee_user_id uuid not null unique");
    expect(schema).toContain("constraint referral_claims_not_self");
    expect(schema).toContain("create or replace function public.claim_referral_reward");
    expect(schema).toContain("'question'");
    expect(schema).toContain("'referral_reward'");
    expect(schema).toContain("grant execute on function public.claim_referral_reward(text, uuid) to service_role");
  });

  it("stores privacy-limited report feedback behind per-user RLS", async () => {
    const schema = await readFile("docs/supabase-schema.sql", "utf8");

    expect(schema).toContain("create table if not exists public.report_feedback");
    expect(schema).toContain("rating in ('helpful', 'unhelpful')");
    expect(schema).toContain("cardinality(reason_tags) <= 8");
    expect(schema).toContain("char_length(comment) <= 300");
    expect(schema).toContain("unique (user_id, report_key)");
    expect(schema).toContain("alter table public.report_feedback enable row level security");
    expect(schema).toContain('create policy "Users can create their own report feedback"');
    expect(schema).toContain('create policy "Users can update their own report feedback"');
  });

  it("reserves and releases report entitlements atomically on the server", async () => {
    const schema = await readFile("docs/supabase-schema.sql", "utf8");

    expect(schema).toContain("create table if not exists public.report_generation_reservations");
    expect(schema).toContain("request_id text not null unique");
    expect(schema).toContain("alter table public.report_generation_reservations enable row level security");
    expect(schema).toContain("create or replace function public.reserve_report_entitlement");
    expect(schema).toContain("for update skip locked");
    expect(schema).toContain("interval '30 minutes'");
    expect(schema).toContain("report_generation_stale_reservations_idx");
    expect(schema).toContain("used_quantity = entitlement.used_quantity + 1");
    expect(schema).toContain("create or replace function public.complete_report_generation");
    expect(schema).toContain("create or replace function public.release_report_entitlement");
    expect(schema).toContain("used_quantity = greatest(entitlement.used_quantity - 1, 0)");
    expect(schema).toContain(
      "grant execute on function public.reserve_report_entitlement(uuid, text, text) to service_role",
    );
  });
});
