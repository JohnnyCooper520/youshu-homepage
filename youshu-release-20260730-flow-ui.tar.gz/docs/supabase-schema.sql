create extension if not exists pgcrypto;

create table if not exists public.payment_orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique,
  client_request_id text not null,
  user_id uuid not null references auth.users(id) on delete restrict,
  product_key text not null,
  subject text not null,
  amount numeric(10, 2) not null,
  currency text not null default 'CNY',
  status text not null default 'created',
  provider text not null default 'alipay',
  provider_trade_id text,
  paid_at timestamptz,
  refund_status text not null default 'none',
  refunded_amount numeric(10, 2) not null default 0,
  raw_payment jsonb not null default '{}'::jsonb,
  raw_refund jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint payment_orders_order_no_check check (order_no ~ '^YS[0-9]{8}[A-F0-9]{16}$'),
  constraint payment_orders_client_request_check check (client_request_id ~ '^[A-Za-z0-9_-]{8,80}$'),
  constraint payment_orders_product_check check (product_key in ('bazi', 'question', 'annual')),
  constraint payment_orders_amount_check check (amount > 0),
  constraint payment_orders_currency_check check (currency = 'CNY'),
  constraint payment_orders_status_check check (status in ('created', 'paid', 'closed', 'refunding', 'refunded')),
  constraint payment_orders_refund_status_check check (refund_status in ('none', 'processing', 'partial', 'refunded', 'failed')),
  constraint payment_orders_refunded_amount_check check (refunded_amount >= 0 and refunded_amount <= amount),
  unique (user_id, client_request_id)
);

alter table public.payment_orders enable row level security;

grant select on table public.payment_orders to authenticated;
grant select, insert, update, delete on table public.payment_orders to service_role;

drop policy if exists "Users can read their own payment orders" on public.payment_orders;
create policy "Users can read their own payment orders"
on public.payment_orders
for select
using (auth.uid() = user_id);

create index if not exists payment_orders_user_created_idx
on public.payment_orders (user_id, created_at desc);

create unique index if not exists payment_orders_provider_trade_uidx
on public.payment_orders (provider, provider_trade_id)
where provider_trade_id is not null and provider_trade_id <> '';

create index if not exists payment_orders_status_updated_idx
on public.payment_orders (status, updated_at);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  report_key text,
  report_type text not null,
  title text,
  report_payload jsonb not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.reports
add column if not exists report_key text;

update public.reports
set report_key = report_payload->>'id'
where report_key is null
  and report_payload ? 'id';

alter table public.reports enable row level security;

grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on table public.reports to authenticated;
grant select, insert, update, delete on table public.reports to service_role;

drop policy if exists "Users can read their own reports" on public.reports;
create policy "Users can read their own reports"
on public.reports
for select
using (auth.uid() = user_id);

drop policy if exists "Users can create their own reports" on public.reports;
create policy "Users can create their own reports"
on public.reports
for insert
with check (auth.uid() = user_id);

drop policy if exists "Users can update their own reports" on public.reports;
create policy "Users can update their own reports"
on public.reports
for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own reports" on public.reports;
create policy "Users can delete their own reports"
on public.reports
for delete
using (auth.uid() = user_id);

create index if not exists reports_user_created_at_idx
on public.reports (user_id, created_at desc);

create unique index if not exists reports_user_report_key_uidx
on public.reports (user_id, report_key)
where report_key is not null;

create table if not exists public.report_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  report_key text not null,
  report_type text not null,
  prompt_version text,
  rating text not null,
  reason_tags text[] not null default '{}',
  comment text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint report_feedback_report_key_check check (char_length(report_key) between 1 and 100),
  constraint report_feedback_report_type_check check (report_type in ('bazi', 'annual', 'question', 'unknown')),
  constraint report_feedback_rating_check check (rating in ('helpful', 'unhelpful')),
  constraint report_feedback_reason_tags_check check (cardinality(reason_tags) <= 8),
  constraint report_feedback_comment_check check (comment is null or char_length(comment) <= 300),
  unique (user_id, report_key)
);

alter table public.report_feedback enable row level security;

grant select, insert, update, delete on table public.report_feedback to authenticated;
grant select, insert, update, delete on table public.report_feedback to service_role;

drop policy if exists "Users can read their own report feedback" on public.report_feedback;
create policy "Users can read their own report feedback"
on public.report_feedback
for select
using (auth.uid() = user_id);

drop policy if exists "Users can create their own report feedback" on public.report_feedback;
create policy "Users can create their own report feedback"
on public.report_feedback
for insert
with check (auth.uid() = user_id);

drop policy if exists "Users can update their own report feedback" on public.report_feedback;
create policy "Users can update their own report feedback"
on public.report_feedback
for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own report feedback" on public.report_feedback;
create policy "Users can delete their own report feedback"
on public.report_feedback
for delete
using (auth.uid() = user_id);

create index if not exists report_feedback_user_updated_idx
on public.report_feedback (user_id, updated_at desc);

create table if not exists public.user_entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_key text not null,
  status text not null default 'active',
  included_quantity integer,
  used_quantity integer not null default 0,
  starts_at timestamptz not null default now(),
  expires_at timestamptz,
  source text not null default 'manual',
  order_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint user_entitlements_status_check check (status in ('active', 'expired', 'refunded', 'revoked')),
  constraint user_entitlements_quantity_check check (included_quantity is null or included_quantity >= 0),
  constraint user_entitlements_used_quantity_check check (used_quantity >= 0)
);

alter table public.user_entitlements enable row level security;

grant select on table public.user_entitlements to authenticated;
grant select, insert, update, delete on table public.user_entitlements to service_role;

drop policy if exists "Users can read their own entitlements" on public.user_entitlements;
create policy "Users can read their own entitlements"
on public.user_entitlements
for select
using (auth.uid() = user_id);

create index if not exists user_entitlements_user_product_idx
on public.user_entitlements (user_id, product_key, status, expires_at);

create unique index if not exists user_entitlements_order_product_uidx
on public.user_entitlements (order_id, product_key);

create table if not exists public.referral_codes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  code text not null unique,
  created_at timestamptz not null default now(),
  constraint referral_codes_code_check check (code ~ '^[A-Z0-9_-]{8,24}$')
);

create table if not exists public.referral_claims (
  id uuid primary key default gen_random_uuid(),
  code_id uuid not null references public.referral_codes(id) on delete restrict,
  referrer_user_id uuid not null references auth.users(id) on delete cascade,
  invitee_user_id uuid not null unique references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint referral_claims_not_self check (referrer_user_id <> invitee_user_id)
);

alter table public.referral_codes enable row level security;
alter table public.referral_claims enable row level security;

revoke all on table public.referral_codes from anon, authenticated;
revoke all on table public.referral_claims from anon, authenticated;
grant select, insert, update, delete on table public.referral_codes to service_role;
grant select, insert, update, delete on table public.referral_claims to service_role;

create index if not exists referral_claims_referrer_created_idx
on public.referral_claims (referrer_user_id, created_at desc);

create or replace function public.claim_referral_reward(
  p_code text,
  p_invitee_user_id uuid
)
returns table(status text)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_code public.referral_codes%rowtype;
  v_claim_id uuid;
begin
  select *
  into v_code
  from public.referral_codes
  where code = upper(trim(p_code));

  if v_code.id is null then
    return query select 'invalid'::text;
    return;
  end if;

  if v_code.user_id = p_invitee_user_id then
    return query select 'self'::text;
    return;
  end if;

  insert into public.referral_claims (
    code_id,
    referrer_user_id,
    invitee_user_id
  )
  values (
    v_code.id,
    v_code.user_id,
    p_invitee_user_id
  )
  on conflict (invitee_user_id) do nothing
  returning id into v_claim_id;

  if v_claim_id is null then
    return query select 'already_claimed'::text;
    return;
  end if;

  insert into public.user_entitlements (
    user_id,
    product_key,
    status,
    included_quantity,
    used_quantity,
    source,
    order_id,
    metadata
  )
  values (
    v_code.user_id,
    'question',
    'active',
    1,
    0,
    'referral',
    'referral:' || v_claim_id::text,
    jsonb_build_object(
      'kind', 'referral_reward',
      'referral_claim_id', v_claim_id,
      'invitee_user_id', p_invitee_user_id
    )
  );

  return query select 'rewarded'::text;
end;
$$;

revoke all on function public.claim_referral_reward(text, uuid) from public, anon, authenticated;
grant execute on function public.claim_referral_reward(text, uuid) to service_role;

create table if not exists public.report_generation_reservations (
  id uuid primary key default gen_random_uuid(),
  request_id text not null unique,
  user_id uuid not null references auth.users(id) on delete cascade,
  entitlement_id uuid not null references public.user_entitlements(id) on delete restrict,
  product_key text not null,
  status text not null default 'reserved',
  response jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz,
  released_at timestamptz,
  constraint report_generation_request_id_check check (request_id ~ '^[A-Za-z0-9_-]{8,80}$'),
  constraint report_generation_product_key_check check (product_key in ('bazi', 'annual', 'question')),
  constraint report_generation_status_check check (status in ('reserved', 'completed', 'released'))
);

alter table public.report_generation_reservations enable row level security;

revoke all on table public.report_generation_reservations from anon, authenticated;
grant select, insert, update, delete on table public.report_generation_reservations to service_role;

create index if not exists report_generation_user_created_idx
on public.report_generation_reservations (user_id, created_at desc);

create index if not exists report_generation_stale_reservations_idx
on public.report_generation_reservations (user_id, product_key, status, updated_at);

create or replace function public.reserve_report_entitlement(
  p_user_id uuid,
  p_product_key text,
  p_request_id text
)
returns table(
  status text,
  reservation_id uuid,
  is_new boolean,
  response jsonb
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_existing public.report_generation_reservations%rowtype;
  v_entitlement_id uuid;
  v_reservation_id uuid;
  v_stale public.report_generation_reservations%rowtype;
begin
  if p_user_id is null then
    raise exception 'user id is required';
  end if;
  if p_product_key not in ('bazi', 'annual', 'question') then
    raise exception 'unsupported product key';
  end if;
  if p_request_id is null or p_request_id !~ '^[A-Za-z0-9_-]{8,80}$' then
    raise exception 'invalid request id';
  end if;

  perform pg_advisory_xact_lock(hashtext(p_request_id));

  select reservation.*
  into v_existing
  from public.report_generation_reservations as reservation
  where reservation.request_id = p_request_id
  for update;

  if v_existing.id is not null then
    if v_existing.user_id <> p_user_id or v_existing.product_key <> p_product_key then
      return query select 'conflict'::text, null::uuid, false, null::jsonb;
      return;
    end if;

    if v_existing.status = 'reserved'
      and v_existing.updated_at < now() - interval '30 minutes' then
      update public.report_generation_reservations as reservation
      set updated_at = now()
      where reservation.id = v_existing.id;

      return query
      select 'reserved'::text, v_existing.id, true, null::jsonb;
      return;
    end if;

    return query
    select
      v_existing.status,
      v_existing.id,
      false,
      case when v_existing.status = 'completed' then v_existing.response else null end;
    return;
  end if;

  for v_stale in
    select reservation.*
    from public.report_generation_reservations as reservation
    where reservation.user_id = p_user_id
      and reservation.product_key = p_product_key
      and reservation.status = 'reserved'
      and reservation.updated_at < now() - interval '30 minutes'
    for update skip locked
  loop
    update public.user_entitlements as entitlement
    set
      used_quantity = greatest(entitlement.used_quantity - 1, 0),
      updated_at = now()
    where entitlement.id = v_stale.entitlement_id;

    update public.report_generation_reservations as reservation
    set
      status = 'released',
      released_at = now(),
      updated_at = now()
    where reservation.id = v_stale.id;
  end loop;

  select entitlement.id
  into v_entitlement_id
  from public.user_entitlements as entitlement
  where entitlement.user_id = p_user_id
    and entitlement.product_key = p_product_key
    and entitlement.status = 'active'
    and entitlement.starts_at <= now()
    and (entitlement.expires_at is null or entitlement.expires_at > now())
    and (
      entitlement.included_quantity is null
      or entitlement.used_quantity < entitlement.included_quantity
    )
  order by entitlement.expires_at asc nulls last, entitlement.created_at asc
  for update skip locked
  limit 1;

  if v_entitlement_id is null then
    return query select 'insufficient'::text, null::uuid, false, null::jsonb;
    return;
  end if;

  update public.user_entitlements as entitlement
  set
    used_quantity = entitlement.used_quantity + 1,
    updated_at = now()
  where entitlement.id = v_entitlement_id;

  insert into public.report_generation_reservations (
    request_id,
    user_id,
    entitlement_id,
    product_key
  )
  values (
    p_request_id,
    p_user_id,
    v_entitlement_id,
    p_product_key
  )
  returning id into v_reservation_id;

  return query select 'reserved'::text, v_reservation_id, true, null::jsonb;
end;
$$;

create or replace function public.complete_report_generation(
  p_reservation_id uuid,
  p_user_id uuid,
  p_response jsonb
)
returns table(status text)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_status text;
begin
  update public.report_generation_reservations as reservation
  set
    status = 'completed',
    response = p_response,
    completed_at = now(),
    updated_at = now()
  where reservation.id = p_reservation_id
    and reservation.user_id = p_user_id
    and reservation.status = 'reserved'
  returning reservation.status into v_status;

  if v_status is null then
    select reservation.status
    into v_status
    from public.report_generation_reservations as reservation
    where reservation.id = p_reservation_id
      and reservation.user_id = p_user_id;
  end if;

  return query select coalesce(v_status, 'missing')::text;
end;
$$;

create or replace function public.release_report_entitlement(
  p_reservation_id uuid,
  p_user_id uuid
)
returns table(status text)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_reservation public.report_generation_reservations%rowtype;
begin
  select reservation.*
  into v_reservation
  from public.report_generation_reservations as reservation
  where reservation.id = p_reservation_id
    and reservation.user_id = p_user_id
  for update;

  if v_reservation.id is null then
    return query select 'missing'::text;
    return;
  end if;

  if v_reservation.status <> 'reserved' then
    return query select v_reservation.status;
    return;
  end if;

  update public.user_entitlements as entitlement
  set
    used_quantity = greatest(entitlement.used_quantity - 1, 0),
    updated_at = now()
  where entitlement.id = v_reservation.entitlement_id;

  update public.report_generation_reservations as reservation
  set
    status = 'released',
    released_at = now(),
    updated_at = now()
  where reservation.id = v_reservation.id;

  return query select 'released'::text;
end;
$$;

revoke all on function public.reserve_report_entitlement(uuid, text, text) from public, anon, authenticated;
revoke all on function public.complete_report_generation(uuid, uuid, jsonb) from public, anon, authenticated;
revoke all on function public.release_report_entitlement(uuid, uuid) from public, anon, authenticated;
grant execute on function public.reserve_report_entitlement(uuid, text, text) to service_role;
grant execute on function public.complete_report_generation(uuid, uuid, jsonb) to service_role;
grant execute on function public.release_report_entitlement(uuid, uuid) to service_role;
