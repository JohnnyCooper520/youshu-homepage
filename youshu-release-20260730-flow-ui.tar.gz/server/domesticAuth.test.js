import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { createDomesticAuth } from "./domesticAuth.js";

describe("domestic phone authentication", () => {
  it("supports the partial unique phone index used by upgraded databases", async () => {
    const secret = "a".repeat(32);
    const phone = "+8613812345678";
    const code = "123456";
    const queries = [];
    const client = {
      async query(text) {
        queries.push(text);
        if (text.includes("select id, code_hash, attempts, expires_at")) {
          return {
            rows: [{
              id: "code-1",
              code_hash: createHmac("sha256", secret)
                .update(`${phone}\n${code}`)
                .digest("hex"),
              attempts: 0,
              expires_at: "2026-07-30T04:00:00.000Z",
            }],
          };
        }
        if (text.includes("insert into auth.users")) {
          return {
            rows: [{
              id: "user-1",
              email: null,
              phone,
            }],
          };
        }
        return { rows: [] };
      },
      release() {},
    };
    const pool = {
      async connect() {
        return client;
      },
    };
    const auth = createDomesticAuth({
      env: { AUTH_CODE_SECRET: secret },
      pool,
      now: () => new Date("2026-07-30T03:00:00.000Z"),
    });

    await expect(auth.verifyPhoneCode({
      phone,
      code,
      ip: "127.0.0.1",
      userAgent: "test",
    })).resolves.toMatchObject({
      user: { id: "user-1", phone },
    });

    const userInsert = queries.find((query) => query.includes("insert into auth.users"));
    expect(userInsert).toContain(
      "on conflict (phone_normalized) where phone_normalized is not null do update",
    );
  });
});
