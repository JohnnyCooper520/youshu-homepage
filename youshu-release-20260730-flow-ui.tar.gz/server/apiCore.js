import { calculateBazi } from "../src/paipan/calculateBazi.js";
import { createDeepSeekChat } from "../src/llm/deepseekClient.js";
import { generateReport } from "../src/report/generateReport.js";
import { generateReportPreview } from "../src/report/generatePreview.js";
import {
  createAlipayOpenApiClient,
  createAlipayPagePayProvider,
  createAlipayVerifier,
} from "./alipay.js";
import { createSupabaseEntitlementStore } from "./paymentEntitlements.js";
import { getPaymentProduct } from "./paymentCatalog.js";
import {
  createSupabasePaymentOrderStore,
  paymentAccessToken,
  paymentAmountsMatch,
} from "./paymentOrders.js";
import { bearerToken, createSupabaseReferralStore } from "./referrals.js";
import { createSupabaseGenerationAccessStore } from "./generationAccess.js";
import { createDomesticStores } from "./domesticStores.js";
import {
  createMemoryRateLimiter,
  enforceGenerationRateLimit,
  enforceRequestRateLimit,
  getRequestIdentity,
  validateGenerationInput,
} from "./requestGuards.js";

const VALID_TYPES = new Set(["bazi", "annual", "question"]);
const MAX_REQUEST_BODY_BYTES = 128 * 1024;

export function createMemoryKeyStore({ env = process.env } = {}) {
  let runtimeKey = "";

  return {
    get() {
      if (runtimeKey) {
        return { apiKey: runtimeKey, source: "runtime" };
      }
      if (env.DEEPSEEK_API_KEY) {
        return { apiKey: env.DEEPSEEK_API_KEY, source: "env" };
      }
      return { apiKey: "", source: null };
    },
    set(apiKey) {
      runtimeKey = String(apiKey || "").trim();
      return this.get();
    },
  };
}

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...headers,
    },
  });
}

function plainText(data, status = 200) {
  return new Response(data, {
    status,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
    },
  });
}

async function readBody(request) {
  if (request.method === "GET" || request.method === "HEAD") {
    return {};
  }
  const declaredLength = Number(request.headers.get("content-length") || 0);
  if (declaredLength > MAX_REQUEST_BODY_BYTES) {
    const error = new Error("Request body is too large");
    error.status = 413;
    throw error;
  }

  const text = await request.text();
  if (Buffer.byteLength(text, "utf8") > MAX_REQUEST_BODY_BYTES) {
    const error = new Error("Request body is too large");
    error.status = 413;
    throw error;
  }
  if (!text) {
    return {};
  }

  const contentType = request.headers.get("content-type") || "";
  if (contentType.includes("application/x-www-form-urlencoded")) {
    return Object.fromEntries(new URLSearchParams(text));
  }

  return JSON.parse(text);
}

function normalizeInput(body) {
  return {
    calendarType: body.calendarType || "solar",
    isLeapMonth: body.isLeapMonth === true,
    birthDate: body.birthDate,
    birthTime: body.birthTime,
    gender: body.gender || "",
    birthPlace: body.birthPlace || "",
    birthLongitude: body.birthLongitude,
    timezone: body.timezone || "Asia/Shanghai",
    useTrueSolarTime: body.useTrueSolarTime === true,
    ziHourConvention: body.ziHourConvention || "zi-chu",
    currentDate: new Date().toISOString().slice(0, 10),
  };
}

function mockContentFor(type, language) {
  if (language === "en") {
    if (type === "annual") {
      return "# Annual Rhythm Report\nA local test report for saving, opening, and archive behavior without a model key.\n\n## Opening judgment\nFirst steady the near field, then read the turning points.\n\n## The year's center of gravity\nKeep the work that can compound, and leave room around choices that still need time.\n\n## The next three months\nUse the next stretch to clarify priorities before adding commitments.\n\n## Suggested move\n- Finish one important loose end.\n- Revisit the decision after new information arrives.";
    }
    if (type === "question") {
      return "# One-Matter Analysis\nA local test report for saving, opening, and archive behavior without a model key.\n\n## The judgment\nKeep the question concrete and the next step becomes easier to see.\n\n## The situation\nDo not rush a decision before the practical conditions are clear.\n\n## Suggested move\n- Check one key condition.\n- Set a date to revisit the choice.";
    }
    return "# Personal Structure Report\nA local test report for saving, opening, and archive behavior without a model key.\n\n## Opening judgment\nKnow the ground first; then choose with less noise.\n\n## Core pattern\nSteadiness works better when it is paired with a clear boundary.\n\n## How to apply effort\nChoose fewer directions and return to them consistently.\n\n## Next step\n- Name the one thing worth protecting this week.\n- Let the next decision wait for one useful signal.";
  }

  if (language === "zh-TW") {
    if (type === "annual") {
      return "# 年度節奏報告\n這是一份本地測試報告，用來測試生成、歸檔和再次打開，不會消耗模型額度。\n\n## 開篇判斷\n先穩眼前，再看一年裡的轉折。\n\n## 這一年的重心\n先守住能累積的事，再為新的選擇留一點空間。\n\n## 眼前三月\n先把先後看清，不急著同時做完所有事。\n\n## 取捨建議\n- 整理一件長期拖著的事。\n- 在新訊息出現後再回看選擇。";
    }
    if (type === "question") {
      return "# 一事分析\n這是一份本地測試報告，用來測試生成、歸檔和再次打開，不會消耗模型額度。\n\n## 這件事的判斷\n問題越具體，下一步越容易落地。\n\n## 形勢\n先看清現實條件，再決定要不要加快。\n\n## 建議推進\n- 確認一個關鍵條件。\n- 給這件事留一個回看的日期。";
    }
    return "# 個人結構報告\n這是一份本地測試報告，用來測試生成、歸檔和再次打開，不會消耗模型額度。\n\n## 開篇判斷\n先看清自己的底色，再談選擇。\n\n## 結構底色\n穩住節奏，比急著證明自己更有用。\n\n## 用力方向\n把注意力放在能持續累積的事情上。\n\n## 下一步\n- 寫下這週最值得守住的一件事。\n- 等一個有效訊號後再做新決定。";
  }

  if (type === "annual") {
    return "# 年度节奏报告\n这是一份本地测试报告，用来测试生成、归档和再次打开，不会消耗模型额度。\n\n## 开篇判断\n先稳眼前，再看一年里的转折。\n\n## 这一年的重心\n先守住能积累的事，再为新的选择留一点空间。\n\n## 眼前三月\n先把先后看清，不急着同时做完所有事。\n\n## 取舍建议\n- 整理一件长期拖着的事。\n- 在新信息出现后再回看选择。";
  }
  if (type === "question") {
    return "# 一事分析\n这是一份本地测试报告，用来测试生成、归档和再次打开，不会消耗模型额度。\n\n## 这件事的判断\n问题越具体，下一步越容易落地。\n\n## 形势\n先看清现实条件，再决定要不要加快。\n\n## 建议推进\n- 确认一个关键条件。\n- 给这件事留一个回看的日期。";
  }
  return "# 个人结构报告\n这是一份本地测试报告，用来测试生成、归档和再次打开，不会消耗模型额度。\n\n## 开篇判断\n先看清自己的底色，再谈选择。\n\n## 结构底色\n稳住节奏，比急着证明自己更有用。\n\n## 用力方向\n把注意力放在能持续积累的事情上。\n\n## 下一步\n- 写下这周最值得守住的一件事。\n- 等一个有效信号后再做新决定。";
}

function isPaidAlipayTrade(fields) {
  return fields.trade_status === "TRADE_SUCCESS" || fields.trade_status === "TRADE_FINISHED";
}

function requirePaymentAdmin(request, env) {
  const configuredToken = String(env.PAYMENT_ADMIN_TOKEN || "");
  if (!configuredToken) {
    throw Object.assign(new Error("Payment administration is not configured"), { status: 503 });
  }
  if (request.headers.get("x-payment-admin-token") !== configuredToken) {
    throw Object.assign(new Error("Payment administration access denied"), { status: 403 });
  }
}

function getAlipayPayment(fields, env, order) {
  if (env.ALIPAY_APP_ID && fields.app_id !== env.ALIPAY_APP_ID) {
    throw new Error("Alipay app_id mismatch");
  }
  if (env.ALIPAY_SELLER_ID && fields.seller_id !== env.ALIPAY_SELLER_ID) {
    throw new Error("Alipay seller_id mismatch");
  }
  if (!isPaidAlipayTrade(fields)) {
    throw new Error("Alipay trade is not paid");
  }
  if (!fields.out_trade_no) {
    throw new Error("Alipay out_trade_no is required");
  }
  if (!paymentAmountsMatch(order.amount, fields.total_amount)) {
    throw new Error("Alipay payment amount mismatch");
  }

  return {
    provider: "alipay",
    orderId: fields.out_trade_no,
    providerTradeId: fields.trade_no || "",
    userId: order.user_id,
    productKey: order.product_key,
    amount: Number(order.amount).toFixed(2),
  };
}

export function createApiHandler({
  env = process.env,
  domesticStores = env.DATA_BACKEND === "postgres" ? createDomesticStores({ env }) : null,
  keyStore = createMemoryKeyStore({ env }),
  createChat = createDeepSeekChat,
  allowRuntimeKey = env.ALLOW_RUNTIME_DEEPSEEK_KEY === "true",
  mockReports = env.MOCK_REPORTS === "true",
  requireGenerationAuth = !mockReports && env.REQUIRE_GENERATION_AUTH !== "false",
  entitlementStore = domesticStores?.entitlementStore || createSupabaseEntitlementStore({ env }),
  paymentOrderStore = domesticStores?.paymentOrderStore || createSupabasePaymentOrderStore({ env }),
  alipayPagePayProvider = createAlipayPagePayProvider({ env }),
  alipayOpenApiClient = createAlipayOpenApiClient({ env }),
  generationAccessStore = domesticStores?.generationAccessStore || createSupabaseGenerationAccessStore({ env }),
  referralStore = domesticStores?.referralStore || createSupabaseReferralStore({ env }),
  authStore = domesticStores?.auth || null,
  accountStore = domesticStores?.accountStore || null,
  alipayVerifier = createAlipayVerifier({ env }),
  generationRateLimiter = createMemoryRateLimiter(),
  paymentRateLimiter = createMemoryRateLimiter({ maxRequests: 10 }),
  authRateLimiter = createMemoryRateLimiter({ maxRequests: 8 }),
} = {}) {
  return async function handleApiRequest(request) {
    try {
      const url = new URL(request.url);

      if (url.pathname === "/api/auth/email/request" && request.method === "POST") {
        if (!authStore) {
          return json({ error: "Domestic authentication is not configured" }, 503);
        }
        enforceRequestRateLimit(
          authRateLimiter,
          request,
          "auth-email",
          "Too many verification code requests. Please try again later.",
        );
        const body = await readBody(request);
        await authStore.requestEmailCode({
          email: body.email,
          ip: getRequestIdentity(request),
        });
        return json({ ok: true }, 202);
      }

      if (url.pathname === "/api/auth/email/verify" && request.method === "POST") {
        if (!authStore) {
          return json({ error: "Domestic authentication is not configured" }, 503);
        }
        enforceRequestRateLimit(
          authRateLimiter,
          request,
          "auth-verify",
          "Too many verification attempts. Please try again later.",
        );
        const body = await readBody(request);
        const result = await authStore.verifyEmailCode({
          email: body.email,
          code: body.code,
          ip: getRequestIdentity(request),
          userAgent: request.headers.get("user-agent"),
        });
        return json({ ok: true, ...result });
      }

      if (url.pathname === "/api/auth/phone/request" && request.method === "POST") {
        if (!authStore) {
          return json({ error: "Domestic authentication is not configured" }, 503);
        }
        enforceRequestRateLimit(
          authRateLimiter,
          request,
          "auth-phone",
          "Too many verification code requests. Please try again later.",
        );
        const body = await readBody(request);
        await authStore.requestPhoneCode({
          phone: body.phone,
          ip: getRequestIdentity(request),
        });
        return json({ ok: true }, 202);
      }

      if (url.pathname === "/api/auth/phone/verify" && request.method === "POST") {
        if (!authStore) {
          return json({ error: "Domestic authentication is not configured" }, 503);
        }
        enforceRequestRateLimit(
          authRateLimiter,
          request,
          "auth-phone-verify",
          "Too many verification attempts. Please try again later.",
        );
        const body = await readBody(request);
        const result = await authStore.verifyPhoneCode({
          phone: body.phone,
          code: body.code,
          ip: getRequestIdentity(request),
          userAgent: request.headers.get("user-agent"),
        });
        return json({ ok: true, ...result });
      }

      if (url.pathname === "/api/auth/session" && request.method === "GET") {
        if (!authStore) {
          return json({ user: null });
        }
        try {
          const user = await authStore.authenticate(bearerToken(request));
          return json({ user });
        } catch (error) {
          if (error.status === 401) {
            return json({ user: null });
          }
          throw error;
        }
      }

      if (url.pathname === "/api/auth/signout" && request.method === "POST") {
        if (authStore) {
          await authStore.signOut(bearerToken(request));
        }
        return json({ ok: true });
      }

      if (url.pathname === "/api/account/reports" && request.method === "GET") {
        if (!accountStore) {
          return json({ error: "Account storage is not configured" }, 503);
        }
        return json({ reports: await accountStore.listReports(bearerToken(request)) });
      }

      if (url.pathname === "/api/account/reports" && request.method === "PUT") {
        if (!accountStore) {
          return json({ error: "Account storage is not configured" }, 503);
        }
        const body = await readBody(request);
        return json(await accountStore.saveReport(bearerToken(request), body.report));
      }

      const accountReportMatch = url.pathname.match(/^\/api\/account\/reports\/([A-Za-z0-9_-]{1,100})$/);
      if (accountReportMatch && request.method === "DELETE") {
        if (!accountStore) {
          return json({ error: "Account storage is not configured" }, 503);
        }
        return json(await accountStore.deleteReport(bearerToken(request), accountReportMatch[1]));
      }

      if (url.pathname === "/api/account/entitlements" && request.method === "GET") {
        if (!accountStore) {
          return json({ error: "Account storage is not configured" }, 503);
        }
        return json({ entitlements: await accountStore.listEntitlements(bearerToken(request)) });
      }

      if (url.pathname === "/api/account/feedback" && request.method === "PUT") {
        if (!accountStore) {
          return json({ error: "Account storage is not configured" }, 503);
        }
        const body = await readBody(request);
        return json(await accountStore.saveFeedback(bearerToken(request), body.feedback));
      }

      if (url.pathname === "/api/deepseek/status" && request.method === "GET") {
        if (mockReports) {
          return json({ configured: true, source: "mock" });
        }
        const key = keyStore.get();
        return json({ configured: Boolean(key.apiKey), source: key.source });
      }

      if (url.pathname === "/api/deepseek/key" && request.method === "POST") {
        if (!allowRuntimeKey) {
          return json({ error: "Runtime DeepSeek key updates are disabled" }, 403);
        }
        const body = await readBody(request);
        const key = keyStore.set(body.apiKey);
        return json({ configured: Boolean(key.apiKey), source: key.source });
      }

      if (url.pathname === "/api/generate/status" && request.method === "GET") {
        const result = await generationAccessStore.lookup({
          accessToken: bearerToken(request),
          requestId: url.searchParams.get("requestId"),
        });
        return json(result);
      }

      if (url.pathname === "/api/generate/preview" && request.method === "POST") {
        enforceGenerationRateLimit(generationRateLimiter, request);
        const body = await readBody(request);
        const type = VALID_TYPES.has(body.type) ? body.type : "bazi";
        validateGenerationInput(body, type);
        const paipan = calculateBazi(normalizeInput(body));
        return json({
          ok: true,
          type,
          access: "preview",
          paipan,
          content: generateReportPreview(type, paipan, {
            language: body.language || "zh-CN",
            question: body.question,
            focus: body.focus,
          }),
        });
      }

      if (url.pathname === "/api/payments/alipay/orders" && request.method === "POST") {
        enforceRequestRateLimit(
          paymentRateLimiter,
          request,
          "payment-order",
          "Too many payment order requests. Please try again later.",
        );
        if (!alipayPagePayProvider.isConfigured()) {
          return json({ error: "Alipay checkout is not configured" }, 503);
        }
        const body = await readBody(request);
        const product = getPaymentProduct(body.productKey);
        const result = await paymentOrderStore.create({
          accessToken: paymentAccessToken(request),
          product,
          clientRequestId: body.clientRequestId,
        });
        const checkout = alipayPagePayProvider.createCheckout(result.order);
        return json({
          ok: true,
          created: result.created,
          order: result.order,
          checkout,
        }, result.created ? 201 : 200);
      }

      const paymentOrderMatch = url.pathname.match(/^\/api\/payments\/orders\/(YS\d{8}[A-F0-9]{16})$/);
      if (paymentOrderMatch && request.method === "GET") {
        let order = await paymentOrderStore.getForUser({
          accessToken: paymentAccessToken(request),
          orderNo: paymentOrderMatch[1],
        });
        if (order.status === "created" && alipayOpenApiClient.isConfigured()) {
          try {
            const queryResult = await alipayOpenApiClient.query(order.orderNo);
            if (isPaidAlipayTrade(queryResult)) {
              const storedOrder = await paymentOrderStore.getForCallback(order.orderNo);
              const callbackFields = {
                ...queryResult,
                app_id: env.ALIPAY_APP_ID,
                seller_id: env.ALIPAY_SELLER_ID,
                out_trade_no: order.orderNo,
              };
              const payment = getAlipayPayment(callbackFields, env, storedOrder);
              await entitlementStore.recordPayment(payment);
              await paymentOrderStore.markPaid(storedOrder, callbackFields);
              order = await paymentOrderStore.getForUser({
                accessToken: paymentAccessToken(request),
                orderNo: order.orderNo,
              });
            }
          } catch {
            // The signed asynchronous notification remains authoritative; return the stored state.
          }
        }
        return json({ ok: true, order });
      }

      if (url.pathname === "/api/admin/payments/alipay/refunds" && request.method === "POST") {
        requirePaymentAdmin(request, env);
        if (!alipayOpenApiClient.isConfigured()) {
          return json({ error: "Alipay OpenAPI is not configured" }, 503);
        }
        const body = await readBody(request);
        const order = await paymentOrderStore.getForCallback(body.orderNo);
        if (order.status === "refunded" && order.refund_status === "refunded") {
          return json({ ok: true, order: await paymentOrderStore.markRefunded(order, {}) });
        }
        if (order.status !== "paid") {
          return json({ error: "Only a paid order can be refunded" }, 409);
        }
        const result = await alipayOpenApiClient.refund({
          orderNo: order.order_no,
          amount: Number(order.amount).toFixed(2),
          reason: String(body.reason || "").trim().slice(0, 200),
        });
        await entitlementStore.refundPayment(order.order_no);
        const refundedOrder = await paymentOrderStore.markRefunded(order, result);
        return json({ ok: true, order: refundedOrder });
      }

      if (url.pathname === "/api/generate" && request.method === "POST") {
        enforceGenerationRateLimit(generationRateLimiter, request);
        const body = await readBody(request);
        const type = VALID_TYPES.has(body.type) ? body.type : "bazi";
        validateGenerationInput(body, type);

        const paipan = calculateBazi(normalizeInput(body));
        if (mockReports) {
          return json({
            ok: true,
            type,
            paipan,
            content: mockContentFor(type, body.language || "zh-CN"),
            usage: { source: "mock" },
          });
        }

        const key = keyStore.get();
        if (!key.apiKey) {
          return json({ error: "DeepSeek API key is not configured on the backend" }, 400);
        }

        let reservation = null;
        try {
          if (requireGenerationAuth) {
            reservation = await generationAccessStore.reserve({
              accessToken: bearerToken(request),
              productKey: type,
              requestId: body.requestId,
            });
            if (reservation.cachedResponse) {
              return json(reservation.cachedResponse);
            }
          }

          const result = await generateReport({
            type,
            paipanResult: paipan,
            language: body.language || "zh-CN",
            question: body.question,
            focus: body.focus,
            coreProfile: body.coreProfile,
            createChat: (options) => createChat({ apiKey: key.apiKey, ...options }),
          });
          const response = {
            ok: true,
            type,
            paipan,
            content: result.content,
            usage: result.usage,
          };

          if (reservation?.reservationId) {
            await generationAccessStore.complete({
              reservationId: reservation.reservationId,
              userId: reservation.userId,
              response,
            });
          }
          return json(response);
        } catch (error) {
          if (reservation?.reservationId) {
            try {
              await generationAccessStore.release({
                reservationId: reservation.reservationId,
                userId: reservation.userId,
              });
            } catch {
              // The original generation error is more useful to the client.
            }
          }
          throw error;
        }
      }

      if (url.pathname === "/api/payments/alipay/notify" && request.method === "POST") {
        const fields = await readBody(request);
        if (!alipayVerifier(fields)) {
          return plainText("fail", 400);
        }

        const order = await paymentOrderStore.getForCallback(fields.out_trade_no);
        const payment = getAlipayPayment(fields, env, order);
        await entitlementStore.recordPayment(payment);
        await paymentOrderStore.markPaid(order, fields);
        return plainText("success");
      }

      if (url.pathname === "/api/referrals/code" && request.method === "POST") {
        const result = await referralStore.getOrCreateCode(bearerToken(request));
        return json(result);
      }

      if (url.pathname === "/api/referrals/claim" && request.method === "POST") {
        const body = await readBody(request);
        const result = await referralStore.claim(bearerToken(request), body.code);
        return json(result);
      }

      return json({ error: "Not found" }, 404);
    } catch (error) {
      if (new URL(request.url).pathname === "/api/payments/alipay/notify") {
        return plainText("fail", 400);
      }
      const headers = error.retryAfterSeconds
        ? { "Retry-After": String(error.retryAfterSeconds) }
        : {};
      return json({ error: error.message || "Unknown server error" }, error.status || 500, headers);
    }
  };
}

export const defaultApiHandler = createApiHandler();
