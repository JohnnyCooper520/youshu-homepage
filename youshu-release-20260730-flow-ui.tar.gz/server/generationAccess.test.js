import { describe, expect, it, vi } from "vitest";
import { createSupabaseGenerationAccessStore } from "./generationAccess.js";

function createStoreWithRpc(rpc) {
  const maybeSingle = vi.fn().mockResolvedValue({ data: null, error: null });
  const userEq = vi.fn(() => ({ maybeSingle }));
  const requestEq = vi.fn(() => ({ eq: userEq }));
  const select = vi.fn(() => ({ eq: requestEq }));
  const client = {
    auth: {
      getUser: vi.fn().mockResolvedValue({
        data: { user: { id: "user-1" } },
        error: null,
      }),
    },
    rpc,
    from: vi.fn(() => ({ select })),
  };
  const createSupabaseClient = vi.fn(() => client);
  const store = createSupabaseGenerationAccessStore({
    env: {
      SUPABASE_URL: "https://project.supabase.co",
      SUPABASE_SERVICE_ROLE_KEY: "service-role-key",
    },
    createSupabaseClient,
  });
  return { client, maybeSingle, store };
}

describe("Supabase generation access", () => {
  it("looks up a completed request for the authenticated owner", async () => {
    const { client, maybeSingle, store } = createStoreWithRpc(vi.fn());
    maybeSingle.mockResolvedValue({
      data: {
        status: "completed",
        response: { ok: true, content: "已完成" },
        product_key: "bazi",
        updated_at: "2026-07-28T01:00:00Z",
      },
      error: null,
    });

    await expect(store.lookup({
      accessToken: "access-token",
      requestId: "request_lookup_1",
    })).resolves.toEqual({
      status: "completed",
      response: { ok: true, content: "已完成" },
      productKey: "bazi",
      updatedAt: "2026-07-28T01:00:00Z",
    });

    expect(client.from).toHaveBeenCalledWith("report_generation_reservations");
    expect(client.auth.getUser).toHaveBeenCalledWith("access-token");
  });

  it("returns missing when a request does not belong to the user", async () => {
    const { store } = createStoreWithRpc(vi.fn());

    await expect(store.lookup({
      accessToken: "access-token",
      requestId: "request_missing_1",
    })).resolves.toEqual({ status: "missing" });
  });

  it("requires a bearer session before opening the admin client", async () => {
    const createSupabaseClient = vi.fn();
    const store = createSupabaseGenerationAccessStore({
      env: {},
      createSupabaseClient,
    });

    await expect(
      store.reserve({
        accessToken: "",
        productKey: "bazi",
        requestId: "request_12345",
      }),
    ).rejects.toMatchObject({
      message: "Authentication required",
      status: 401,
    });
    expect(createSupabaseClient).not.toHaveBeenCalled();
  });

  it("authenticates the user and reserves one entitlement through the RPC", async () => {
    const rpc = vi.fn().mockResolvedValue({
      data: [{
        status: "reserved",
        reservation_id: "reservation-1",
        is_new: true,
        response: null,
      }],
      error: null,
    });
    const { client, store } = createStoreWithRpc(rpc);

    await expect(
      store.reserve({
        accessToken: "access-token",
        productKey: "annual",
        requestId: "request_annual_1",
      }),
    ).resolves.toEqual({
      reservationId: "reservation-1",
      userId: "user-1",
    });

    expect(client.auth.getUser).toHaveBeenCalledWith("access-token");
    expect(rpc).toHaveBeenCalledWith("reserve_report_entitlement", {
      p_user_id: "user-1",
      p_product_key: "annual",
      p_request_id: "request_annual_1",
    });
  });

  it("returns a completed response for an idempotent retry", async () => {
    const cachedResponse = { ok: true, type: "question", content: "已完成" };
    const rpc = vi.fn().mockResolvedValue({
      data: [{
        status: "completed",
        reservation_id: "reservation-2",
        is_new: false,
        response: cachedResponse,
      }],
      error: null,
    });
    const { store } = createStoreWithRpc(rpc);

    await expect(
      store.reserve({
        accessToken: "access-token",
        productKey: "question",
        requestId: "request_question_1",
      }),
    ).resolves.toEqual({
      cachedResponse,
      reservationId: "reservation-2",
      userId: "user-1",
    });
  });

  it("does not complete a reservation that the database has already released", async () => {
    const rpc = vi.fn().mockResolvedValue({
      data: [{ status: "released" }],
      error: null,
    });
    const { store } = createStoreWithRpc(rpc);

    await expect(
      store.complete({
        reservationId: "reservation-2",
        userId: "user-1",
        response: { ok: true },
      }),
    ).rejects.toMatchObject({
      message: "This report reservation is no longer active",
      status: 409,
    });
  });

  it.each([
    ["insufficient", 403, "No report entitlement is available"],
    ["reserved", 409, "already being generated"],
    ["released", 409, "already been released"],
    ["conflict", 409, "already in use"],
  ])("maps the %s reservation state to an API error", async (status, expectedStatus, message) => {
    const rpc = vi.fn().mockResolvedValue({
      data: [{
        status,
        reservation_id: "reservation-3",
        is_new: false,
        response: null,
      }],
      error: null,
    });
    const { store } = createStoreWithRpc(rpc);

    await expect(
      store.reserve({
        accessToken: "access-token",
        productKey: "bazi",
        requestId: "request_status_1",
      }),
    ).rejects.toMatchObject({
      status: expectedStatus,
      message: expect.stringContaining(message),
    });
  });
});
