import { createSign, generateKeyPairSync } from "node:crypto";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it, vi } from "vitest";
import {
  canonicalizeAlipayFields,
  createAlipayOpenApiClient,
  createAlipayPagePayProvider,
  extractAlipayResponsePayload,
  formatAlipayTimestamp,
  parseAlipayPassbackParams,
  signAlipayFields,
  verifyAlipaySignature,
} from "./alipay.js";

function createSignedFields(fields, privateKey) {
  const signer = createSign("RSA-SHA256");
  signer.update(canonicalizeAlipayFields(fields), "utf8");
  signer.end();
  return {
    ...fields,
    sign: signer.sign(privateKey, "base64"),
  };
}

describe("alipay", () => {
  it("canonicalizes callback fields in Alipay signature order", () => {
    expect(
      canonicalizeAlipayFields({
        sign: "ignored",
        out_trade_no: "YS202607040001",
        sign_type: "RSA2",
        app_id: "2026000000000000",
        empty: "",
      }),
    ).toBe("app_id=2026000000000000&out_trade_no=YS202607040001&sign_type=RSA2");
  });

  it("verifies a real RSA2 callback signature and rejects tampering", () => {
    const { privateKey, publicKey } = generateKeyPairSync("rsa", {
      modulusLength: 2048,
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
      publicKeyEncoding: { type: "spki", format: "pem" },
    });
    const fields = createSignedFields(
      {
        app_id: "2026000000000000",
        trade_status: "TRADE_SUCCESS",
        out_trade_no: "YS202607040001",
        total_amount: "29.90",
        sign_type: "RSA2",
      },
      privateKey,
    );

    expect(verifyAlipaySignature(fields, publicKey)).toBe(true);
    expect(verifyAlipaySignature({ ...fields, total_amount: "1.00" }, publicKey)).toBe(false);
  });

  it("parses Alipay passback params from JSON or query strings", () => {
    expect(parseAlipayPassbackParams('{"userId":"u1","productKey":"bazi"}')).toEqual({
      userId: "u1",
      productKey: "bazi",
    });
    expect(parseAlipayPassbackParams("userId=u2&productKey=question")).toEqual({
      userId: "u2",
      productKey: "question",
    });
  });

  it("signs a computer website payment request with RSA2", () => {
    const { privateKey, publicKey } = generateKeyPairSync("rsa", {
      modulusLength: 2048,
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
      publicKeyEncoding: { type: "spki", format: "pem" },
    });
    const provider = createAlipayPagePayProvider({
      env: {
        ALIPAY_APP_ID: "2026000000000000",
        ALIPAY_APP_PRIVATE_KEY: privateKey,
        PUBLIC_SITE_URL: "https://dongfangyoushu.com.cn/",
      },
      now: () => new Date("2026-07-28T02:30:45.000Z"),
    });

    const checkout = provider.createCheckout({
      orderNo: "YS202607280001",
      amount: "39.90",
      subject: "有数｜年度节奏报告",
    });

    const actionUrl = new URL(checkout.gatewayUrl);
    const actionFields = Object.fromEntries(actionUrl.searchParams);
    expect(actionUrl.origin + actionUrl.pathname).toBe("https://openapi.alipay.com/gateway.do");
    expect(actionFields).toMatchObject({
      app_id: "2026000000000000",
      method: "alipay.trade.page.pay",
      sign_type: "RSA2",
      return_url: "https://dongfangyoushu.com.cn/payment/result",
      notify_url: "https://dongfangyoushu.com.cn/api/payments/alipay/notify",
    });
    expect(JSON.parse(checkout.formFields.biz_content)).toEqual({
      out_trade_no: "YS202607280001",
      total_amount: "39.90",
      subject: "有数｜年度节奏报告",
      product_code: "FAST_INSTANT_TRADE_PAY",
      timeout_express: "15m",
    });
    expect(Object.keys(checkout.formFields)).toEqual(["biz_content"]);
    expect(verifyAlipaySignature({
      ...actionFields,
      ...checkout.formFields,
    }, publicKey)).toBe(true);
  });

  it("formats Alipay timestamps in Asia/Shanghai and rejects missing private keys", () => {
    expect(formatAlipayTimestamp(new Date("2026-07-28T02:30:45.000Z"))).toBe("2026-07-28 10:30:45");
    expect(() => signAlipayFields({ app_id: "1" }, "")).toThrow("private key");
  });

  it("loads application and platform keys from protected files", () => {
    const applicationKeys = generateKeyPairSync("rsa", {
      modulusLength: 2048,
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
      publicKeyEncoding: { type: "spki", format: "pem" },
    });
    const keyDir = mkdtempSync(join(tmpdir(), "youshu-alipay-"));
    const privateKeyPath = join(keyDir, "app-private-key.pem");
    const platformKeyPath = join(keyDir, "alipay-public-key.pem");
    writeFileSync(privateKeyPath, applicationKeys.privateKey, { mode: 0o600 });
    writeFileSync(platformKeyPath, applicationKeys.publicKey, { mode: 0o600 });

    const provider = createAlipayPagePayProvider({
      env: {
        ALIPAY_APP_ID: "2026000000000000",
        ALIPAY_APP_PRIVATE_KEY_FILE: privateKeyPath,
        ALIPAY_PUBLIC_KEY_FILE: platformKeyPath,
        PUBLIC_SITE_URL: "https://dongfangyoushu.com.cn",
      },
      now: () => new Date("2026-07-28T02:30:45.000Z"),
    });
    const checkout = provider.createCheckout({
      orderNo: "YS202607280001",
      amount: "29.90",
      subject: "有数｜个人结构报告",
    });

    expect(provider.isConfigured()).toBe(true);
    expect(verifyAlipaySignature({
      ...Object.fromEntries(new URL(checkout.gatewayUrl).searchParams),
      ...checkout.formFields,
    }, applicationKeys.publicKey)).toBe(true);
  });

  it("fails closed when a configured key file cannot be read", () => {
    expect(() => createAlipayPagePayProvider({
      env: {
        ALIPAY_APP_ID: "2026000000000000",
        ALIPAY_APP_PRIVATE_KEY_FILE: "/missing/alipay-private-key.pem",
      },
    })).toThrow("ALIPAY_APP_PRIVATE_KEY");
  });

  it("queries Alipay OpenAPI and verifies the signed response payload", async () => {
    const applicationKeys = generateKeyPairSync("rsa", {
      modulusLength: 2048,
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
      publicKeyEncoding: { type: "spki", format: "pem" },
    });
    const platformKeys = generateKeyPairSync("rsa", {
      modulusLength: 2048,
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
      publicKeyEncoding: { type: "spki", format: "pem" },
    });
    const payload = '{"code":"10000","msg":"Success","out_trade_no":"YS20260728ABCDEF1234567890","trade_status":"TRADE_SUCCESS","total_amount":"39.90"}';
    const responseSigner = createSign("RSA-SHA256");
    responseSigner.update(payload, "utf8");
    responseSigner.end();
    const responseSign = responseSigner.sign(platformKeys.privateKey, "base64");
    const rawResponse = `{"alipay_trade_query_response":${payload},"sign":${JSON.stringify(responseSign)}}`;
    const fetchImpl = vi.fn(async () => new Response(rawResponse, {
      status: 200,
      headers: { "Content-Type": "application/json" },
    }));
    const client = createAlipayOpenApiClient({
      env: {
        ALIPAY_APP_ID: "2026000000000000",
        ALIPAY_APP_PRIVATE_KEY: applicationKeys.privateKey,
        ALIPAY_PUBLIC_KEY: platformKeys.publicKey,
      },
      fetchImpl,
      now: () => new Date("2026-07-28T02:30:45.000Z"),
    });

    await expect(client.query("YS20260728ABCDEF1234567890")).resolves.toMatchObject({
      code: "10000",
      trade_status: "TRADE_SUCCESS",
      total_amount: "39.90",
    });
    const requestBody = new URLSearchParams(fetchImpl.mock.calls[0][1].body);
    expect(requestBody.get("method")).toBe("alipay.trade.query");
    expect(JSON.parse(requestBody.get("biz_content"))).toEqual({
      out_trade_no: "YS20260728ABCDEF1234567890",
    });
    expect(requestBody.get("sign")).toBeTruthy();
    expect(extractAlipayResponsePayload(rawResponse, "alipay_trade_query_response")).toBe(payload);
  });
});
