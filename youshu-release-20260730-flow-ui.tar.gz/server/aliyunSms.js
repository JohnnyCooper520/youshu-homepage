import DysmsapiModule, { SendSmsRequest } from "@alicloud/dysmsapi20170525";
import { Config } from "@alicloud/openapi-client";

function configurationError(message) {
  return Object.assign(new Error(message), { status: 503 });
}

export function createAliyunSmsSender({
  env = process.env,
  ClientClass = DysmsapiModule.default,
  ConfigClass = Config,
  RequestClass = SendSmsRequest,
} = {}) {
  let client;

  function settings() {
    const accessKeyId = String(env.ALIBABA_CLOUD_ACCESS_KEY_ID || "").trim();
    const accessKeySecret = String(env.ALIBABA_CLOUD_ACCESS_KEY_SECRET || "").trim();
    const signName = String(env.ALIYUN_SMS_SIGN_NAME || "").trim();
    const templateCode = String(env.ALIYUN_SMS_TEMPLATE_CODE || "").trim();
    if (!accessKeyId || !accessKeySecret || !signName || !templateCode) {
      throw configurationError("SMS delivery is not configured");
    }
    return { accessKeyId, accessKeySecret, signName, templateCode };
  }

  function smsClient(config) {
    if (!client) {
      client = new ClientClass(new ConfigClass({
        accessKeyId: config.accessKeyId,
        accessKeySecret: config.accessKeySecret,
        endpoint: "dysmsapi.aliyuncs.com",
      }));
    }
    return client;
  }

  return {
    async sendVerificationCode({ phone, code }) {
      const config = settings();
      try {
        const response = await smsClient(config).sendSms(new RequestClass({
          phoneNumbers: String(phone).replace(/^\+86/, ""),
          signName: config.signName,
          templateCode: config.templateCode,
          templateParam: JSON.stringify({ code }),
        }));
        const result = response?.body || response;
        if (result?.code !== "OK") {
          const error = new Error(`SMS provider rejected the request: ${result?.code || "UNKNOWN"}`);
          error.status = 502;
          throw error;
        }
        return { requestId: result.requestId || "", bizId: result.bizId || "" };
      } catch (error) {
        if (error.status) {
          throw error;
        }
        const wrapped = new Error("SMS delivery failed");
        wrapped.status = 502;
        wrapped.cause = error;
        throw wrapped;
      }
    },
  };
}
