export const paymentProductCatalog = Object.freeze({
  bazi: Object.freeze({
    productKey: "bazi",
    amount: "29.90",
    subject: "有数｜个人结构报告",
  }),
  question: Object.freeze({
    productKey: "question",
    amount: "29.90",
    subject: "有数｜一事分析",
  }),
  annual: Object.freeze({
    productKey: "annual",
    amount: "39.90",
    subject: "有数｜年度节奏报告",
  }),
});

export function getPaymentProduct(productKey) {
  const product = paymentProductCatalog[productKey];
  if (!product) {
    const error = new Error("Unsupported payment product");
    error.status = 400;
    throw error;
  }
  return product;
}
