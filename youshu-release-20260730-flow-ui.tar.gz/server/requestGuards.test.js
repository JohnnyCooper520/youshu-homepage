import { describe, expect, it } from "vitest";
import {
  createMemoryRateLimiter,
  enforceGenerationRateLimit,
  getRequestIdentity,
  validateGenerationInput,
} from "./requestGuards.js";

const validInput = {
  birthDate: "1988-01-14",
  birthTime: "11:25",
  language: "zh-CN",
  calendarType: "solar",
  gender: "male",
  ziHourConvention: "zi-chu",
  birthPlace: "长春",
};
const tomorrow = new Date();
tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
const futureBirthDate = tomorrow.toISOString().slice(0, 10);

describe("generation request guards", () => {
  it("accepts bounded generation input", () => {
    expect(() => validateGenerationInput(validInput, "bazi")).not.toThrow();
    expect(() => validateGenerationInput({
      ...validInput,
      question: "接下来半年适合换工作吗？",
      birthLongitude: 125.32,
    }, "question")).not.toThrow();
  });

  it.each([
    [{ ...validInput, birthDate: "2024-02-31" }, "birthDate"],
    [{ ...validInput, birthDate: futureBirthDate }, "birthDate"],
    [{ ...validInput, birthTime: "25:61" }, "birthTime"],
    [{ ...validInput, birthPlace: "城".repeat(81) }, "birthPlace"],
    [{ ...validInput, question: "问".repeat(501) }, "question"],
    [{ ...validInput, birthLongitude: 181 }, "birthLongitude"],
    [{ ...validInput, language: "fr" }, "language"],
  ])("rejects invalid or excessive input", (input, expectedMessage) => {
    expect(() => validateGenerationInput(input, "bazi")).toThrow(expectedMessage);
  });

  it("requires a question for one-matter reports", () => {
    expect(() => validateGenerationInput(validInput, "question")).toThrow("question is required");
  });

  it("uses the first forwarded address as the request identity", () => {
    const request = new Request("https://example.com/api/generate", {
      headers: { "x-forwarded-for": "203.0.113.5, 10.0.0.1" },
    });
    expect(getRequestIdentity(request)).toBe("203.0.113.5");
  });

  it("limits repeated generation attempts within one window", () => {
    let currentTime = 1_000;
    const limiter = createMemoryRateLimiter({
      maxRequests: 2,
      windowMs: 10_000,
      now: () => currentTime,
    });
    const request = new Request("https://example.com/api/generate", {
      headers: { "x-real-ip": "203.0.113.7" },
    });

    expect(() => enforceGenerationRateLimit(limiter, request)).not.toThrow();
    currentTime += 100;
    expect(() => enforceGenerationRateLimit(limiter, request)).not.toThrow();
    expect(() => enforceGenerationRateLimit(limiter, request)).toThrow(
      expect.objectContaining({ status: 429 }),
    );
  });
});
