import { randomBytes } from "node:crypto";
import { createClient } from "@supabase/supabase-js";
import { bearerToken } from "./referrals.js";

const CLIENT_REQUEST_ID_PATTERN = /^[A-Za-z0-9_-]{8,80}$/;
const ORDER_NO_PATTERN = /^YS\d{8}[A-F0-9]{16}$/;

function requestError(message, status = 400) {
  return Object.assign(new Error(message), { status });
}

function getAdminConfig(env = process.env) {
  return {
    url: env.SUPABASE_URL || env.VITE_SUPABASE_URL || "",
    serviceKey: env.SUPABASE_SERVICE_ROLE_KEY || env.SUPABASE_SERVICE_KEY || "",
  };
}

function formatDatePart(date) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date).reduce((result, part) => {
    result[part.type] = part.value;
    return result;
  }, {});
  return `${parts.year}${parts.month}${parts.day}`;
}

export function createPaymentOrderNo(date = new Date(), randomHex = randomBytes(8).toString("hex")) {
  return `YS${formatDatePart(date)}${String(randomHex).replace(/[^a-fA-F0-9]/g, "").slice(0, 16).padEnd(16, "0").toUpperCase()}`;
}

export function amountInCents(value) {
  if (!/^\d+(?:\.\d{1,2})?$/.test(String(value || ""))) {
    return null;
  }
  const [whole, decimal = ""] = String(value).split(".");
  return Number(whole) * 100 + Number(decimal.padEnd(2, "0"));
}

export function paymentAmountsMatch(left, right) {
  const leftCents = amountInCents(left);
  const rightCents = amountInCents(right);
  return leftCents !== null && leftCents === rightCents;
}

function publicOrder(row) {
  if (!row) {
    return null;
  }
  return {
    orderNo: row.order_no,
    productKey: row.product_key,
    subject: row.subject,
    amount: Number(row.amount).toFixed(2),
    currency: row.currency,
    status: row.status,
    providerTradeId: row.provider_trade_id || "",
    paidAt: row.paid_at || null,
    refundStatus: row.refund_status || "none",
    createdAt: row.created_at,
  };
}

const publicColumns = "order_no,product_key,subject,amount,currency,status,provider_trade_id,paid_at,refund_status,created_at";

export function createSupabasePaymentOrderStore({
  env = process.env,
  createSupabaseClient = createClient,
  now = () => new Date(),
  createOrderNo = () => createPaymentOrderNo(now()),
} = {}) {
  const config = getAdminConfig(env);
  let cachedClient = null;

  function adminClient() {
    if (!config.url || !config.serviceKey) {
      throw requestError("Supabase service role credentials are not configured", 503);
    }
    if (!cachedClient) {
      cachedClient = createSupabaseClient(config.url, config.serviceKey, {
        auth: { autoRefreshToken: false, persistSession: false },
      });
    }
    return cachedClient;
  }

  async function authenticate(accessToken) {
    if (!accessToken) {
      throw requestError("Authentication required", 401);
    }
    const client = adminClient();
    const { data, error } = await client.auth.getUser(accessToken);
    if (error || !data?.user?.id) {
      throw requestError("Invalid or expired session", 401);
    }
    return { client, user: data.user };
  }

  async function findExisting(client, userId, clientRequestId) {
    const { data, error } = await client
      .from("payment_orders")
      .select(publicColumns)
      .eq("user_id", userId)
      .eq("client_request_id", clientRequestId)
      .maybeSingle();
    if (error) {
      throw error;
    }
    return publicOrder(data);
  }

  return {
    async create({ accessToken, product, clientRequestId }) {
      if (!CLIENT_REQUEST_ID_PATTERN.test(String(clientRequestId || ""))) {
        throw requestError("A valid clientRequestId is required");
      }
      const { client, user } = await authenticate(accessToken);
      const existing = await findExisting(client, user.id, clientRequestId);
      if (existing) {
        return { order: existing, created: false };
      }

      const row = {
        order_no: createOrderNo(),
        client_request_id: clientRequestId,
        user_id: user.id,
        product_key: product.productKey,
        subject: product.subject,
        amount: product.amount,
        currency: "CNY",
        status: "created",
        provider: "alipay",
      };
      const { data, error } = await client
        .from("payment_orders")
        .insert([row])
        .select(publicColumns)
        .single();
      if (error) {
        if (error.code === "23505") {
          const racedOrder = await findExisting(client, user.id, clientRequestId);
          if (racedOrder) {
            return { order: racedOrder, created: false };
          }
        }
        throw error;
      }
      return { order: publicOrder(data), created: true };
    },

    async getForUser({ accessToken, orderNo }) {
      if (!ORDER_NO_PATTERN.test(String(orderNo || ""))) {
        throw requestError("A valid order number is required");
      }
      const { client, user } = await authenticate(accessToken);
      const { data, error } = await client
        .from("payment_orders")
        .select(publicColumns)
        .eq("order_no", orderNo)
        .eq("user_id", user.id)
        .maybeSingle();
      if (error) {
        throw error;
      }
      if (!data) {
        throw requestError("Order not found", 404);
      }
      return publicOrder(data);
    },

    async getForCallback(orderNo) {
      if (!ORDER_NO_PATTERN.test(String(orderNo || ""))) {
        throw requestError("A valid order number is required");
      }
      const client = adminClient();
      const { data, error } = await client
        .from("payment_orders")
        .select("*")
        .eq("order_no", orderNo)
        .maybeSingle();
      if (error) {
        throw error;
      }
      if (!data) {
        throw requestError("Order not found", 404);
      }
      return data;
    },

    async markPaid(order, fields) {
      if (order.status === "paid") {
        if (order.provider_trade_id && fields.trade_no && order.provider_trade_id !== fields.trade_no) {
          throw requestError("Alipay trade number mismatch", 409);
        }
        return publicOrder(order);
      }
      if (order.status !== "created") {
        throw requestError("Order is not payable", 409);
      }

      const client = adminClient();
      const safeNotification = {
        trade_status: fields.trade_status,
        gmt_payment: fields.gmt_payment || null,
        receipt_amount: fields.receipt_amount || null,
        buyer_pay_amount: fields.buyer_pay_amount || null,
        point_amount: fields.point_amount || null,
        invoice_amount: fields.invoice_amount || null,
      };
      const { data, error } = await client
        .from("payment_orders")
        .update({
          status: "paid",
          provider_trade_id: fields.trade_no || "",
          paid_at: fields.gmt_payment || now().toISOString(),
          raw_payment: safeNotification,
          updated_at: now().toISOString(),
        })
        .eq("order_no", order.order_no)
        .eq("status", "created")
        .select(publicColumns)
        .single();
      if (error) {
        throw error;
      }
      return publicOrder(data);
    },

    async markRefunded(order, result) {
      if (order.status === "refunded" && order.refund_status === "refunded") {
        return publicOrder(order);
      }
      if (order.status !== "paid") {
        throw requestError("Only a paid order can be refunded", 409);
      }
      const client = adminClient();
      const { data, error } = await client
        .from("payment_orders")
        .update({
          status: "refunded",
          refund_status: "refunded",
          refunded_amount: Number(order.amount).toFixed(2),
          raw_refund: {
            trade_no: result.trade_no || order.provider_trade_id || "",
            fund_change: result.fund_change || "",
            refund_fee: result.refund_fee || Number(order.amount).toFixed(2),
            gmt_refund_pay: result.gmt_refund_pay || null,
          },
          updated_at: now().toISOString(),
        })
        .eq("order_no", order.order_no)
        .eq("status", "paid")
        .select(publicColumns)
        .single();
      if (error) {
        throw error;
      }
      return publicOrder(data);
    },
  };
}

export function paymentAccessToken(request) {
  return bearerToken(request);
}
