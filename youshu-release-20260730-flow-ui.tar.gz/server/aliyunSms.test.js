import { describe, expect, it, vi } from "vitest";
import { createAliyunSmsSender } from "./aliyunSms.js";

class FakeConfig {
  constructor(settings) {
    Object.assign(this, settings);
  }
}

class FakeRequest {
  constructor(settings) {
    Object.assign(this, settings);
  }
}

describe("Aliyun SMS sender", () => {
  it("sends a six-digit code without the +86 prefix", async () => {
    const sendSms = vi.fn(async () => ({
      body: { code: "OK", requestId: "request-1", bizId: "biz-1" },
    }));
    class FakeClient {
      constructor(config) {
        expect(config).toEqual(expect.objectContaining({
          accessKeyId: "test-id",
          endpoint: "dysmsapi.aliyuncs.com",
        }));
      }

      sendSms(request) {
        return sendSms(request);
      }
    }
    const sender = createAliyunSmsSender({
      env: {
        ALIBABA_CLOUD_ACCESS_KEY_ID: "test-id",
        ALIBABA_CLOUD_ACCESS_KEY_SECRET: "test-secret",
        ALIYUN_SMS_SIGN_NAME: "有数",
        ALIYUN_SMS_TEMPLATE_CODE: "SMS_123456789",
      },
      ClientClass: FakeClient,
      ConfigClass: FakeConfig,
      RequestClass: FakeRequest,
    });

    await expect(sender.sendVerificationCode({
      phone: "+8613812345678",
      code: "123456",
    })).resolves.toEqual({ requestId: "request-1", bizId: "biz-1" });
    expect(sendSms).toHaveBeenCalledWith(expect.objectContaining({
      phoneNumbers: "13812345678",
      signName: "有数",
      templateCode: "SMS_123456789",
      templateParam: "{\"code\":\"123456\"}",
    }));
  });

  it("fails closed when SMS credentials are missing", async () => {
    const sender = createAliyunSmsSender({
      env: {},
      ClientClass: class {},
      ConfigClass: FakeConfig,
      RequestClass: FakeRequest,
    });

    await expect(sender.sendVerificationCode({
      phone: "+8613812345678",
      code: "123456",
    })).rejects.toMatchObject({ status: 503 });
  });
});
