import { describe, expect, it, vi } from "vitest";
import {
  amountInCents,
  createPaymentOrderNo,
  createSupabasePaymentOrderStore,
  paymentAmountsMatch,
} from "./paymentOrders.js";

describe("paymentOrders", () => {
  it("creates fixed-format order numbers and compares currency in cents", () => {
    expect(createPaymentOrderNo(new Date("2026-07-28T01:00:00.000Z"), "abcdef1234567890"))
      .toBe("YS20260728ABCDEF1234567890");
    expect(amountInCents("29.9")).toBe(2990);
    expect(paymentAmountsMatch("29.90", "29.9")).toBe(true);
    expect(paymentAmountsMatch("29.90", "39.90")).toBe(false);
  });

  it("creates an authenticated order and returns a safe public shape", async () => {
    const row = {
      order_no: "YS20260728ABCDEF1234567890",
      product_key: "annual",
      subject: "有数｜年度节奏报告",
      amount: "39.90",
      currency: "CNY",
      status: "created",
      provider_trade_id: null,
      paid_at: null,
      refund_status: "none",
      created_at: "2026-07-28T00:00:00.000Z",
    };
    const maybeSingle = vi.fn(async () => ({ data: null, error: null }));
    const existingEqClient = vi.fn(() => ({ maybeSingle }));
    const existingEqUser = vi.fn(() => ({ eq: existingEqClient }));
    const selectExisting = vi.fn(() => ({ eq: existingEqUser }));
    const single = vi.fn(async () => ({ data: row, error: null }));
    const selectInserted = vi.fn(() => ({ single }));
    const insert = vi.fn(() => ({ select: selectInserted }));
    const from = vi.fn(() => ({ select: selectExisting, insert }));
    const client = {
      auth: { getUser: vi.fn(async () => ({ data: { user: { id: "user-1" } }, error: null })) },
      from,
    };
    const store = createSupabasePaymentOrderStore({
      env: { SUPABASE_URL: "https://example.supabase.co", SUPABASE_SERVICE_ROLE_KEY: "service" },
      createSupabaseClient: vi.fn(() => client),
      createOrderNo: () => row.order_no,
    });

    const result = await store.create({
      accessToken: "token",
      product: { productKey: "annual", amount: "39.90", subject: row.subject },
      clientRequestId: "checkout_request_123",
    });

    expect(result).toEqual({
      created: true,
      order: {
        orderNo: row.order_no,
        productKey: "annual",
        subject: row.subject,
        amount: "39.90",
        currency: "CNY",
        status: "created",
        providerTradeId: "",
        paidAt: null,
        refundStatus: "none",
        createdAt: row.created_at,
      },
    });
    expect(insert).toHaveBeenCalledWith([
      expect.objectContaining({
        user_id: "user-1",
        product_key: "annual",
        amount: "39.90",
        client_request_id: "checkout_request_123",
      }),
    ]);
  });
});
