import { createClient } from "@supabase/supabase-js";

const VALID_PRODUCT_KEYS = new Set(["bazi", "annual", "question"]);
const REQUEST_ID_PATTERN = /^[A-Za-z0-9_-]{8,80}$/;

function getAdminConfig(env = process.env) {
  return {
    url: env.SUPABASE_URL || env.VITE_SUPABASE_URL || "",
    serviceKey: env.SUPABASE_SERVICE_ROLE_KEY || env.SUPABASE_SERVICE_KEY || "",
  };
}

function requestError(message, status) {
  const error = new Error(message);
  error.status = status;
  return error;
}

export function createSupabaseGenerationAccessStore({
  env = process.env,
  createSupabaseClient = createClient,
} = {}) {
  const config = getAdminConfig(env);
  let cachedClient = null;

  function adminClient() {
    if (!config.url || !config.serviceKey) {
      throw new Error("Supabase service role credentials are not configured");
    }
    if (!cachedClient) {
      cachedClient = createSupabaseClient(config.url, config.serviceKey, {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      });
    }
    return cachedClient;
  }

  async function authenticate(accessToken) {
    if (!accessToken) {
      throw requestError("Authentication required", 401);
    }
    const client = adminClient();
    const { data, error } = await client.auth.getUser(accessToken);
    if (error || !data?.user?.id) {
      throw requestError("Invalid or expired session", 401);
    }
    return { client, user: data.user };
  }

  return {
    async lookup({ accessToken, requestId }) {
      if (!REQUEST_ID_PATTERN.test(String(requestId || ""))) {
        throw requestError("A valid requestId is required", 400);
      }

      const { client, user } = await authenticate(accessToken);
      const { data, error } = await client
        .from("report_generation_reservations")
        .select("status,response,product_key,updated_at")
        .eq("request_id", requestId)
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) {
        throw error;
      }
      if (!data) {
        return { status: "missing" };
      }

      return {
        status: data.status,
        response: data.status === "completed" ? data.response : null,
        productKey: data.product_key,
        updatedAt: data.updated_at,
      };
    },

    async reserve({ accessToken, productKey, requestId }) {
      if (!VALID_PRODUCT_KEYS.has(productKey)) {
        throw requestError("Unsupported report product", 400);
      }
      if (!REQUEST_ID_PATTERN.test(String(requestId || ""))) {
        throw requestError("A valid requestId is required", 400);
      }

      const { client, user } = await authenticate(accessToken);
      const { data, error } = await client.rpc("reserve_report_entitlement", {
        p_user_id: user.id,
        p_product_key: productKey,
        p_request_id: requestId,
      });
      if (error) {
        throw error;
      }

      const result = data?.[0] || data || {};
      if (result.status === "completed" && result.response) {
        return {
          cachedResponse: result.response,
          reservationId: result.reservation_id,
          userId: user.id,
        };
      }
      if (result.status === "reserved" && result.is_new === true) {
        return {
          reservationId: result.reservation_id,
          userId: user.id,
        };
      }
      if (result.status === "reserved") {
        throw requestError("This report request is already being generated", 409);
      }
      if (result.status === "insufficient") {
        throw requestError("No report entitlement is available", 403);
      }
      if (result.status === "released") {
        throw requestError("This report request has already been released", 409);
      }
      if (result.status === "conflict") {
        throw requestError("This report requestId is already in use", 409);
      }
      throw new Error("Unable to reserve report entitlement");
    },

    async complete({ reservationId, userId, response }) {
      const client = adminClient();
      const { data, error } = await client.rpc("complete_report_generation", {
        p_reservation_id: reservationId,
        p_user_id: userId,
        p_response: response,
      });
      if (error) {
        throw error;
      }
      const result = data?.[0] || data || {};
      if (result.status !== "completed") {
        throw requestError("This report reservation is no longer active", 409);
      }
      return result;
    },

    async release({ reservationId, userId }) {
      const client = adminClient();
      const { data, error } = await client.rpc("release_report_entitlement", {
        p_reservation_id: reservationId,
        p_user_id: userId,
      });
      if (error) {
        throw error;
      }
      return data?.[0] || data;
    },
  };
}
