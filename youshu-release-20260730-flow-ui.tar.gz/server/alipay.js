import { createSign, createVerify } from "node:crypto";
import { readFileSync } from "node:fs";

const DEFAULT_GATEWAY = "https://openapi.alipay.com/gateway.do";

function configuredKey(env, valueName, fileName) {
  const inlineValue = env[valueName];
  if (inlineValue) {
    return inlineValue;
  }
  const configuredPath = String(env[fileName] || "").trim();
  if (!configuredPath) {
    return "";
  }
  try {
    return readFileSync(configuredPath, "utf8");
  } catch {
    throw Object.assign(new Error(`Unable to read ${valueName} from ${fileName}`), { status: 503 });
  }
}

function normalizePublicKey(publicKey) {
  if (!publicKey) {
    return "";
  }
  const normalized = String(publicKey).replace(/\\n/g, "\n").trim();
  if (normalized.includes("BEGIN PUBLIC KEY")) {
    return normalized;
  }
  const body = normalized.replace(/\s+/g, "").match(/.{1,64}/g)?.join("\n") || "";
  return `-----BEGIN PUBLIC KEY-----\n${body}\n-----END PUBLIC KEY-----`;
}

function normalizePrivateKey(privateKey) {
  if (!privateKey) {
    return "";
  }
  const normalized = String(privateKey).replace(/\\n/g, "\n").trim();
  if (normalized.includes("BEGIN PRIVATE KEY") || normalized.includes("BEGIN RSA PRIVATE KEY")) {
    return normalized;
  }
  const body = normalized.replace(/\s+/g, "").match(/.{1,64}/g)?.join("\n") || "";
  return `-----BEGIN PRIVATE KEY-----\n${body}\n-----END PRIVATE KEY-----`;
}

export function canonicalizeAlipayFields(fields) {
  return Object.entries(fields)
    .filter(([key, value]) => key !== "sign" && value !== undefined && value !== null && String(value) !== "")
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([key, value]) => `${key}=${value}`)
    .join("&");
}

export function signAlipayFields(fields, privateKey) {
  const pem = normalizePrivateKey(privateKey);
  if (!pem) {
    throw Object.assign(new Error("Alipay application private key is not configured"), { status: 503 });
  }

  const signer = createSign("RSA-SHA256");
  signer.update(canonicalizeAlipayFields(fields), "utf8");
  signer.end();
  return signer.sign(pem, "base64");
}

export function verifyAlipaySignature(fields, publicKey) {
  const sign = fields.sign;
  const pem = normalizePublicKey(publicKey);
  if (!sign || !pem) {
    return false;
  }

  const algorithm = fields.sign_type === "RSA" ? "RSA-SHA1" : "RSA-SHA256";
  const verifier = createVerify(algorithm);
  verifier.update(canonicalizeAlipayFields(fields), "utf8");
  verifier.end();

  try {
    return verifier.verify(pem, sign, "base64");
  } catch {
    return false;
  }
}

export function verifyAlipayPayload(payload, signature, publicKey) {
  const pem = normalizePublicKey(publicKey);
  if (!payload || !signature || !pem) {
    return false;
  }
  const verifier = createVerify("RSA-SHA256");
  verifier.update(payload, "utf8");
  verifier.end();
  try {
    return verifier.verify(pem, signature, "base64");
  } catch {
    return false;
  }
}

export function extractAlipayResponsePayload(rawJson, responseKey) {
  const marker = `"${responseKey}":`;
  const markerIndex = rawJson.indexOf(marker);
  if (markerIndex < 0) {
    return "";
  }
  let start = markerIndex + marker.length;
  while (/\s/.test(rawJson[start] || "")) {
    start += 1;
  }
  if (rawJson[start] !== "{") {
    return "";
  }

  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < rawJson.length; index += 1) {
    const character = rawJson[index];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (character === "\\") {
        escaped = true;
      } else if (character === '"') {
        inString = false;
      }
      continue;
    }
    if (character === '"') {
      inString = true;
    } else if (character === "{") {
      depth += 1;
    } else if (character === "}") {
      depth -= 1;
      if (depth === 0) {
        return rawJson.slice(start, index + 1);
      }
    }
  }
  return "";
}

export function createAlipayVerifier({ env = process.env } = {}) {
  const platformPublicKey = configuredKey(env, "ALIPAY_PUBLIC_KEY", "ALIPAY_PUBLIC_KEY_FILE");
  return (fields) => verifyAlipaySignature(fields, platformPublicKey);
}

export function formatAlipayTimestamp(date = new Date()) {
  const parts = new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(date).reduce((result, part) => {
    result[part.type] = part.value;
    return result;
  }, {});

  return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}:${parts.second}`;
}

export function createAlipayPagePayProvider({ env = process.env, now = () => new Date() } = {}) {
  const appId = String(env.ALIPAY_APP_ID || "").trim();
  const privateKey = configuredKey(env, "ALIPAY_APP_PRIVATE_KEY", "ALIPAY_APP_PRIVATE_KEY_FILE");
  const platformPublicKey = configuredKey(env, "ALIPAY_PUBLIC_KEY", "ALIPAY_PUBLIC_KEY_FILE");
  const publicSiteUrl = String(env.PUBLIC_SITE_URL || "https://dongfangyoushu.com.cn").replace(/\/+$/, "");
  const gatewayUrl = String(env.ALIPAY_GATEWAY_URL || DEFAULT_GATEWAY).trim();

  return {
    isConfigured() {
      return Boolean(appId && privateKey && platformPublicKey && publicSiteUrl);
    },

    createCheckout(order) {
      if (!appId || !privateKey) {
        throw Object.assign(new Error("Alipay checkout is not configured"), { status: 503 });
      }

      const fields = {
        app_id: appId,
        method: "alipay.trade.page.pay",
        format: "JSON",
        return_url: `${publicSiteUrl}/payment/result`,
        charset: "utf-8",
        sign_type: "RSA2",
        timestamp: formatAlipayTimestamp(now()),
        version: "1.0",
        notify_url: `${publicSiteUrl}/api/payments/alipay/notify`,
        biz_content: JSON.stringify({
          out_trade_no: order.orderNo,
          total_amount: order.amount,
          subject: order.subject,
          product_code: "FAST_INSTANT_TRADE_PAY",
          timeout_express: "15m",
        }),
      };
      const signedFields = {
        ...fields,
        sign: signAlipayFields(fields, privateKey),
      };
      const actionUrl = new URL(gatewayUrl);
      Object.entries(signedFields).forEach(([key, value]) => {
        if (key !== "biz_content") {
          actionUrl.searchParams.set(key, value);
        }
      });

      return {
        gatewayUrl: actionUrl.toString(),
        formFields: {
          biz_content: fields.biz_content,
        },
      };
    },
  };
}

export function createAlipayOpenApiClient({
  env = process.env,
  now = () => new Date(),
  fetchImpl = globalThis.fetch,
} = {}) {
  const appId = String(env.ALIPAY_APP_ID || "").trim();
  const privateKey = configuredKey(env, "ALIPAY_APP_PRIVATE_KEY", "ALIPAY_APP_PRIVATE_KEY_FILE");
  const platformPublicKey = configuredKey(env, "ALIPAY_PUBLIC_KEY", "ALIPAY_PUBLIC_KEY_FILE");
  const gatewayUrl = String(env.ALIPAY_GATEWAY_URL || DEFAULT_GATEWAY).trim();

  async function execute(method, bizContent) {
    if (!appId || !privateKey || !platformPublicKey || typeof fetchImpl !== "function") {
      throw Object.assign(new Error("Alipay OpenAPI is not configured"), { status: 503 });
    }
    const fields = {
      app_id: appId,
      method,
      format: "JSON",
      charset: "utf-8",
      sign_type: "RSA2",
      timestamp: formatAlipayTimestamp(now()),
      version: "1.0",
      biz_content: JSON.stringify(bizContent),
    };
    const response = await fetchImpl(gatewayUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded;charset=utf-8" },
      body: new URLSearchParams({
        ...fields,
        sign: signAlipayFields(fields, privateKey),
      }).toString(),
    });
    const raw = await response.text();
    if (!response.ok) {
      throw new Error(`Alipay OpenAPI HTTP ${response.status}`);
    }
    const parsed = JSON.parse(raw);
    const responseKey = `${method.replaceAll(".", "_")}_response`;
    const result = parsed[responseKey];
    const signedPayload = extractAlipayResponsePayload(raw, responseKey);
    if (!result || !verifyAlipayPayload(signedPayload, parsed.sign, platformPublicKey)) {
      throw new Error("Alipay OpenAPI response signature verification failed");
    }
    if (result.code !== "10000") {
      throw Object.assign(new Error(result.sub_msg || result.msg || "Alipay OpenAPI request failed"), {
        alipayCode: result.sub_code || result.code,
      });
    }
    return result;
  }

  return {
    isConfigured() {
      return Boolean(appId && privateKey && platformPublicKey && typeof fetchImpl === "function");
    },
    query(orderNo) {
      return execute("alipay.trade.query", { out_trade_no: orderNo });
    },
    refund({ orderNo, amount, reason = "" }) {
      return execute("alipay.trade.refund", {
        out_trade_no: orderNo,
        refund_amount: amount,
        out_request_no: `RF${orderNo}`,
        ...(reason ? { refund_reason: reason } : {}),
      });
    },
  };
}

export function parseAlipayPassbackParams(rawValue) {
  if (!rawValue) {
    return {};
  }

  try {
    return JSON.parse(rawValue);
  } catch {
    return Object.fromEntries(new URLSearchParams(rawValue));
  }
}
