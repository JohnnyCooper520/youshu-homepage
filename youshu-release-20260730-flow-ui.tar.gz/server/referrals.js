import { randomBytes } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

function getAdminConfig(env = process.env) {
  return {
    url: env.SUPABASE_URL || env.VITE_SUPABASE_URL || "",
    serviceKey: env.SUPABASE_SERVICE_ROLE_KEY || env.SUPABASE_SERVICE_KEY || "",
  };
}

function createReferralCode() {
  return randomBytes(6).toString("base64url").toUpperCase();
}

export function createSupabaseReferralStore({
  env = process.env,
  createSupabaseClient = createClient,
} = {}) {
  const config = getAdminConfig(env);

  function adminClient() {
    if (!config.url || !config.serviceKey) {
      throw new Error("Supabase service role credentials are not configured");
    }
    return createSupabaseClient(config.url, config.serviceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });
  }

  async function authenticate(accessToken) {
    if (!accessToken) {
      const error = new Error("Authentication required");
      error.status = 401;
      throw error;
    }
    const client = adminClient();
    const { data, error } = await client.auth.getUser(accessToken);
    if (error || !data?.user) {
      const authError = new Error("Invalid or expired session");
      authError.status = 401;
      throw authError;
    }
    return { client, user: data.user };
  }

  return {
    async getOrCreateCode(accessToken) {
      const { client, user } = await authenticate(accessToken);
      const existing = await client
        .from("referral_codes")
        .select("code")
        .eq("user_id", user.id)
        .maybeSingle();

      if (existing.error) {
        throw existing.error;
      }
      if (existing.data?.code) {
        return { code: existing.data.code };
      }

      for (let attempt = 0; attempt < 3; attempt += 1) {
        const code = createReferralCode();
        const inserted = await client
          .from("referral_codes")
          .insert({ user_id: user.id, code })
          .select("code")
          .single();
        if (!inserted.error) {
          return { code: inserted.data.code };
        }
        if (inserted.error.code !== "23505") {
          throw inserted.error;
        }
        const retryExisting = await client
          .from("referral_codes")
          .select("code")
          .eq("user_id", user.id)
          .maybeSingle();
        if (retryExisting.data?.code) {
          return { code: retryExisting.data.code };
        }
      }
      throw new Error("Unable to allocate a referral code");
    },

    async claim(accessToken, code) {
      const normalizedCode = String(code || "").trim().toUpperCase();
      if (!/^[A-Z0-9_-]{8,24}$/.test(normalizedCode)) {
        const error = new Error("Invalid referral code");
        error.status = 400;
        throw error;
      }

      const { client, user } = await authenticate(accessToken);
      const { data, error } = await client.rpc("claim_referral_reward", {
        p_code: normalizedCode,
        p_invitee_user_id: user.id,
      });
      if (error) {
        throw error;
      }
      return data?.[0] || data || { status: "ignored" };
    },
  };
}

export function bearerToken(request) {
  const authorization = request.headers.get("authorization") || "";
  const match = authorization.match(/^Bearer\s+(.+)$/i);
  return match?.[1]?.trim() || "";
}
