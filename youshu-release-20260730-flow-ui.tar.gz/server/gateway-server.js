import { createReadStream, existsSync, statSync } from "node:fs";
import { createServer, request as createHttpRequest } from "node:http";
import { extname, join, normalize } from "node:path";

const host = process.env.HOST || "127.0.0.1";
const port = Number(process.env.PORT || 8788);
const apiHost = process.env.API_HOST || "127.0.0.1";
const apiPort = Number(process.env.API_PORT || 8787);
const distDir = join(process.cwd(), "dist");

const contentTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
};

function proxyApi(request, response) {
  const proxyRequest = createHttpRequest(
    {
      hostname: apiHost,
      port: apiPort,
      path: request.url,
      method: request.method,
      headers: {
        ...request.headers,
        host: `${apiHost}:${apiPort}`,
      },
    },
    (proxyResponse) => {
      response.writeHead(proxyResponse.statusCode || 502, proxyResponse.headers);
      proxyResponse.pipe(response);
    },
  );

  proxyRequest.on("error", () => {
    response.writeHead(502, { "content-type": "application/json; charset=utf-8" });
    response.end(JSON.stringify({ error: "API service unavailable" }));
  });

  request.pipe(proxyRequest);
}

function serveFile(filePath, response) {
  response.writeHead(200, {
    "content-type": contentTypes[extname(filePath).toLowerCase()] || "application/octet-stream",
    "cache-control": extname(filePath) === ".html" ? "no-cache" : "public, max-age=31536000, immutable",
  });
  createReadStream(filePath).pipe(response);
}

const server = createServer(async (request, response) => {
  if (request.url?.startsWith("/api/")) {
    const proxyRequest = createHttpRequest(
      {
        hostname: apiHost,
        port: apiPort,
        path: request.url,
        method: request.method,
        headers: { ...request.headers, host: `${apiHost}:${apiPort}` },
      },
      (proxyResponse) => {
        response.writeHead(proxyResponse.statusCode || 502, proxyResponse.headers);
        proxyResponse.pipe(response);
      },
    );
    proxyRequest.on("error", () => {
      response.writeHead(502, { "content-type": "application/json; charset=utf-8" });
      response.end(JSON.stringify({ error: "API service unavailable" }));
    });
    request.pipe(proxyRequest);
    return;
  }

  const pathname = decodeURIComponent((request.url || "/").split("?")[0]);
  const safePath = normalize(pathname).replace(/^(\.\.(\/|\\|$))+/, "");
  const requestedPath = join(distDir, safePath);

  if (
    requestedPath.startsWith(distDir) &&
    existsSync(requestedPath) &&
    statSync(requestedPath).isFile()
  ) {
    serveFile(requestedPath, response);
    return;
  }

  const indexPath = join(distDir, "index.html");
  if (existsSync(indexPath)) {
    serveFile(indexPath, response);
    return;
  }

  response.writeHead(503, { "content-type": "text/plain; charset=utf-8" });
  response.end("Site build is not available.");
});

server.listen(port, host, () => {
  console.log(`Youshu web gateway listening on http://${host}:${port}`);
});
