import {
  createHash,
  createHmac,
  randomBytes,
  randomInt,
} from "node:crypto";
import { isIP } from "node:net";
import nodemailer from "nodemailer";
import { createAliyunSmsSender } from "./aliyunSms.js";
import { getPostgresPool, withTransaction } from "./postgres.js";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const CHINA_PHONE_PATTERN = /^1[3-9]\d{9}$/;
const CODE_TTL_MINUTES = 10;
const SESSION_TTL_DAYS = 30;

function requestError(message, status = 400) {
  return Object.assign(new Error(message), { status });
}

function normalizeEmail(value) {
  const email = String(value || "").trim().toLowerCase();
  if (!EMAIL_PATTERN.test(email) || email.length > 320) {
    throw requestError("A valid email address is required");
  }
  return email;
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

function codeHash(secret, email, code) {
  return createHmac("sha256", secret).update(`${email}\n${code}`).digest("hex");
}

function authSecret(env) {
  const secret = String(env.AUTH_CODE_SECRET || "");
  if (secret.length < 32) {
    throw requestError("AUTH_CODE_SECRET must contain at least 32 characters", 503);
  }
  return secret;
}

function databaseIp(value) {
  const ip = String(value || "").trim();
  return isIP(ip) ? ip : null;
}

function smtpTransport(env) {
  const host = String(env.SMTP_HOST || "").trim();
  const user = String(env.SMTP_USER || "").trim();
  const pass = String(env.SMTP_PASS || "");
  if (!host || !user || !pass) {
    throw requestError("Email delivery is not configured", 503);
  }
  return nodemailer.createTransport({
    host,
    port: Number(env.SMTP_PORT || 465),
    secure: env.SMTP_SECURE !== "false",
    auth: { user, pass },
    connectionTimeout: 8_000,
    greetingTimeout: 8_000,
    socketTimeout: 15_000,
  });
}

function publicUser(row) {
  return row
    ? {
        id: row.id,
        email: row.email || null,
        phone: row.phone || null,
      }
    : null;
}

export function createDomesticAuth({
  env = process.env,
  pool = getPostgresPool(env),
  now = () => new Date(),
  sendMail,
  sendSms,
} = {}) {
  async function deliverCode(email, code) {
    if (sendMail) {
      await sendMail({ email, code });
      return;
    }
    const transporter = smtpTransport(env);
    await transporter.sendMail({
      from: env.SMTP_FROM || env.SMTP_USER,
      to: email,
      subject: "有数登录验证码",
      text: `你的有数登录验证码是：${code}\n\n验证码 ${CODE_TTL_MINUTES} 分钟内有效。请勿转发给任何人。`,
      html: `<p>你的有数登录验证码是：</p><p style="font-size:28px;font-weight:700;letter-spacing:6px">${code}</p><p>验证码 ${CODE_TTL_MINUTES} 分钟内有效。请勿转发给任何人。</p>`,
    });
  }

  async function deliverSms(phone, code) {
    if (sendSms) {
      return sendSms({ phone, code });
    }
    return createAliyunSmsSender({ env }).sendVerificationCode({ phone, code });
  }

  return {
    async requestEmailCode({ email, ip }) {
      const normalized = normalizeEmail(email);
      const secret = authSecret(env);
      const recent = await pool.query(
        `select count(*)::int as count
         from auth.email_codes
         where email_normalized = $1
           and created_at > now() - interval '10 minutes'`,
        [normalized],
      );
      if (recent.rows[0].count >= 5) {
        throw requestError("Too many verification codes requested", 429);
      }

      const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
      const codeResult = await pool.query(
        `insert into auth.email_codes
          (email_normalized, code_hash, expires_at, requested_ip)
         values ($1, $2, now() + interval '${CODE_TTL_MINUTES} minutes', $3)
         returning id`,
        [normalized, codeHash(secret, normalized, code), databaseIp(ip)],
      );
      try {
        await deliverCode(normalized, code);
      } catch (error) {
        await pool.query(
          "update auth.email_codes set consumed_at = now() where id = $1",
          [codeResult.rows[0].id],
        ).catch(() => {});
        throw error;
      }
      return { ok: true };
    },

    async requestPhoneCode({ phone, ip }) {
      const normalized = normalizeChinaPhone(phone);
      const secret = authSecret(env);
      const recent = await pool.query(
        `select
           count(*) filter (where created_at > now() - interval '10 minutes')::int as count,
           count(*) filter (where created_at > now() - interval '24 hours')::int as daily_count,
           max(created_at) as latest_created_at
         from auth.phone_codes
         where phone_normalized = $1
           and created_at > now() - interval '24 hours'`,
        [normalized],
      );
      const limits = recent.rows[0];
      const latestCreatedAt = limits.latest_created_at
        ? new Date(limits.latest_created_at).getTime()
        : 0;
      if (
        limits.count >= 5
        || limits.daily_count >= 10
        || latestCreatedAt > now().getTime() - 60_000
      ) {
        throw requestError("Too many verification codes requested", 429);
      }

      const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
      const codeResult = await pool.query(
        `insert into auth.phone_codes
          (phone_normalized, code_hash, expires_at, requested_ip)
         values ($1, $2, now() + interval '${CODE_TTL_MINUTES} minutes', $3)
         returning id`,
        [
          normalized,
          codeHash(secret, normalized, code),
          databaseIp(ip),
        ],
      );
      try {
        const delivery = await deliverSms(normalized, code);
        await pool.query(
          "update auth.phone_codes set provider_request_id = $2 where id = $1",
          [codeResult.rows[0].id, delivery?.requestId || null],
        );
      } catch (error) {
        await pool.query(
          "update auth.phone_codes set consumed_at = now() where id = $1",
          [codeResult.rows[0].id],
        ).catch(() => {});
        throw error;
      }
      return { ok: true };
    },

    async verifyEmailCode({ email, code, ip, userAgent }) {
      const normalized = normalizeEmail(email);
      const token = String(code || "").replace(/\D/g, "");
      if (!/^\d{6}$/.test(token)) {
        throw requestError("A valid verification code is required");
      }
      const secret = authSecret(env);

      const verified = await withTransaction(pool, async (client) => {
        const codeResult = await client.query(
          `select id, code_hash, attempts, expires_at
           from auth.email_codes
           where email_normalized = $1
             and purpose = 'login'
             and consumed_at is null
           order by created_at desc
           limit 1
           for update`,
          [normalized],
        );
        const record = codeResult.rows[0];
        if (!record || new Date(record.expires_at) <= now() || record.attempts >= 6) {
          throw requestError("Verification code is invalid or expired", 401);
        }
        if (record.code_hash !== codeHash(secret, normalized, token)) {
          await client.query(
            "update auth.email_codes set attempts = attempts + 1 where id = $1",
            [record.id],
          );
          return { invalid: true };
        }
        await client.query(
          "update auth.email_codes set consumed_at = now() where id = $1",
          [record.id],
        );

        const userResult = await client.query(
          `insert into auth.users (email, email_normalized, email_confirmed_at)
           values ($1, $1, now())
           on conflict (email_normalized) do update
           set email = excluded.email,
               email_confirmed_at = coalesce(auth.users.email_confirmed_at, now()),
               updated_at = now()
           returning id, email`,
          [normalized],
        );
        const sessionToken = randomBytes(32).toString("base64url");
        await client.query(
          `insert into auth.sessions
            (user_id, token_hash, expires_at, created_ip, user_agent)
           values ($1, $2, now() + interval '${SESSION_TTL_DAYS} days', $3, $4)`,
          [
            userResult.rows[0].id,
            sha256(sessionToken),
            databaseIp(ip),
            String(userAgent || "").slice(0, 500) || null,
          ],
        );
        return {
          accessToken: sessionToken,
          expiresIn: SESSION_TTL_DAYS * 24 * 60 * 60,
          user: publicUser(userResult.rows[0]),
        };
      });
      if (verified.invalid) {
        throw requestError("Verification code is invalid or expired", 401);
      }
      return verified;
    },

    async verifyPhoneCode({ phone, code, ip, userAgent }) {
      const normalized = normalizeChinaPhone(phone);
      const token = String(code || "").replace(/\D/g, "");
      if (!/^\d{6}$/.test(token)) {
        throw requestError("A valid verification code is required");
      }
      const secret = authSecret(env);

      const verified = await withTransaction(pool, async (client) => {
        const codeResult = await client.query(
          `select id, code_hash, attempts, expires_at
           from auth.phone_codes
           where phone_normalized = $1
             and purpose = 'login'
             and consumed_at is null
           order by created_at desc
           limit 1
           for update`,
          [normalized],
        );
        const record = codeResult.rows[0];
        if (!record || new Date(record.expires_at) <= now() || record.attempts >= 6) {
          throw requestError("Verification code is invalid or expired", 401);
        }
        if (record.code_hash !== codeHash(secret, normalized, token)) {
          await client.query(
            "update auth.phone_codes set attempts = attempts + 1 where id = $1",
            [record.id],
          );
          return { invalid: true };
        }
        await client.query(
          "update auth.phone_codes set consumed_at = now() where id = $1",
          [record.id],
        );

        const userResult = await client.query(
          `insert into auth.users (phone, phone_normalized, phone_confirmed_at)
           values ($1, $1, now())
           on conflict (phone_normalized) where phone_normalized is not null do update
           set phone = excluded.phone,
               phone_confirmed_at = coalesce(auth.users.phone_confirmed_at, now()),
               updated_at = now()
           returning id, email, phone`,
          [normalized],
        );
        const sessionToken = randomBytes(32).toString("base64url");
        await client.query(
          `insert into auth.sessions
            (user_id, token_hash, expires_at, created_ip, user_agent)
           values ($1, $2, now() + interval '${SESSION_TTL_DAYS} days', $3, $4)`,
          [
            userResult.rows[0].id,
            sha256(sessionToken),
            databaseIp(ip),
            String(userAgent || "").slice(0, 500) || null,
          ],
        );
        return {
          accessToken: sessionToken,
          expiresIn: SESSION_TTL_DAYS * 24 * 60 * 60,
          user: publicUser(userResult.rows[0]),
        };
      });
      if (verified.invalid) {
        throw requestError("Verification code is invalid or expired", 401);
      }
      return verified;
    },

    async authenticate(accessToken, { touch = true } = {}) {
      const token = String(accessToken || "").trim();
      if (!token) {
        throw requestError("Authentication required", 401);
      }
      const result = await pool.query(
        `select u.id, u.email, u.phone, s.id as session_id
         from auth.sessions s
         join auth.users u on u.id = s.user_id
         where s.token_hash = $1
           and s.revoked_at is null
           and s.expires_at > now()
           and u.disabled_at is null
         limit 1`,
        [sha256(token)],
      );
      if (!result.rows[0]) {
        throw requestError("Invalid or expired session", 401);
      }
      if (touch) {
        pool.query(
          "update auth.sessions set last_seen_at = now() where id = $1",
          [result.rows[0].session_id],
        ).catch(() => {});
      }
      return publicUser(result.rows[0]);
    },

    async signOut(accessToken) {
      const token = String(accessToken || "").trim();
      if (token) {
        await pool.query(
          "update auth.sessions set revoked_at = now() where token_hash = $1 and revoked_at is null",
          [sha256(token)],
        );
      }
      return { ok: true };
    },
  };
}

export function normalizeChinaPhone(value) {
  let phone = String(value || "").trim().replace(/[\s()-]/g, "");
  if (phone.startsWith("+86")) {
    phone = phone.slice(3);
  } else if (phone.startsWith("86") && phone.length === 13) {
    phone = phone.slice(2);
  }
  if (!CHINA_PHONE_PATTERN.test(phone)) {
    throw requestError("A valid mainland China mobile number is required");
  }
  return `+86${phone}`;
}
