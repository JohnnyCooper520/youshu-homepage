import { randomBytes } from "node:crypto";
import { buildEntitlementRows } from "./paymentEntitlements.js";
import { createPaymentOrderNo } from "./paymentOrders.js";
import { createDomesticAuth } from "./domesticAuth.js";
import { getPostgresPool } from "./postgres.js";

const CLIENT_REQUEST_ID_PATTERN = /^[A-Za-z0-9_-]{8,80}$/;
const ORDER_NO_PATTERN = /^YS\d{8}[A-F0-9]{16}$/;
const REQUEST_ID_PATTERN = /^[A-Za-z0-9_-]{8,80}$/;
const VALID_PRODUCT_KEYS = new Set(["bazi", "annual", "question"]);

function requestError(message, status = 400) {
  return Object.assign(new Error(message), { status });
}

function publicOrder(row) {
  if (!row) {
    return null;
  }
  return {
    orderNo: row.order_no,
    productKey: row.product_key,
    subject: row.subject,
    amount: Number(row.amount).toFixed(2),
    currency: row.currency,
    status: row.status,
    providerTradeId: row.provider_trade_id || "",
    paidAt: row.paid_at || null,
    refundStatus: row.refund_status || "none",
    createdAt: row.created_at,
  };
}

export function createDomesticStores({
  env = process.env,
  pool = getPostgresPool(env),
  auth = createDomesticAuth({ env, pool }),
  now = () => new Date(),
  createOrderNo = () => createPaymentOrderNo(now()),
} = {}) {
  async function userFor(accessToken) {
    return auth.authenticate(accessToken);
  }

  const paymentOrderStore = {
    async create({ accessToken, product, clientRequestId }) {
      if (!CLIENT_REQUEST_ID_PATTERN.test(String(clientRequestId || ""))) {
        throw requestError("A valid clientRequestId is required");
      }
      const user = await userFor(accessToken);
      const result = await pool.query(
        `with inserted as (
           insert into public.payment_orders
             (order_no, client_request_id, user_id, product_key, subject, amount, currency, status, provider)
           values ($1, $2, $3, $4, $5, $6, 'CNY', 'created', 'alipay')
           on conflict (user_id, client_request_id) do nothing
           returning *, true as was_created
         )
         select * from inserted
         union all
         select existing.*, false as was_created
         from public.payment_orders existing
         where existing.user_id = $3 and existing.client_request_id = $2
           and not exists (select 1 from inserted)
         limit 1`,
        [createOrderNo(), clientRequestId, user.id, product.productKey, product.subject, product.amount],
      );
      const row = result.rows[0];
      return { order: publicOrder(row), created: row.was_created === true };
    },

    async getForUser({ accessToken, orderNo }) {
      if (!ORDER_NO_PATTERN.test(String(orderNo || ""))) {
        throw requestError("A valid order number is required");
      }
      const user = await userFor(accessToken);
      const result = await pool.query(
        "select * from public.payment_orders where order_no = $1 and user_id = $2 limit 1",
        [orderNo, user.id],
      );
      if (!result.rows[0]) {
        throw requestError("Order not found", 404);
      }
      return publicOrder(result.rows[0]);
    },

    async getForCallback(orderNo) {
      if (!ORDER_NO_PATTERN.test(String(orderNo || ""))) {
        throw requestError("A valid order number is required");
      }
      const result = await pool.query(
        "select * from public.payment_orders where order_no = $1 limit 1",
        [orderNo],
      );
      if (!result.rows[0]) {
        throw requestError("Order not found", 404);
      }
      return result.rows[0];
    },

    async markPaid(order, fields) {
      if (order.status === "paid") {
        if (order.provider_trade_id && fields.trade_no && order.provider_trade_id !== fields.trade_no) {
          throw requestError("Alipay trade number mismatch", 409);
        }
        return publicOrder(order);
      }
      if (order.status !== "created") {
        throw requestError("Order is not payable", 409);
      }
      const safeNotification = {
        trade_status: fields.trade_status,
        gmt_payment: fields.gmt_payment || null,
        receipt_amount: fields.receipt_amount || null,
        buyer_pay_amount: fields.buyer_pay_amount || null,
        point_amount: fields.point_amount || null,
        invoice_amount: fields.invoice_amount || null,
      };
      const result = await pool.query(
        `update public.payment_orders
         set status = 'paid',
             provider_trade_id = $2,
             paid_at = $3,
             raw_payment = $4::jsonb,
             updated_at = now()
         where order_no = $1 and status = 'created'
         returning *`,
        [
          order.order_no,
          fields.trade_no || "",
          fields.gmt_payment || now().toISOString(),
          JSON.stringify(safeNotification),
        ],
      );
      if (!result.rows[0]) {
        throw requestError("Order is no longer payable", 409);
      }
      return publicOrder(result.rows[0]);
    },

    async markRefunded(order, refundResult) {
      if (order.status === "refunded" && order.refund_status === "refunded") {
        return publicOrder(order);
      }
      if (order.status !== "paid") {
        throw requestError("Only a paid order can be refunded", 409);
      }
      const rawRefund = {
        trade_no: refundResult.trade_no || order.provider_trade_id || "",
        fund_change: refundResult.fund_change || "",
        refund_fee: refundResult.refund_fee || Number(order.amount).toFixed(2),
        gmt_refund_pay: refundResult.gmt_refund_pay || null,
      };
      const result = await pool.query(
        `update public.payment_orders
         set status = 'refunded',
             refund_status = 'refunded',
             refunded_amount = amount,
             raw_refund = $2::jsonb,
             updated_at = now()
         where order_no = $1 and status = 'paid'
         returning *`,
        [order.order_no, JSON.stringify(rawRefund)],
      );
      if (!result.rows[0]) {
        throw requestError("Order is no longer refundable", 409);
      }
      return publicOrder(result.rows[0]);
    },
  };

  const entitlementStore = {
    async recordPayment(payment) {
      const rows = buildEntitlementRows(payment);
      for (const row of rows) {
        await pool.query(
          `insert into public.user_entitlements
            (user_id, product_key, status, included_quantity, used_quantity, starts_at, source, order_id, metadata)
           values ($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb)
           on conflict (order_id, product_key) do nothing`,
          [
            row.user_id,
            row.product_key,
            row.status,
            row.included_quantity,
            row.used_quantity,
            row.starts_at,
            row.source,
            row.order_id,
            JSON.stringify(row.metadata),
          ],
        );
      }
      return { inserted: rows.length };
    },

    async refundPayment(orderId) {
      if (!orderId) {
        throw requestError("An order id is required");
      }
      await pool.query(
        `update public.user_entitlements
         set status = 'refunded', updated_at = now()
         where order_id = $1`,
        [orderId],
      );
      return { refunded: true };
    },
  };

  const generationAccessStore = {
    async lookup({ accessToken, requestId }) {
      if (!REQUEST_ID_PATTERN.test(String(requestId || ""))) {
        throw requestError("A valid requestId is required");
      }
      const user = await userFor(accessToken);
      const result = await pool.query(
        `select status, response, product_key, updated_at
         from public.report_generation_reservations
         where request_id = $1 and user_id = $2
         limit 1`,
        [requestId, user.id],
      );
      const row = result.rows[0];
      if (!row) {
        return { status: "missing" };
      }
      return {
        status: row.status,
        response: row.status === "completed" ? row.response : null,
        productKey: row.product_key,
        updatedAt: row.updated_at,
      };
    },

    async reserve({ accessToken, productKey, requestId }) {
      if (!VALID_PRODUCT_KEYS.has(productKey)) {
        throw requestError("Unsupported report product");
      }
      if (!REQUEST_ID_PATTERN.test(String(requestId || ""))) {
        throw requestError("A valid requestId is required");
      }
      const user = await userFor(accessToken);
      const result = await pool.query(
        "select * from public.reserve_report_entitlement($1, $2, $3)",
        [user.id, productKey, requestId],
      );
      const row = result.rows[0] || {};
      if (row.status === "completed" && row.response) {
        return { cachedResponse: row.response, reservationId: row.reservation_id, userId: user.id };
      }
      if (row.status === "reserved" && row.is_new === true) {
        return { reservationId: row.reservation_id, userId: user.id };
      }
      if (row.status === "reserved") throw requestError("This report request is already being generated", 409);
      if (row.status === "insufficient") throw requestError("No report entitlement is available", 403);
      if (row.status === "released") throw requestError("This report request has already been released", 409);
      if (row.status === "conflict") throw requestError("This requestId is already in use", 409);
      throw new Error("Unable to reserve report entitlement");
    },

    async complete({ reservationId, userId, response }) {
      const result = await pool.query(
        "select * from public.complete_report_generation($1, $2, $3::jsonb)",
        [reservationId, userId, JSON.stringify(response)],
      );
      const row = result.rows[0] || {};
      if (row.status !== "completed") {
        throw requestError("This report reservation is no longer active", 409);
      }
      return row;
    },

    async release({ reservationId, userId }) {
      const result = await pool.query(
        "select * from public.release_report_entitlement($1, $2)",
        [reservationId, userId],
      );
      return result.rows[0] || {};
    },
  };

  const referralStore = {
    async getOrCreateCode(accessToken) {
      const user = await userFor(accessToken);
      const existing = await pool.query(
        "select code from public.referral_codes where user_id = $1 limit 1",
        [user.id],
      );
      if (existing.rows[0]) {
        return { code: existing.rows[0].code, rewardsEnabled: false };
      }
      for (let attempt = 0; attempt < 3; attempt += 1) {
        const code = randomBytes(6).toString("base64url").toUpperCase();
        const inserted = await pool.query(
          `insert into public.referral_codes (user_id, code)
           values ($1, $2)
           on conflict do nothing
           returning code`,
          [user.id, code],
        );
        if (inserted.rows[0]) {
          return { code: inserted.rows[0].code, rewardsEnabled: false };
        }
      }
      throw new Error("Unable to allocate a referral code");
    },

    async claim(accessToken) {
      await userFor(accessToken);
      return { status: "disabled" };
    },
  };

  const accountStore = {
    async listReports(accessToken) {
      const user = await userFor(accessToken);
      const result = await pool.query(
        `select report_payload
         from public.reports
         where user_id = $1
         order by created_at desc
         limit 100`,
        [user.id],
      );
      return result.rows.map((row) => row.report_payload);
    },

    async saveReport(accessToken, report) {
      const user = await userFor(accessToken);
      if (!report?.id || String(report.id).length > 100) {
        throw requestError("A valid report is required");
      }
      await pool.query(
        `insert into public.reports
          (user_id, report_key, report_type, title, report_payload)
         values ($1, $2, $3, $4, $5::jsonb)
         on conflict (user_id, report_key) where report_key is not null
         do update set
           report_type = excluded.report_type,
           title = excluded.title,
           report_payload = excluded.report_payload,
           updated_at = now()`,
        [
          user.id,
          String(report.id),
          ["bazi", "annual", "question"].includes(report.type) ? report.type : "unknown",
          String(report.title || "").slice(0, 300),
          JSON.stringify(report),
        ],
      );
      return { ok: true };
    },

    async deleteReport(accessToken, reportKey) {
      const user = await userFor(accessToken);
      await pool.query(
        "delete from public.reports where user_id = $1 and report_key = $2",
        [user.id, String(reportKey || "").slice(0, 100)],
      );
      return { ok: true };
    },

    async listEntitlements(accessToken) {
      const user = await userFor(accessToken);
      const result = await pool.query(
        `select product_key, included_quantity, used_quantity, status, expires_at
         from public.user_entitlements
         where user_id = $1
         order by created_at desc`,
        [user.id],
      );
      return result.rows;
    },

    async saveFeedback(accessToken, feedback) {
      const user = await userFor(accessToken);
      await pool.query(
        `insert into public.report_feedback
          (user_id, report_key, report_type, prompt_version, rating, reason_tags, comment, created_at, updated_at)
         values ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         on conflict (user_id, report_key)
         do update set
           report_type = excluded.report_type,
           prompt_version = excluded.prompt_version,
           rating = excluded.rating,
           reason_tags = excluded.reason_tags,
           comment = excluded.comment,
           updated_at = excluded.updated_at`,
        [
          user.id,
          String(feedback.reportId || "").slice(0, 100),
          ["bazi", "annual", "question"].includes(feedback.reportType) ? feedback.reportType : "unknown",
          String(feedback.promptVersion || "").slice(0, 80) || null,
          feedback.rating,
          Array.isArray(feedback.reasons) ? feedback.reasons.slice(0, 8) : [],
          String(feedback.comment || "").slice(0, 300) || null,
          feedback.createdAt || now().toISOString(),
          feedback.updatedAt || now().toISOString(),
        ],
      );
      return { ok: true };
    },
  };

  return {
    accountStore,
    auth,
    entitlementStore,
    generationAccessStore,
    paymentOrderStore,
    referralStore,
  };
}
