const DEFAULT_WINDOW_MS = 10 * 60 * 1000;
const DEFAULT_MAX_REQUESTS = 6;
const VALID_LANGUAGES = new Set(["zh-CN", "zh-TW", "en"]);
const VALID_CALENDARS = new Set(["solar", "lunar"]);
const VALID_GENDERS = new Set(["", "male", "female"]);
const VALID_ZI_HOUR_CONVENTIONS = new Set(["zi-chu", "midnight"]);

function requestError(message, status = 400, details = {}) {
  const error = new Error(message);
  error.status = status;
  Object.assign(error, details);
  return error;
}

function validDateParts(value) {
  const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) {
    return false;
  }

  const [, yearText, monthText, dayText] = match;
  const year = Number(yearText);
  const month = Number(monthText);
  const day = Number(dayText);
  const today = new Date();
  const currentYear = today.getUTCFullYear();
  const date = new Date(Date.UTC(year, month - 1, day));
  const todayUtc = Date.UTC(currentYear, today.getUTCMonth(), today.getUTCDate());

  return year >= 1900
    && year <= currentYear
    && date.getTime() <= todayUtc
    && date.getUTCFullYear() === year
    && date.getUTCMonth() === month - 1
    && date.getUTCDate() === day;
}

function assertTextLength(value, field, maxLength) {
  if (String(value || "").length > maxLength) {
    throw requestError(`${field} is too long`);
  }
}

export function validateGenerationInput(body = {}, type = "bazi") {
  if (!validDateParts(body.birthDate)) {
    throw requestError("birthDate must be a valid YYYY-MM-DD date between 1900 and today");
  }
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(String(body.birthTime || ""))) {
    throw requestError("birthTime must be a valid HH:mm time");
  }
  if (!VALID_LANGUAGES.has(body.language || "zh-CN")) {
    throw requestError("Unsupported report language");
  }
  if (!VALID_CALENDARS.has(body.calendarType || "solar")) {
    throw requestError("Unsupported calendar type");
  }
  if (!VALID_GENDERS.has(body.gender || "")) {
    throw requestError("Unsupported gender value");
  }
  if (!VALID_ZI_HOUR_CONVENTIONS.has(body.ziHourConvention || "zi-chu")) {
    throw requestError("Unsupported zi-hour convention");
  }

  assertTextLength(body.birthPlace, "birthPlace", 80);
  assertTextLength(body.focus, "focus", 80);
  assertTextLength(body.question, "question", 500);

  if (type === "question" && !String(body.question || "").trim()) {
    throw requestError("question is required for question reports");
  }

  if (body.birthLongitude !== undefined && body.birthLongitude !== null && body.birthLongitude !== "") {
    const longitude = Number(body.birthLongitude);
    if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
      throw requestError("birthLongitude must be between -180 and 180");
    }
  }

  if (body.coreProfile !== undefined) {
    const serializedProfile = typeof body.coreProfile === "string"
      ? body.coreProfile
      : JSON.stringify(body.coreProfile);
    if (serializedProfile.length > 12_000) {
      throw requestError("coreProfile is too long");
    }
  }
}

export function getRequestIdentity(request) {
  const forwardedFor = request.headers.get("x-forwarded-for");
  const firstForwarded = forwardedFor?.split(",")[0]?.trim();
  return firstForwarded
    || request.headers.get("x-real-ip")
    || request.headers.get("cf-connecting-ip")
    || "unknown";
}

export function createMemoryRateLimiter({
  windowMs = DEFAULT_WINDOW_MS,
  maxRequests = DEFAULT_MAX_REQUESTS,
  now = () => Date.now(),
} = {}) {
  const attempts = new Map();

  return {
    check(key) {
      const currentTime = now();
      const cutoff = currentTime - windowMs;
      const recent = (attempts.get(key) || []).filter((timestamp) => timestamp > cutoff);

      if (recent.length >= maxRequests) {
        const retryAfterMs = Math.max(1, recent[0] + windowMs - currentTime);
        attempts.set(key, recent);
        return {
          allowed: false,
          retryAfterSeconds: Math.ceil(retryAfterMs / 1000),
        };
      }

      recent.push(currentTime);
      attempts.set(key, recent);
      return { allowed: true, retryAfterSeconds: 0 };
    },
  };
}

export function enforceGenerationRateLimit(rateLimiter, request) {
  return enforceRequestRateLimit(
    rateLimiter,
    request,
    "generate",
    "Too many report requests. Please try again later.",
  );
}

export function enforceRequestRateLimit(rateLimiter, request, namespace, message) {
  const identity = getRequestIdentity(request);
  const result = rateLimiter.check(`${namespace}:${identity}`);
  if (!result.allowed) {
    throw requestError(message || "Too many requests. Please try again later.", 429, {
      retryAfterSeconds: result.retryAfterSeconds,
    });
  }
  return result;
}
