import pg from "pg";

const { Pool } = pg;
const pools = new Map();

function databaseConfig(env = process.env) {
  const connectionString = String(env.DATABASE_URL || "").trim();
  if (!connectionString) {
    const error = new Error("Domestic PostgreSQL is not configured");
    error.status = 503;
    throw error;
  }

  return {
    connectionString,
    ssl: env.DATABASE_SSL === "false"
      ? false
      : { rejectUnauthorized: env.DATABASE_SSL_REJECT_UNAUTHORIZED !== "false" },
    max: Number(env.DATABASE_POOL_MAX || 8),
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 8_000,
    statement_timeout: 15_000,
    application_name: "youshu",
  };
}

export function getPostgresPool(env = process.env) {
  const config = databaseConfig(env);
  const cacheKey = `${config.connectionString}|${JSON.stringify(config.ssl)}|${config.max}`;
  if (!pools.has(cacheKey)) {
    const pool = new Pool(config);
    pool.on("error", (error) => {
      console.error(JSON.stringify({
        event: "postgres_pool_error",
        error: error.message,
        at: new Date().toISOString(),
      }));
    });
    pools.set(cacheKey, pool);
  }
  return pools.get(cacheKey);
}

export async function withTransaction(pool, callback) {
  const client = await pool.connect();
  try {
    await client.query("begin");
    const result = await callback(client);
    await client.query("commit");
    return result;
  } catch (error) {
    await client.query("rollback");
    throw error;
  } finally {
    client.release();
  }
}

export async function closePostgresPools() {
  const closing = [...pools.values()].map((pool) => pool.end());
  pools.clear();
  await Promise.allSettled(closing);
}

