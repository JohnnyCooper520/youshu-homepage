import { describe, expect, it, vi } from "vitest";
import { createApiHandler, createMemoryKeyStore } from "./apiCore.js";

async function readJson(response) {
  return response.json();
}

function post(path, body) {
  return new Request(`http://localhost${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

function authorizedPost(path, body = {}) {
  return new Request(`http://localhost${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer test-access-token",
    },
    body: JSON.stringify(body),
  });
}

function formPost(path, fields) {
  return new Request(`http://localhost${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(fields).toString(),
  });
}

describe("apiCore", () => {
  it("reports backend DeepSeek key status without exposing it", async () => {
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: { DEEPSEEK_API_KEY: "sk-env" } }),
      createChat: vi.fn(),
    });

    expect(await readJson(await handler(new Request("http://localhost/api/deepseek/status")))).toEqual({
      configured: true,
      source: "env",
    });
  });

  it("rejects runtime DeepSeek key writes by default", async () => {
    const keyStore = createMemoryKeyStore({ env: {} });
    const handler = createApiHandler({ keyStore, createChat: vi.fn() });

    const response = await handler(post("/api/deepseek/key", { apiKey: "sk-test" }));
    const json = await readJson(response);

    expect(response.status).toBe(403);
    expect(json.error).toContain("disabled");
    expect(await readJson(await handler(new Request("http://localhost/api/deepseek/status")))).toEqual({
      configured: false,
      source: null,
    });
  });

  it("routes mainland phone code requests and verification through domestic auth", async () => {
    const authStore = {
      requestPhoneCode: vi.fn(async () => ({ ok: true })),
      verifyPhoneCode: vi.fn(async () => ({
        accessToken: "phone-session",
        expiresIn: 2_592_000,
        user: { id: "user-phone", email: null, phone: "+8613812345678" },
      })),
    };
    const handler = createApiHandler({ authStore });

    const requestResponse = await handler(post("/api/auth/phone/request", {
      phone: "+8613812345678",
    }));
    const verifyResponse = await handler(post("/api/auth/phone/verify", {
      phone: "+8613812345678",
      code: "123456",
    }));

    expect(requestResponse.status).toBe(202);
    expect(authStore.requestPhoneCode).toHaveBeenCalledWith(expect.objectContaining({
      phone: "+8613812345678",
    }));
    expect(verifyResponse.status).toBe(200);
    expect(await readJson(verifyResponse)).toEqual(expect.objectContaining({
      ok: true,
      accessToken: "phone-session",
      user: { id: "user-phone", email: null, phone: "+8613812345678" },
    }));
    expect(authStore.verifyPhoneCode).toHaveBeenCalledWith(expect.objectContaining({
      phone: "+8613812345678",
      code: "123456",
    }));
  });

  it("stores a runtime DeepSeek key only when explicitly enabled for ops", async () => {
    const keyStore = createMemoryKeyStore({ env: {} });
    const handler = createApiHandler({ keyStore, createChat: vi.fn(), allowRuntimeKey: true });

    const response = await handler(post("/api/deepseek/key", { apiKey: "sk-test" }));

    expect(response.status).toBe(200);
    expect(await readJson(response)).toEqual({
      configured: true,
      source: "runtime",
    });
    expect(await readJson(await handler(new Request("http://localhost/api/deepseek/status")))).toEqual({
      configured: true,
      source: "runtime",
    });
  });

  it("generates a personal structure report from birth data through DeepSeek", async () => {
    const createChat = vi.fn().mockResolvedValue({
      content: "# 个人结构报告\n先知己。",
      usage: { total_tokens: 88 },
    });
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: { DEEPSEEK_API_KEY: "sk-env" } }),
      createChat,
      requireGenerationAuth: false,
    });

    const response = await handler(
      post("/api/generate", {
        type: "bazi",
        language: "zh-CN",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        gender: "male",
        birthPlace: "长春",
      }),
    );
    const json = await readJson(response);

    expect(response.status).toBe(200);
    expect(json.type).toBe("bazi");
    expect(json.paipan.pillars.day.value).toBe("戊辰");
    expect(json.content).toContain("个人结构报告");
    expect(createChat).toHaveBeenCalledWith(
      expect.objectContaining({
        apiKey: "sk-env",
        messages: expect.arrayContaining([
          expect.objectContaining({ role: "system" }),
          expect.objectContaining({ content: expect.stringContaining("个人结构报告") }),
        ]),
      }),
    );
  });

  it("returns a short personalized preview without authentication or a model call", async () => {
    const createChat = vi.fn();
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat,
    });

    const response = await handler(post("/api/generate/preview", {
      type: "question",
      language: "zh-CN",
      birthDate: "1988-01-14",
      birthTime: "11:25",
      birthPlace: "长春",
      question: "接下来半年适合换工作吗？",
    }));
    const json = await readJson(response);

    expect(response.status).toBe(200);
    expect(json).toMatchObject({
      ok: true,
      type: "question",
      access: "preview",
    });
    expect(json.content).toContain("接下来半年适合换工作吗");
    expect(json.content.length).toBeLessThan(600);
    expect(createChat).not.toHaveBeenCalled();
  });

  it("generates annual rhythm report and question answer with separate prompt intent", async () => {
    const createChat = vi.fn().mockResolvedValueOnce({ content: "# 年度节奏", usage: {} }).mockResolvedValueOnce({
      content: "此事宜稳。",
      usage: {},
    });
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: { DEEPSEEK_API_KEY: "sk-env" } }),
      createChat,
      requireGenerationAuth: false,
    });

    await handler(
      post("/api/generate", {
        type: "annual",
        language: "zh-TW",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        birthPlace: "長春",
      }),
    );
    await handler(
      post("/api/generate", {
        type: "question",
        language: "en",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        birthPlace: "Changchun",
        question: "Should I change jobs?",
      }),
    );

    expect(createChat.mock.calls[0][0].messages[1].content).toContain("年度节奏报告");
    expect(createChat.mock.calls[0][0].messages[1].content).toContain("使用繁體中文");
    expect(createChat.mock.calls[1][0].messages[1].content).toContain("Should I change jobs?");
    expect(createChat.mock.calls[1][0].messages[1].content).toContain("Write the answer in English");
  });

  it("rejects generation when no backend key is configured", async () => {
    const handler = createApiHandler({ keyStore: createMemoryKeyStore({ env: {} }), createChat: vi.fn() });
    const response = await handler(post("/api/generate", { type: "bazi", birthDate: "1988-01-14", birthTime: "11:25" }));
    const json = await readJson(response);

    expect(response.status).toBe(400);
    expect(json.error).toContain("DeepSeek API key");
  });

  it("rejects oversized request bodies before generation", async () => {
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: { DEEPSEEK_API_KEY: "sk-env" } }),
      createChat: vi.fn(),
    });
    const response = await handler(
      post("/api/generate", {
        type: "bazi",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        focus: "x".repeat(129 * 1024),
      }),
    );

    expect(response.status).toBe(413);
    expect(await readJson(response)).toEqual({ error: "Request body is too large" });
  });

  it("rejects malformed and excessive generation fields before calling the model", async () => {
    const createChat = vi.fn();
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: { DEEPSEEK_API_KEY: "sk-env" } }),
      createChat,
      requireGenerationAuth: false,
    });

    const invalidDate = await handler(post("/api/generate", {
      type: "bazi",
      birthDate: "2026-02-31",
      birthTime: "11:25",
    }));
    const longQuestion = await handler(post("/api/generate", {
      type: "question",
      birthDate: "1988-01-14",
      birthTime: "11:25",
      question: "问".repeat(501),
    }));

    expect(invalidDate.status).toBe(400);
    expect((await readJson(invalidDate)).error).toContain("birthDate");
    expect(longQuestion.status).toBe(400);
    expect((await readJson(longQuestion)).error).toContain("question");
    expect(createChat).not.toHaveBeenCalled();
  });

  it("returns retry guidance when the generation rate limit is reached", async () => {
    const generationRateLimiter = {
      check: vi.fn(() => ({ allowed: false, retryAfterSeconds: 45 })),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: { DEEPSEEK_API_KEY: "sk-env" } }),
      createChat: vi.fn(),
      generationRateLimiter,
    });

    const response = await handler(post("/api/generate", {
      type: "bazi",
      birthDate: "1988-01-14",
      birthTime: "11:25",
    }));

    expect(response.status).toBe(429);
    expect(response.headers.get("Retry-After")).toBe("45");
    expect((await readJson(response)).error).toContain("Too many");
  });

  it("generates a local mock report without a DeepSeek key when explicitly enabled", async () => {
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      mockReports: true,
    });

    expect(await readJson(await handler(new Request("http://localhost/api/deepseek/status")))).toEqual({
      configured: true,
      source: "mock",
    });

    const response = await handler(
      post("/api/generate", {
        type: "bazi",
        language: "zh-CN",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        birthPlace: "长春",
      }),
    );
    const json = await readJson(response);

    expect(response.status).toBe(200);
    expect(json.type).toBe("bazi");
    expect(json.content).toContain("本地测试报告");
    expect(json.paipan.pillars.day.value).toBe("戊辰");
  });

  it("reserves and completes an authenticated report entitlement", async () => {
    const createChat = vi.fn().mockResolvedValue({
      content: "# 个人结构报告\n先知己。",
      usage: { total_tokens: 88 },
    });
    const generationAccessStore = {
      reserve: vi.fn().mockResolvedValue({
        reservationId: "reservation-1",
        userId: "user-1",
      }),
      complete: vi.fn().mockResolvedValue({ status: "completed" }),
      release: vi.fn(),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: { DEEPSEEK_API_KEY: "sk-env" } }),
      createChat,
      generationAccessStore,
    });

    const response = await handler(
      authorizedPost("/api/generate", {
        requestId: "request_12345",
        type: "bazi",
        language: "zh-CN",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        birthPlace: "长春",
      }),
    );
    const json = await readJson(response);

    expect(response.status).toBe(200);
    expect(json.content).toContain("个人结构报告");
    expect(generationAccessStore.reserve).toHaveBeenCalledWith({
      accessToken: "test-access-token",
      productKey: "bazi",
      requestId: "request_12345",
    });
    expect(generationAccessStore.complete).toHaveBeenCalledWith({
      reservationId: "reservation-1",
      userId: "user-1",
      response: expect.objectContaining({ ok: true, type: "bazi" }),
    });
    expect(generationAccessStore.release).not.toHaveBeenCalled();
  });

  it("looks up an authenticated generation request for refresh recovery", async () => {
    const generationAccessStore = {
      lookup: vi.fn().mockResolvedValue({
        status: "completed",
        response: { ok: true, type: "annual", content: "已完成" },
        productKey: "annual",
      }),
      reserve: vi.fn(),
      complete: vi.fn(),
      release: vi.fn(),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      generationAccessStore,
    });

    const response = await handler(new Request(
      "http://localhost/api/generate/status?requestId=request_annual_1",
      { headers: { Authorization: "Bearer test-access-token" } },
    ));

    expect(response.status).toBe(200);
    expect(await readJson(response)).toEqual({
      status: "completed",
      response: { ok: true, type: "annual", content: "已完成" },
      productKey: "annual",
    });
    expect(generationAccessStore.lookup).toHaveBeenCalledWith({
      accessToken: "test-access-token",
      requestId: "request_annual_1",
    });
  });

  it("releases a reserved report entitlement when generation fails", async () => {
    const generationAccessStore = {
      reserve: vi.fn().mockResolvedValue({
        reservationId: "reservation-2",
        userId: "user-1",
      }),
      complete: vi.fn(),
      release: vi.fn().mockResolvedValue({ status: "released" }),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: { DEEPSEEK_API_KEY: "sk-env" } }),
      createChat: vi.fn().mockRejectedValue(new Error("Model unavailable")),
      generationAccessStore,
    });

    const response = await handler(
      authorizedPost("/api/generate", {
        requestId: "request_67890",
        type: "question",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        question: "要不要换工作？",
      }),
    );

    expect(response.status).toBe(500);
    expect(await readJson(response)).toEqual({ error: "Model unavailable" });
    expect(generationAccessStore.complete).not.toHaveBeenCalled();
    expect(generationAccessStore.release).toHaveBeenCalledWith({
      reservationId: "reservation-2",
      userId: "user-1",
    });
  });

  it("rejects report generation without an authenticated session", async () => {
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: { DEEPSEEK_API_KEY: "sk-env" } }),
      createChat: vi.fn(),
    });

    const response = await handler(
      post("/api/generate", {
        requestId: "request_unauthenticated",
        type: "bazi",
        birthDate: "1988-01-14",
        birthTime: "11:25",
      }),
    );

    expect(response.status).toBe(401);
    expect(await readJson(response)).toEqual({ error: "Authentication required" });
  });

  it("opens paid entitlements from a verified Alipay async notification", async () => {
    const entitlementStore = {
      recordPayment: vi.fn().mockResolvedValue({ inserted: 2 }),
    };
    const alipayVerifier = vi.fn().mockReturnValue(true);
    const order = {
      order_no: "YS20260704ABCDEF1234567890",
      user_id: "00000000-0000-4000-8000-000000000001",
      product_key: "bazi",
      amount: "29.90",
      status: "created",
    };
    const paymentOrderStore = {
      getForCallback: vi.fn().mockResolvedValue(order),
      markPaid: vi.fn().mockResolvedValue({ ...order, status: "paid" }),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      entitlementStore,
      paymentOrderStore,
      alipayVerifier,
      env: { ALIPAY_APP_ID: "2026000000000000" },
    });

    const response = await handler(
      formPost("/api/payments/alipay/notify", {
        app_id: "2026000000000000",
        trade_status: "TRADE_SUCCESS",
        out_trade_no: order.order_no,
        trade_no: "2026070422000000000001",
        total_amount: "29.90",
        sign_type: "RSA2",
        sign: "valid-signature",
      }),
    );

    expect(response.status).toBe(200);
    expect(await response.text()).toBe("success");
    expect(alipayVerifier).toHaveBeenCalledWith(
      expect.objectContaining({
        app_id: "2026000000000000",
        out_trade_no: order.order_no,
        sign: "valid-signature",
      }),
    );
    expect(entitlementStore.recordPayment).toHaveBeenCalledWith(
      expect.objectContaining({
        provider: "alipay",
        orderId: order.order_no,
        providerTradeId: "2026070422000000000001",
        productKey: "bazi",
        userId: "00000000-0000-4000-8000-000000000001",
        amount: "29.90",
      }),
    );
    expect(paymentOrderStore.markPaid).toHaveBeenCalledWith(
      order,
      expect.objectContaining({ trade_no: "2026070422000000000001" }),
    );
  });

  it("creates a signed Alipay checkout for an authenticated product order", async () => {
    const order = {
      orderNo: "YS20260728ABCDEF1234567890",
      productKey: "annual",
      subject: "有数｜年度节奏报告",
      amount: "39.90",
      currency: "CNY",
      status: "created",
    };
    const paymentOrderStore = {
      create: vi.fn().mockResolvedValue({ order, created: true }),
      getForUser: vi.fn(),
    };
    const alipayPagePayProvider = {
      isConfigured: vi.fn().mockReturnValue(true),
      createCheckout: vi.fn().mockReturnValue({
        gatewayUrl: "https://openapi.alipay.com/gateway.do",
        formFields: { app_id: "2026000000000000", sign: "signed" },
      }),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      paymentOrderStore,
      alipayPagePayProvider,
    });

    const response = await handler(authorizedPost("/api/payments/alipay/orders", {
      productKey: "annual",
      clientRequestId: "checkout_request_123",
    }));
    const result = await readJson(response);

    expect(response.status).toBe(201);
    expect(result.order).toEqual(order);
    expect(result.checkout.formFields.sign).toBe("signed");
    expect(paymentOrderStore.create).toHaveBeenCalledWith({
      accessToken: "test-access-token",
      product: {
        productKey: "annual",
        amount: "39.90",
        subject: "有数｜年度节奏报告",
      },
      clientRequestId: "checkout_request_123",
    });
  });

  it("returns only the authenticated user's server-side payment status", async () => {
    const order = {
      orderNo: "YS20260728ABCDEF1234567890",
      productKey: "annual",
      amount: "39.90",
      status: "paid",
    };
    const paymentOrderStore = {
      create: vi.fn(),
      getForUser: vi.fn().mockResolvedValue(order),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      paymentOrderStore,
    });
    const response = await handler(new Request(
      `http://localhost/api/payments/orders/${order.orderNo}`,
      { headers: { Authorization: "Bearer test-access-token" } },
    ));

    expect(response.status).toBe(200);
    expect(await readJson(response)).toEqual({ ok: true, order });
    expect(paymentOrderStore.getForUser).toHaveBeenCalledWith({
      accessToken: "test-access-token",
      orderNo: order.orderNo,
    });
  });

  it("reconciles a paid Alipay trade when the async notification is delayed", async () => {
    const storedOrder = {
      order_no: "YS20260728ABCDEF1234567890",
      user_id: "user-1",
      product_key: "annual",
      amount: "39.90",
      status: "created",
    };
    const publicCreated = {
      orderNo: storedOrder.order_no,
      productKey: "annual",
      amount: "39.90",
      status: "created",
    };
    const publicPaid = { ...publicCreated, status: "paid" };
    const paymentOrderStore = {
      getForUser: vi.fn()
        .mockResolvedValueOnce(publicCreated)
        .mockResolvedValueOnce(publicPaid),
      getForCallback: vi.fn().mockResolvedValue(storedOrder),
      markPaid: vi.fn().mockResolvedValue(publicPaid),
    };
    const entitlementStore = { recordPayment: vi.fn().mockResolvedValue({ inserted: 1 }) };
    const alipayOpenApiClient = {
      isConfigured: vi.fn().mockReturnValue(true),
      query: vi.fn().mockResolvedValue({
        trade_status: "TRADE_SUCCESS",
        trade_no: "trade-1",
        total_amount: "39.90",
      }),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      paymentOrderStore,
      entitlementStore,
      alipayOpenApiClient,
      env: { ALIPAY_APP_ID: "2026000000000000" },
    });

    const response = await handler(new Request(
      `http://localhost/api/payments/orders/${storedOrder.order_no}`,
      { headers: { Authorization: "Bearer test-access-token" } },
    ));

    expect(await readJson(response)).toEqual({ ok: true, order: publicPaid });
    expect(alipayOpenApiClient.query).toHaveBeenCalledWith(storedOrder.order_no);
    expect(entitlementStore.recordPayment).toHaveBeenCalledWith(expect.objectContaining({
      orderId: storedOrder.order_no,
      userId: "user-1",
      productKey: "annual",
      amount: "39.90",
    }));
    expect(paymentOrderStore.markPaid).toHaveBeenCalled();
  });

  it("refunds a paid order only through the protected administration endpoint", async () => {
    const order = {
      order_no: "YS20260728ABCDEF1234567890",
      user_id: "user-1",
      product_key: "annual",
      amount: "39.90",
      status: "paid",
      refund_status: "none",
    };
    const refundedOrder = {
      orderNo: order.order_no,
      productKey: "annual",
      amount: "39.90",
      status: "refunded",
      refundStatus: "refunded",
    };
    const paymentOrderStore = {
      getForCallback: vi.fn().mockResolvedValue(order),
      markRefunded: vi.fn().mockResolvedValue(refundedOrder),
    };
    const entitlementStore = {
      refundPayment: vi.fn().mockResolvedValue({ refunded: true }),
    };
    const alipayOpenApiClient = {
      isConfigured: vi.fn().mockReturnValue(true),
      refund: vi.fn().mockResolvedValue({
        code: "10000",
        trade_no: "trade-1",
        fund_change: "Y",
        refund_fee: "39.90",
      }),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      paymentOrderStore,
      entitlementStore,
      alipayOpenApiClient,
      env: { PAYMENT_ADMIN_TOKEN: "admin-secret" },
    });
    const request = authorizedPost("/api/admin/payments/alipay/refunds", {
      orderNo: order.order_no,
      reason: "用户申请七日退款",
    });
    request.headers.set("x-payment-admin-token", "admin-secret");

    const response = await handler(request);

    expect(response.status).toBe(200);
    expect(await readJson(response)).toEqual({ ok: true, order: refundedOrder });
    expect(alipayOpenApiClient.refund).toHaveBeenCalledWith({
      orderNo: order.order_no,
      amount: "39.90",
      reason: "用户申请七日退款",
    });
    expect(entitlementStore.refundPayment).toHaveBeenCalledWith(order.order_no);
    expect(paymentOrderStore.markRefunded).toHaveBeenCalledWith(
      order,
      expect.objectContaining({ fund_change: "Y" }),
    );
  });

  it("rejects a signed Alipay notification when its amount differs from the stored order", async () => {
    const entitlementStore = { recordPayment: vi.fn() };
    const paymentOrderStore = {
      getForCallback: vi.fn().mockResolvedValue({
        order_no: "YS20260728ABCDEF1234567890",
        user_id: "user-1",
        product_key: "annual",
        amount: "39.90",
        status: "created",
      }),
      markPaid: vi.fn(),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      entitlementStore,
      paymentOrderStore,
      alipayVerifier: vi.fn().mockReturnValue(true),
      env: { ALIPAY_APP_ID: "2026000000000000" },
    });

    const response = await handler(formPost("/api/payments/alipay/notify", {
      app_id: "2026000000000000",
      trade_status: "TRADE_SUCCESS",
      out_trade_no: "YS20260728ABCDEF1234567890",
      trade_no: "trade-1",
      total_amount: "0.01",
      sign: "valid",
    }));

    expect(response.status).toBe(400);
    expect(await response.text()).toBe("fail");
    expect(paymentOrderStore.markPaid).not.toHaveBeenCalled();
    expect(entitlementStore.recordPayment).not.toHaveBeenCalled();
  });

  it("creates an authenticated referral code without returning user data", async () => {
    const referralStore = {
      getOrCreateCode: vi.fn().mockResolvedValue({ code: "INVITE123" }),
      claim: vi.fn(),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      referralStore,
    });

    const response = await handler(authorizedPost("/api/referrals/code"));

    expect(response.status).toBe(200);
    expect(await readJson(response)).toEqual({ code: "INVITE123" });
    expect(referralStore.getOrCreateCode).toHaveBeenCalledWith("test-access-token");
  });

  it("claims a referral through the authenticated one-time reward store", async () => {
    const referralStore = {
      getOrCreateCode: vi.fn(),
      claim: vi.fn().mockResolvedValue({ status: "rewarded" }),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      referralStore,
    });

    const response = await handler(authorizedPost("/api/referrals/claim", { code: "INVITE123" }));

    expect(response.status).toBe(200);
    expect(await readJson(response)).toEqual({ status: "rewarded" });
    expect(referralStore.claim).toHaveBeenCalledWith("test-access-token", "INVITE123");
  });

  it("rejects Alipay notifications when signature verification fails", async () => {
    const entitlementStore = {
      recordPayment: vi.fn(),
    };
    const handler = createApiHandler({
      keyStore: createMemoryKeyStore({ env: {} }),
      createChat: vi.fn(),
      entitlementStore,
      alipayVerifier: vi.fn().mockReturnValue(false),
      env: { ALIPAY_APP_ID: "2026000000000000" },
    });

    const response = await handler(
      formPost("/api/payments/alipay/notify", {
        app_id: "2026000000000000",
        trade_status: "TRADE_SUCCESS",
        out_trade_no: "YS202607040002",
        passback_params: JSON.stringify({
          userId: "00000000-0000-4000-8000-000000000001",
          productKey: "question",
        }),
        sign: "bad-signature",
      }),
    );

    expect(response.status).toBe(400);
    expect(await response.text()).toBe("fail");
    expect(entitlementStore.recordPayment).not.toHaveBeenCalled();
  });
});
