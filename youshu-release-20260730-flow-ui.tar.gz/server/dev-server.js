import http from "node:http";
import { defaultApiHandler } from "./apiCore.js";

const port = Number(process.env.API_PORT || 8787);
const MAX_REQUEST_BODY_BYTES = 128 * 1024;

function collectBody(req) {
  if (req.method === "GET" || req.method === "HEAD") {
    return Promise.resolve(undefined);
  }
  return new Promise((resolve, reject) => {
    const chunks = [];
    let receivedBytes = 0;
    let tooLarge = false;
    req.on("data", (chunk) => {
      receivedBytes += chunk.length;
      if (receivedBytes > MAX_REQUEST_BODY_BYTES) {
        tooLarge = true;
        chunks.length = 0;
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      if (tooLarge) {
        const error = new Error("Request body is too large");
        error.status = 413;
        reject(error);
        return;
      }
      const body = Buffer.concat(chunks);
      resolve(body.length > 0 ? body : undefined);
    });
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const body = await collectBody(req);
    const request = new Request(`http://127.0.0.1:${port}${req.url}`, {
      method: req.method,
      headers: req.headers,
      body,
    });
    const response = await defaultApiHandler(request);
    const responseBody = await response.arrayBuffer();

    res.statusCode = response.status;
    response.headers.forEach((value, key) => {
      res.setHeader(key, value);
    });
    res.end(Buffer.from(responseBody));
  } catch (error) {
    res.statusCode = error.status || 500;
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.end(JSON.stringify({
      error: error.status === 413 ? "Request body is too large" : "Internal server error",
    }));
  }
});

server.listen(port, "127.0.0.1", () => {
  console.log(`Youshu API listening on http://127.0.0.1:${port}`);
});
