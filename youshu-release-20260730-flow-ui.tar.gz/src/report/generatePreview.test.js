import { describe, expect, it } from "vitest";
import { calculateBazi } from "../paipan/calculateBazi.js";
import { generateReportPreview } from "./generatePreview.js";

const paipan = calculateBazi({
  birthDate: "1988-01-14",
  birthTime: "11:25",
  birthPlace: "长春",
});

describe("generateReportPreview", () => {
  it("creates a bounded personal preview from structured calculation data", () => {
    const content = generateReportPreview("bazi", paipan, { language: "zh-CN" });

    expect(content).toContain("# 先看见你的底色");
    expect(content).toContain("完整报告");
    expect(content.length).toBeLessThan(500);
  });

  it("keeps a one-matter preview tied to the submitted question", () => {
    const content = generateReportPreview("question", paipan, {
      language: "zh-CN",
      question: "接下来半年适合换工作吗？",
    });

    expect(content).toContain("接下来半年适合换工作吗");
    expect(content).toContain("风险边界");
  });

  it("supports English preview copy", () => {
    const content = generateReportPreview("annual", paipan, {
      language: "en",
      focus: "career direction",
    });

    expect(content).toContain("Where this year begins");
    expect(content).toContain("career direction");
  });
});
