import { describe, expect, it } from "vitest";
import { buildAnnualReportMessages } from "./annualReportPrompt.js";

const paipanResult = {
  input: {
    birth_date: "1988-01-14",
    birth_time: "11:25",
    birth_place: "长春",
  },
  pillars: {
    year: { value: "丁卯" },
    month: { value: "癸丑" },
    day: { value: "戊辰", day_master: "戊" },
    hour: { value: "戊午" },
  },
  elements: { wood: 1, fire: 2, earth: 4, metal: 0, water: 1 },
};

describe("buildAnnualReportMessages", () => {
  it("builds guarded annual report messages from paipan JSON", () => {
    const messages = buildAnnualReportMessages(paipanResult, { focus: "事业机会" });

    expect(messages).toHaveLength(2);
    expect(messages[0]).toMatchObject({ role: "system" });
    expect(messages[0].content).toContain("不承诺发财、复合、升职");
    expect(messages[0].content).toContain("文化参考和决策辅助");
    expect(messages[1].content).toContain("十二月回看");
    expect(messages[1].content).toContain("你正处在什么位置");
    expect(messages[1].content).toContain("你最关心的事");
    expect(messages[1].content).toContain("用户当前最关心的主题：事业机会");
    expect(messages[1].content).toContain("2-3 个可核对的现实表现");
    expect(messages[1].content).toContain("不写按月流水账");
    expect(messages[1].content).toContain("一致性锚点");
    expect(messages[1]).toMatchObject({ role: "user" });
    expect(messages[1].content).toContain("年度节奏报告");
    expect(messages[1].content).toContain('"birth_date": "1988-01-14"');
    expect(messages[1].content).toContain('"value": "戊辰"');
    expect(messages[0].content).toContain("Markdown");
  });

  it("supports simplified Chinese, traditional Chinese, and English report output", () => {
    const simplified = buildAnnualReportMessages(paipanResult, { language: "zh-CN" });
    const traditional = buildAnnualReportMessages(paipanResult, { language: "zh-TW" });
    const english = buildAnnualReportMessages(paipanResult, { language: "en" });

    expect(simplified[1].content).toContain("使用简体中文");
    expect(traditional[1].content).toContain("使用繁體中文");
    expect(english[1].content).toContain("Write the report in English");
  });
});
