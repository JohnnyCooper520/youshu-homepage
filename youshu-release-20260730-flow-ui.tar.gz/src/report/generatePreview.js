const ELEMENT_LABELS = {
  wood: "木",
  fire: "火",
  earth: "土",
  metal: "金",
  water: "水",
};

const DAY_STEM_TONES = {
  甲: ["更习惯先看方向，再投入行动", "当目标含糊时，容易把力气用在反复确认上"],
  乙: ["对环境和他人的变化很敏感，擅长顺势调整", "真正要留意的是别为了维持和谐而推迟自己的决定"],
  丙: ["更容易被明确、可见的目标带动", "节奏过快时，先分清热情与长期投入"],
  丁: ["判断常从细节和感受开始，适合在安静里把事情想透", "压力集中时，不必同时照顾所有人的期待"],
  戊: ["遇事倾向先稳住局面，再判断下一步", "稳定是优势，但也要防止把暂缓变成长期搁置"],
  己: ["擅长把复杂信息慢慢整理成可执行的次序", "边界不清时，容易替别人承担过多"],
  庚: ["在需要取舍时通常更看重效率和明确结果", "先留出核对空间，避免在信息不足时过早定论"],
  辛: ["对标准、品质和边界较为敏感", "不必等到所有条件都完美，先验证最关键的一步"],
  壬: ["能同时看到多个可能性，适合处理变化较多的局面", "选择过多时，需要主动收窄范围"],
  癸: ["观察细致，常能捕捉到别人忽略的信号", "不要只在心里推演，把判断转成一个可验证的小动作"],
};

const PREVIEW_HEADINGS = {
  "zh-CN": {
    bazi: "先看见你的底色",
    annual: "先看这一年的起点",
    question: "先看这件事的关键",
  },
  "zh-TW": {
    bazi: "先看見你的底色",
    annual: "先看這一年的起點",
    question: "先看這件事的關鍵",
  },
  en: {
    bazi: "A first look at your pattern",
    annual: "Where this year begins",
    question: "The key tension in this matter",
  },
};

function dominantElement(elements = {}) {
  return Object.entries(elements)
    .sort((left, right) => right[1] - left[1])[0]?.[0] || "earth";
}

function simplifiedPreview(type, paipan, { question = "", focus = "" } = {}) {
  const dayStem = paipan?.pillars?.day?.stem || "戊";
  const [strength, boundary] = DAY_STEM_TONES[dayStem] || DAY_STEM_TONES.戊;
  const element = ELEMENT_LABELS[dominantElement(paipan?.elements)] || "土";
  const cycle = paipan?.current_cycle?.liunian || "";

  if (type === "question") {
    const matter = String(question || "这件事").trim().slice(0, 42);
    return [
      `# ${PREVIEW_HEADINGS["zh-CN"].question}`,
      "",
      `你问的是“${matter}”。从当前结构看，重点不是立刻给自己一个绝对答案，而是先确认：这件事现在缺的是条件，还是你还没有接受取舍。`,
      "",
      `你的判断方式更接近“${strength}”。这能帮助你看清风险，但${boundary}。完整分析会继续拆开有利条件、风险边界，以及适合推进或暂缓的信号。`,
    ].join("\n");
  }

  if (type === "annual") {
    return [
      `# ${PREVIEW_HEADINGS["zh-CN"].annual}`,
      "",
      `这一阶段的关键词不是把所有事情同时做满，而是先确定哪一件事值得稳定投入。当前${cycle ? `${cycle}的节奏` : "节奏"}更适合先收拢重点，再逐步放大成果。`,
      "",
      `你的结构里“${element}”的表现较突出，通常意味着${strength}。完整报告会继续展开眼前三个月、半年转折和未来十二个月的观察节点，并结合你最关心的“${focus || "综合趋势"}”给出取舍建议。`,
    ].join("\n");
  }

  return [
    `# ${PREVIEW_HEADINGS["zh-CN"].bazi}`,
    "",
    `你更像是一个${strength}的人。面对重要选择时，你通常不会只看表面得失，而会先判断这件事能否长期站得住。`,
    "",
    `结构里“${element}”的表现较突出，这会让你的优势在稳定推进和持续判断中更容易被看见；同时也要留意：${boundary}。完整报告会继续展开你的内在拉扯、关系线索和更具体的用力方向。`,
  ].join("\n");
}

function traditionalPreview(content) {
  return content
    .replaceAll("这一", "這一")
    .replaceAll("这件事", "這件事")
    .replaceAll("现在", "現在")
    .replaceAll("绝对", "絕對")
    .replaceAll("还是", "還是")
    .replaceAll("没有", "沒有")
    .replaceAll("判断", "判斷")
    .replaceAll("帮助", "幫助")
    .replaceAll("继续", "繼續")
    .replaceAll("条件", "條件")
    .replaceAll("边界", "邊界")
    .replaceAll("结构", "結構")
    .replaceAll("节奏", "節奏")
    .replaceAll("适合", "適合")
    .replaceAll("展开", "展開")
    .replaceAll("综合趋势", "綜合趨勢")
    .replaceAll("选择", "選擇")
    .replaceAll("长期", "長期")
    .replaceAll("关系", "關係")
    .replaceAll("具体", "具體");
}

function englishPreview(type, paipan, { question = "", focus = "" } = {}) {
  const element = dominantElement(paipan?.elements);
  const emphasis = {
    wood: "direction and growth",
    fire: "clarity and visible momentum",
    earth: "stability and follow-through",
    metal: "standards and decisive boundaries",
    water: "adaptability and careful observation",
  }[element] || "steady judgment";

  if (type === "question") {
    const matter = String(question || "this matter").trim().slice(0, 64);
    return `# ${PREVIEW_HEADINGS.en.question}\n\nYou asked about “${matter}.” The useful first question is not whether the outcome is guaranteed, but whether the missing piece is an external condition or a trade-off you have not accepted yet.\n\nYour pattern emphasizes ${emphasis}. The full analysis continues with supportive conditions, risk boundaries, and concrete signals for moving or pausing.`;
  }

  if (type === "annual") {
    return `# ${PREVIEW_HEADINGS.en.annual}\n\nThe next phase is less about filling every available space and more about deciding what deserves sustained attention. Your pattern emphasizes ${emphasis}, so progress is more likely to come from a clear sequence than from simultaneous expansion.\n\nThe full report continues through the next three months, the six-month turn, and a twelve-month view around “${focus || "overall direction"}.”`;
  }

  return `# ${PREVIEW_HEADINGS.en.bazi}\n\nYou tend to look for what can hold over time before committing fully. Your pattern emphasizes ${emphasis}, which can become a practical strength when the situation is complex.\n\nThe full report continues with the inner tension behind this pattern, relationship signals, and specific ways to apply effort without overextending yourself.`;
}

export function generateReportPreview(type = "bazi", paipan, options = {}) {
  const language = options.language || "zh-CN";
  if (language === "en") {
    return englishPreview(type, paipan, options);
  }

  const content = simplifiedPreview(type, paipan, options);
  return language === "zh-TW" ? traditionalPreview(content) : content;
}
