import { useEffect, useRef, useState } from "react";
import { consumeEntitlement, getModeAccess, getProductStatus, grantProduct, normalizeEntitlements } from "./lib/entitlements.js";
import { loadCloudEntitlements } from "./lib/cloudEntitlements.js";
import { getSupabaseClient } from "./lib/supabaseClient.js";
import { deleteCloudReport, loadCloudReports, saveCloudReport } from "./lib/reportStore.js";
import { getStoredReportFeedback, saveCloudReportFeedback, saveStoredReportFeedback } from "./lib/reportFeedback.js";
import {
  buildPendingGeneration,
  clearPendingGeneration,
  loadPendingGeneration,
  savePendingGeneration,
} from "./lib/pendingGeneration.js";
import {
  buildReadingDraft,
  clearReadingDraft,
  loadReadingDraft,
  saveReadingDraft,
} from "./lib/readingDraft.js";
import { reportPromptVersion } from "./report/profileAnchor.js";
import { buildReferralUrl, downloadPoster, renderSharePoster, sharePosterStyles } from "./sharePoster.js";

const languageOptions = [
  { value: "zh-CN", label: "简体中文" },
  { value: "zh-TW", label: "繁體中文" },
  { value: "en", label: "English" },
];

const focusIds = ["career", "relationship", "emotion", "money", "other"];
const entryModeIds = ["bazi", "annual", "question"];
const legalPageIds = ["terms", "privacy", "refund", "contact", "license", "ai"];
const reportStorageKey = "youshu:last-report";
const reportArchiveStorageKey = "youshu:reports";
const entitlementStorageKey = "youshu:entitlements";
const pendingReferralStorageKey = "youshu:pending-referral";
const maxStoredReports = 30;
const companyNameZh = "北京一叶泛舟文化科技有限公司";
const companyNameEn = "Beijing Yiye Fanzhou Culture Technology Co., Ltd.";
const companyCreditCode = "91110114MACEGQFU0Q";
const supportEmail = "qinyuneo@gmail.com";
const icpNumber = "京ICP备2026045183号-1";
const icpUrl = "https://beian.miit.gov.cn/";
const businessRegistryUrl = "https://www.gsxt.gov.cn/";
const aiModelName = "DeepSeek-V4-Flash";
const aiServiceFilingName = "Deepseek Chat";
const aiServiceFilingNumber = "Beijing-DeepseekChat-202404280016";
const checkoutCopy = {
  "zh-CN": {
    kicker: "确认订单",
    title: "核对本次服务，再进入支付宝。",
    subtitle: "价格、交付与售后保持在同一笔订单里。",
    productLabel: "购买项目",
    amountLabel: "应付金额",
    deliveryLabel: "交付时间",
    deliveryValue: "支付成功后立即生成，完成后自动归档",
    refundLabel: "售后保障",
    refundValue: "报告生成并首次展示后 7 天内可申请退款",
    agreementPrefix: "我已阅读并同意",
    agreementJoin: "、",
    payAction: "支付宝支付",
    payingAction: "正在创建订单…",
    signInRequired: "支付前需要先登录，订单和报告才能绑定到你的账号。",
    signInAction: "前往登录",
    payNotice: "暂时无法创建支付宝订单，请稍后重试或联系客服。",
    secureNote: "支付结果以支付宝页面和订单记录为准。",
    back: "返回选择其他服务",
  },
  "zh-TW": {
    kicker: "確認訂單",
    title: "核對本次服務，再進入支付寶。",
    subtitle: "價格、交付與售後保持在同一筆訂單裡。",
    productLabel: "購買項目",
    amountLabel: "應付金額",
    deliveryLabel: "交付時間",
    deliveryValue: "支付成功後立即生成，完成後自動歸檔",
    refundLabel: "售後保障",
    refundValue: "報告生成並首次展示後 7 天內可申請退款",
    agreementPrefix: "我已閱讀並同意",
    agreementJoin: "、",
    payAction: "支付寶支付",
    payingAction: "正在建立訂單…",
    signInRequired: "支付前需要先登入，訂單和報告才能綁定到你的帳號。",
    signInAction: "前往登入",
    payNotice: "暫時無法建立支付寶訂單，請稍後重試或聯絡客服。",
    secureNote: "支付結果以支付寶頁面和訂單記錄為準。",
    back: "返回選擇其他服務",
  },
  en: {
    kicker: "Confirm order",
    title: "Review the service before continuing to Alipay.",
    subtitle: "Price, delivery, and support stay attached to one order.",
    productLabel: "Service",
    amountLabel: "Amount due",
    deliveryLabel: "Delivery",
    deliveryValue: "Generation starts immediately after payment and archives on completion",
    refundLabel: "Refund support",
    refundValue: "Refund requests are accepted within 7 days after first delivery",
    agreementPrefix: "I have read and agree to the",
    agreementJoin: ", ",
    payAction: "Pay with Alipay",
    payingAction: "Creating order…",
    signInRequired: "Sign in before payment so the order and report remain attached to your account.",
    signInAction: "Sign in",
    payNotice: "The Alipay order could not be created. Try again shortly or contact support.",
    secureNote: "Payment status is determined by Alipay and the order record.",
    back: "Choose another service",
  },
};

const paymentResultCopy = {
  "zh-CN": {
    kicker: "支付结果",
    confirmedKicker: "支付已确认",
    titles: {
      checking: "正在核对这笔付款",
      pending: "付款结果确认中",
      paid: "付款成功",
      signin: "登录后继续确认付款",
      failed: "订单查询暂时遇到问题",
      missing: "没有找到订单信息",
    },
    descriptions: {
      checking: "请稍候，我们正在向服务端确认支付宝的到账结果。",
      pending: "支付宝通知可能需要几秒，请稍后重新查询，不要重复付款。",
      paid: "订单已经绑定当前账号。你的完整报告已开始生成，完成后会自动打开并归入“我的报告”。",
      signin: "付款记录已经绑定账号。重新登录后会继续查询，不需要再次付款。",
      failed: "订单仍会保存在账号中。你可以重新查询，或进入“我的报告”查看。",
      missing: "请从支付宝完成页返回，或进入“我的报告”查看订单与报告。",
    },
    checking: "正在查询订单…",
    pending: "暂未确认到账。若你已付款，请等待几秒后再次查询，不要重复支付。",
    paid: "正在读取你刚才提交的信息并生成完整报告，请不要重复付款。",
    signInRequired: "登录状态已失效。请重新登录，系统会继续确认这笔订单。",
    failed: "无法查询这笔订单，请确认登录账号或联系客服。",
    missing: "缺少订单号，请从支付宝完成页返回或进入“我的报告”查看。",
    orderSummary: "付款明细",
    resultStatus: "订单状态",
    product: "购买内容",
    amount: "实付金额",
    account: "归属账号",
    accountBound: "已绑定当前账号",
    orderNo: "订单编号",
    delivery: "你的报告正在生成",
    deliveryLead: "接下来不用再操作",
    deliveryLeadText: "请保持本页打开。系统正在结合你刚才提交的信息撰写并校验完整内容，完成后会自动进入阅读页。",
    paidReceipt: "支付宝支付成功",
    progress: ["订单已绑定", "付款已确认", "报告生成中", "完成并归档"],
    progressDetails: [
      "购买记录已保存到当前账号",
      "支付宝到账结果已经核对",
      "正在撰写并校验完整内容",
      "生成后自动进入“我的报告”",
    ],
    assuranceTitle: "订单与报告已经绑定",
    assuranceText: "购买记录已经保存到当前账号。生成完成后会自动归入“我的报告”，之后更换设备也可以找回。",
    orderSafeTitle: "订单记录仍然保留",
    orderSafeText: "如果你已经完成付款，请不要重复支付。重新查询，或进入“我的报告”查看这笔订单。",
    checkAgain: "重新查询",
    signIn: "重新登录并继续",
    continue: "继续生成报告",
    generating: "正在生成报告…",
    retryDelivery: "重新生成报告",
    restoreDraft: "补充资料并生成",
    confirmed: "已确认",
    keepOpen: "保持页面打开，报告完成后会自动进入阅读页。",
    restoreDraftStatus: "付款已经完成，但这台设备没有找到刚才的生成资料。请补充资料，订单不会重复收费。",
    restoreDraftStep: "等待补充资料",
    reports: "订单与我的报告",
    support: "退款与售后",
  },
  "zh-TW": {
    kicker: "支付結果",
    confirmedKicker: "支付已確認",
    titles: {
      checking: "正在核對這筆付款",
      pending: "付款結果確認中",
      paid: "付款成功",
      signin: "登入後繼續確認付款",
      failed: "訂單查詢暫時遇到問題",
      missing: "沒有找到訂單資訊",
    },
    descriptions: {
      checking: "請稍候，我們正在向服務端確認支付寶的到帳結果。",
      pending: "支付寶通知可能需要幾秒，請稍後重新查詢，不要重複付款。",
      paid: "訂單已經綁定目前帳號。你的完整報告已開始生成，完成後會自動開啟並歸入「我的報告」。",
      signin: "付款記錄已經綁定帳號。重新登入後會繼續查詢，不需要再次付款。",
      failed: "訂單仍會保存在帳號中。你可以重新查詢，或進入「我的報告」查看。",
      missing: "請從支付寶完成頁返回，或進入「我的報告」查看訂單與報告。",
    },
    checking: "正在查詢訂單…",
    pending: "暫未確認到帳。若已付款，請等待幾秒後再次查詢，不要重複支付。",
    paid: "正在讀取你剛才提交的資訊並生成完整報告，請不要重複付款。",
    signInRequired: "登入狀態已失效。請重新登入，系統會繼續確認這筆訂單。",
    failed: "無法查詢這筆訂單，請確認登入帳號或聯絡客服。",
    missing: "缺少訂單號，請從支付寶完成頁返回或進入「我的報告」查看。",
    orderSummary: "付款明細",
    resultStatus: "訂單狀態",
    product: "購買內容",
    amount: "實付金額",
    account: "歸屬帳號",
    accountBound: "已綁定目前帳號",
    orderNo: "訂單編號",
    delivery: "你的報告正在生成",
    deliveryLead: "接下來不用再操作",
    deliveryLeadText: "請保持本頁開啟。系統正在結合你剛才提交的資訊撰寫並校驗完整內容，完成後會自動進入閱讀頁。",
    paidReceipt: "支付寶付款成功",
    progress: ["訂單已綁定", "付款已確認", "報告生成中", "完成並歸檔"],
    progressDetails: [
      "購買記錄已保存到目前帳號",
      "支付寶到帳結果已經核對",
      "正在撰寫並校驗完整內容",
      "生成後自動進入「我的報告」",
    ],
    assuranceTitle: "訂單與報告已經綁定",
    assuranceText: "購買記錄已經保存到目前帳號。生成完成後會自動歸入「我的報告」，之後更換裝置也可以找回。",
    orderSafeTitle: "訂單記錄仍然保留",
    orderSafeText: "如果已經完成付款，請不要重複支付。重新查詢，或進入「我的報告」查看這筆訂單。",
    checkAgain: "重新查詢",
    signIn: "重新登入並繼續",
    continue: "繼續生成報告",
    generating: "正在生成報告…",
    retryDelivery: "重新生成報告",
    restoreDraft: "補充資料並生成",
    confirmed: "已確認",
    keepOpen: "保持頁面開啟，報告完成後會自動進入閱讀頁。",
    restoreDraftStatus: "付款已經完成，但這台裝置沒有找到剛才的生成資料。請補充資料，訂單不會重複收費。",
    restoreDraftStep: "等待補充資料",
    reports: "訂單與我的報告",
    support: "退款與售後",
  },
  en: {
    kicker: "Payment result",
    confirmedKicker: "Payment confirmed",
    titles: {
      checking: "Confirming this payment",
      pending: "Payment confirmation in progress",
      paid: "Payment complete",
      signin: "Sign in to continue checking the payment",
      failed: "We could not check the order",
      missing: "Order information is missing",
    },
    descriptions: {
      checking: "Please wait while the server confirms the Alipay result.",
      pending: "Alipay's notification may take a few seconds. Check again shortly and do not pay twice.",
      paid: "This order is attached to your account. Your full report is now being prepared and will open automatically when it is ready.",
      signin: "The payment remains attached to your account. Sign in again to continue; you do not need to pay twice.",
      failed: "The order remains saved to your account. Check again or open My reports.",
      missing: "Return from Alipay or open My reports to find your order and reports.",
    },
    checking: "Checking order…",
    pending: "Payment has not been confirmed yet. If you paid, wait a few seconds and check again. Do not pay twice.",
    paid: "We are reading the details you submitted and preparing the full report. Do not pay again.",
    signInRequired: "Your session has expired. Sign in again and we will continue checking this order.",
    failed: "This order cannot be checked. Confirm the signed-in account or contact support.",
    missing: "The order number is missing. Return from Alipay or open My reports.",
    orderSummary: "Payment details",
    resultStatus: "Order status",
    product: "Purchase",
    amount: "Amount paid",
    account: "Account",
    accountBound: "Attached to this account",
    orderNo: "Order number",
    delivery: "Your report is being prepared",
    deliveryLead: "Nothing else is needed",
    deliveryLeadText: "Keep this page open while we write and check the full report from the details you submitted. It will open automatically when ready.",
    paidReceipt: "Paid with Alipay",
    progress: ["Order attached", "Payment confirmed", "Generating report", "Saved to My reports"],
    progressDetails: [
      "The purchase is saved to this account",
      "The Alipay result has been verified",
      "The full report is being written and checked",
      "It will open and save to My reports",
    ],
    assuranceTitle: "Your order and report are linked",
    assuranceText: "The purchase is saved to this account. Once generated, the report is saved automatically in My reports and can be restored on another device.",
    orderSafeTitle: "The order record is still saved",
    orderSafeText: "If you have already paid, do not pay again. Check again or open My reports to find this order.",
    checkAgain: "Check again",
    signIn: "Sign in and continue",
    continue: "Continue generating",
    generating: "Generating report…",
    retryDelivery: "Generate again",
    restoreDraft: "Add details and generate",
    confirmed: "Confirmed",
    keepOpen: "Keep this page open. The report will open automatically when it is ready.",
    restoreDraftStatus: "Payment is complete, but the report details were not found on this device. Add them again; you will not be charged twice.",
    restoreDraftStep: "Waiting for details",
    reports: "Orders & My reports",
    support: "Refunds & support",
  },
};

const complianceCopy = {
  "zh-CN": {
    license: {
      title: "营业执照信息公示",
      intro: "以下为有数网站经营主体的市场主体登记信息。",
      sections: [
        ["企业名称", companyNameZh],
        ["统一社会信用代码", companyCreditCode],
        ["网站名称", "有数｜东方文化人生参考"],
        ["网站备案", icpNumber],
        ["信息核验", "可通过国家企业信用信息公示系统查询市场主体登记信息；如页面信息发生变更，我们会及时更新。"],
      ],
    },
    ai: {
      title: "AI 模型与内容标识说明",
      intro: "有数使用结构化规则与生成式人工智能共同整理报告，并明确标识生成内容。",
      sections: [
        ["当前模型", `${aiModelName}，通过 DeepSeek 官方 API 调用。`],
        ["已备案服务", `${aiServiceFilingName}，生成式人工智能服务备案号：${aiServiceFilingNumber}。`],
        ["文本标识", "每份报告在内容周边持续显示“内容由人工智能生成，仅供参考”，不将模型输出包装为确定事实。"],
        ["图片标识", "分享海报包含可见“AI生成内容”文字，下载的 PNG 文件同时写入生成属性、服务提供者和内容编号等元数据信息。"],
        ["用户分享责任", "对外发布或转发生成内容时，请保留 AI 标识，并按发布平台要求主动声明内容包含 AI 生成或辅助创作。不得删除、篡改或隐匿标识。"],
      ],
    },
  },
  "zh-TW": {
    license: {
      title: "營業執照資訊公示",
      intro: "以下為有數網站營運主體的市場主體登記資訊。",
      sections: [
        ["企業名稱", companyNameZh],
        ["統一社會信用代碼", companyCreditCode],
        ["網站名稱", "有數｜東方文化人生參考"],
        ["網站備案", icpNumber],
        ["資訊核驗", "可透過國家企業信用資訊公示系統查詢市場主體登記資訊。"],
      ],
    },
    ai: {
      title: "AI 模型與內容標識說明",
      intro: "有數使用結構化規則與生成式人工智慧共同整理報告，並明確標識生成內容。",
      sections: [
        ["目前模型", `${aiModelName}，透過 DeepSeek 官方 API 呼叫。`],
        ["已備案服務", `${aiServiceFilingName}，生成式人工智慧服務備案號：${aiServiceFilingNumber}。`],
        ["文字與圖片標識", "每份報告和分享海報均顯示 AI 生成提示；下載的 PNG 檔案同時寫入生成屬性、服務提供者和內容編號等中繼資料。"],
        ["分享責任", "對外發布或轉發時請保留 AI 標識，並依發布平台要求主動聲明。"],
      ],
    },
  },
  en: {
    license: {
      title: "Business registration disclosure",
      intro: "Registration details for the entity operating Youshu.",
      sections: [
        ["Registered entity", companyNameEn],
        ["Unified Social Credit Code", companyCreditCode],
        ["Website", "Youshu · Eastern culture life reference"],
        ["ICP filing", icpNumber],
        ["Verification", "The entity record can be checked through China's National Enterprise Credit Information Publicity System."],
      ],
    },
    ai: {
      title: "AI model and content labels",
      intro: "Youshu combines structured rules with generative AI and clearly labels generated content.",
      sections: [
        ["Current model", `${aiModelName}, accessed through the official DeepSeek API.`],
        ["Filed service", `${aiServiceFilingName}; generative AI service filing: ${aiServiceFilingNumber}.`],
        ["Visible and metadata labels", "Reports and posters carry visible AI notices. Downloaded PNG posters also include metadata for generated status, service provider, and content ID."],
        ["Sharing responsibility", "Keep the AI label when publishing or forwarding generated content, and use the destination platform's AI-content declaration tools where available."],
      ],
    },
  },
};

const copy = {
  "zh-CN": {
    brandHome: "有数首页",
    brandSmall: "东方文化人生参考",
    navLabel: "主导航",
    nav: ["个人结构", "一事", "年度节奏", "购买", "方法"],
    navHrefs: ["#reading", "#products", "#products", "#products", "#method"],
    account: "我的报告",
    login: "登录",
    heroRegion: "首页主视觉",
    heroSubtitle: "心中有数，选择有光",
    heroLede: "先看结构，再看选择。心里有数，路就不乱。",
    primaryCta: "先看结构",
    servicesCta: "看产品",
    orbLabel: "旋转阴阳动效",
    readingRegion: "结构校准",
    readingKicker: "结构校准",
    readingTitle: "先把信息放准，再看当下方向。",
    readingText: "不急着要答案。先把信息与问题放清楚，再看选择从哪里开始。",
    generateBazi: "生成个人结构报告",
    generateAnnual: "生成年度节奏",
    askQuestion: "一事分析",
    entryModeLabel: "选择服务",
    entryModes: {
      bazi: {
        title: "个人结构报告",
        eyebrow: "先知己",
        summary: "看性格底色、用力方式与关系惯性。",
        focusLabel: "想看的方向",
        action: "生成个人结构报告",
        previewTitle: "先知己，心不乱",
        previewText: "先把自己的底色看清，再谈选择。",
        tags: ["性格底色", "用力方式", "关系惯性"],
      },
      annual: {
        title: "年度节奏",
        eyebrow: "看一年",
        summary: "从生成日起，向后看完整 12 个月。",
        focusLabel: "今年重点",
        action: "生成年度节奏",
        previewTitle: "先看眼前，再看一年里的转折",
        previewText: "不按自然年切开，而是从此刻往后看。",
        tags: ["后续十二月", "节奏窗口", "留意处"],
      },
      question: {
        title: "一事分析",
        eyebrow: "看一事",
        summary: "把一件具体的事拆清趋势、风险和下一步。",
        action: "生成一事分析",
        previewTitle: "事到眼前，先辨轻重",
        previewText: "问题越具体，判断越能落到下一步。",
        tags: ["趋势", "风险边界", "下一步"],
      },
    },
    birthPlace: "出生地",
    birthPlacePlaceholder: "请输入出生城市",
    calendarType: "历法",
    solarCalendar: "公历（阳历）",
    lunarCalendar: "农历（阴历）",
    lunarBirthDate: "农历生日",
    lunarDatePlaceholder: "例如 1990-08-15",
    leapMonth: "闰月",
    gender: "性别",
    genderPlaceholder: "请选择性别",
    male: "男",
    female: "女",
    questionLabel: "想分析的事",
    questionPlaceholder: "例如：接下来半年适合换工作吗？",
    generationReviewTitle: "生成前确认",
    generationReviewText: "请核对信息，确认后再开始生成。",
    generationReviewService: "服务",
    generationReviewBirth: "出生信息",
    generationReviewPlace: "出生地",
    generationReviewCalendar: "历法",
    generationReviewGender: "性别",
    generationReviewFocus: "关注方向",
    generationReviewQuestion: "具体事项",
    generationReviewUse: "确认后将使用 1 次{product}权益",
    generationReviewTestUse: "测试通道，本次不消耗正式权益。",
    generationReviewBack: "返回修改",
    generationReviewConfirm: "确认并生成",
    generationReviewMissing: "未填写",
    generatingKicker: "报告生成中",
    generating: "正在把你的信息整理成报告",
    generatingText: "先核对出生信息，再梳理结构与重点。完成后会自动进入报告页。",
    generatingSteps: ["核对出生信息", "梳理个人结构", "收束重点建议"],
    generatingStepDetails: [
      "确认历法、时间与出生地",
      "把信息整理成一条清楚的结构",
      "转成更容易理解和行动的表达",
    ],
    generatingNote: "不用重复操作，请保持此页打开。",
    generatedTitle: "生成结果",
    reportVerdict: "总断",
    reportHighlights: "要点",
    reportOutline: "报告目录",
    reportReady: "报告已成",
    reportPillars: "出生信息",
    reportFootnote: "以下内容基于确定性结构化分析与有数规则生成，仅作选择参考。",
    reportPageRegion: "报告详情",
    reportPageKicker: "我的报告",
    reportPageTitle: "这份报告，单独慢慢看。",
    reportPageText: "这份报告按你的信息归档，适合隔一段时间再回来读。",
    reportBackHome: "回到首页",
    previewReady: "试看已生成",
    previewPageText: "这是根据你刚才的信息生成的个性化试看，不会占用付费次数。",
    previewUnlockTitle: "解锁完整报告",
    previewUnlockText: "完整报告会继续展开结构、关系线索、风险边界和可执行建议。支付前先登录，订单与报告会绑定到同一账号。",
    previewUnlockAction: "登录并解锁全文",
    noReportTitle: "还没有可查看的报告",
    noReportText: "先回首页生成一份报告，完成后会自动来到这里。",
    reportGeneratedAt: "生成于",
    reportBirthInfo: "出生信息",
    reportFocusInfo: "关注方向",
    reportQuestionInfo: "具体事项",
    reportFeedback: {
      title: "这份报告，贴合你的感受吗？",
      text: "选一个最接近的感受，帮助我们把后续内容做得更具体。",
      helpful: "比较贴合",
      helpfulNote: "有启发，也能找到可用的部分",
      unhelpful: "还不够贴合",
      unhelpfulNote: "有些判断太泛，或和你不一样",
      helpfulPrompt: "哪些地方做得好？",
      unhelpfulPrompt: "最需要改进什么？",
      reasons: {
        helpful: [["resonates", "像我"], ["insightful", "有启发"], ["actionable", "建议能执行"], ["continue", "想继续问"]],
        unhelpful: [["too_generic", "太泛了"], ["mismatch", "不太像我"], ["too_strong", "说重了"], ["hard_to_act", "建议不好执行"]],
      },
      commentLabel: "想再补充一句吗？（选填）",
      commentPlaceholder: "例如：哪一段最像你，或哪一处需要更具体。",
      privacy: "只记录评价和你主动填写的内容，不提交出生信息、具体问题或报告正文。",
      submit: "提交反馈",
      saving: "正在保存…",
      savedLabel: "已记录",
      synced: "谢谢，反馈已记录。",
      localSaved: "谢谢，反馈已保存在此设备。",
      syncFallback: "反馈已保存在此设备，云端同步暂时未完成。",
      edit: "修改反馈",
      error: "保存没有完成，请稍后再试。",
    },
    reportsPageRegion: "报告归档",
    reportsPageKicker: "报告归档",
    reportsPageTitle: "我的报告",
    reportsPageText: "生成过的个人结构、一事和年度节奏，都会归在这里。日后再看，不必从头来过。",
    signedOutPageKicker: "账号登录",
    signedOutPageTitle: "登录后查看你的报告",
    signedOutPageText: "先用中国大陆手机号登录。订单、解锁权益和生成过的报告都会绑定到这个账号。",
    reportsCount: "份报告",
    reportFiltersLabel: "按报告类型筛选",
    reportFilters: { all: "全部", bazi: "个人结构", annual: "年度节奏", question: "一事分析" },
    reportFilterEmpty: "这一类报告还没有归档。",
    reportsEmptyTitle: "这里还没有报告",
    reportsEmptyText: "先生成一份报告，完成后会自动归档到这里。",
    reportOpenAction: "打开报告",
    reportDeleteAction: "删除",
    reportDeleteLabel: "删除报告：{title}",
    reportDeleteConfirm: "确认删除这份报告？删除后无法从本机恢复；已登录时也会同步删除云端副本。",
    privacyRightsTitle: "管理你的个人信息",
    privacyRightsText: "可以删除单份报告，或申请查询、更正、删除个人信息和注销账号。",
    privacyRightsAction: "提交个人信息请求",
    reportDeleteError: "报告暂时没有删除，请稍后再试。",
    reportUnknownType: "有数报告",
    authTitle: "登录后，报告会跟着你走。",
    authText: "当前浏览器会先保存报告。登录后，可把报告留到云端，之后换设备也能找回。",
    authEmailLabel: "邮箱",
    authEmailPlaceholder: "you@example.com",
    authEmailCodeLabel: "邮箱验证码",
    authEmailCodePlaceholder: "6 位验证码",
    authPhoneTab: "手机号登录",
    authEmailTab: "邮箱登录",
    authPhoneLabel: "中国大陆手机号",
    authPhonePlaceholder: "请输入 11 位手机号",
    authPhoneInvalid: "请输入正确的 11 位中国大陆手机号。",
    authPhoneCodeLabel: "短信验证码",
    authPhoneCodePlaceholder: "6 位验证码",
    authCodeInvalid: "请输入短信中的 6 位验证码。",
    authSendCode: "获取验证码",
    authResendCode: "重新获取",
    authVerifyCode: "登录并同步报告",
    authCodeSent: "验证码已发送，请查看短信。",
    authPhoneError: "验证码没有发送成功，请稍后重试。",
    authOverseas: "海外用户",
    authGoogle: "Google 登录",
    authMagicLink: "获取邮箱验证码",
    authSignedIn: "已登录",
    authSignOut: "退出登录",
    authCheckEmail: "验证码已发送，请检查邮箱，10 分钟内有效。",
    authUnavailable: "云端归档尚未配置，当前先保存到这台设备。",
    authError: "登录暂时没有完成，请稍后再试。",
    birthDate: "出生日期",
    birthTime: "出生时间",
    currentFocus: "当前关注",
    timeOptions: ["23:00-01:00", "05:00-07:00", "11:00-13:00", "17:00-19:00", "21:00-23:00"],
    readings: {
      career: { option: "事业机会", title: "机会不急，先稳住能力半径", tags: ["先稳后起", "外部机会", "节奏调整"], line: "机会未必马上出现。先把手上的能力与资源整理好。" },
      relationship: { option: "感情关系", title: "先立边界，再谈靠近", tags: ["慢热", "重承诺", "边界感"], line: "关系不是越急越近。先看清自己需要怎样的稳定。" },
      emotion: { option: "内耗与情绪", title: "心思重，责任也重", tags: ["思虑深", "责任重", "独自消化"], line: "事不一定难，难的是你总想一个人扛完。" },
      money: { option: "财务选择", title: "先看现金流，再谈选择", tags: ["稳现金流", "重判断", "忌冲动"], line: "不怕慢，就怕心急时把节奏交出去。" },
      other: { option: "综合趋势", title: "先看整体，再找到真正需要用力的地方", tags: ["整体观察", "厘清重点", "行动次序"], line: "暂时说不清也没关系。先从整体结构里找到最值得关注的部分。" },
    },
    productsRegion: "购买选择",
    purchaseLabel: "购买项目",
    productKicker: "购买选择",
    productTitle: "三项单次服务，按需要选择。",
    productSubtitle: "先免费生成一段个性化试看；觉得有帮助，再登录并支付解锁全文。完整报告生成后会归入“我的报告”。",
    badges: { single: "单次", featured: "主推" },
    prices: {
      basic: { cny: "人民币 ¥29.9", usd: "USD $4.2" },
      annual: { cny: "人民币 ¥39.9", usd: "USD $5.6" },
    },
    products: [
      { key: "bazi", title: "个人结构报告", question: "先知己，再谈选择。", priceKey: "basic", action: "生成个人结构报告" },
      { key: "question", title: "一事分析", question: "事到眼前，先辨轻重。", priceKey: "basic", action: "生成一事分析" },
      { key: "annual", title: "年度节奏报告", question: "生成日起，向后看完整 12 个月。", priceKey: "annual", action: "看年度节奏" },
    ],
    productDelivery: "先免费试看，支付后解锁完整报告",
    productRefund: "报告生成后 7 天内不满意可申请退款",
    purchaseFlowLabel: "购买流程",
    purchaseFlowTitle: "先看是否有帮助，再决定要不要解锁。",
    purchaseFlowText: "每次只选择一项服务。试看无需登录；解锁前先登录，订单、权益和完整报告会绑定到同一账号。",
    purchaseSteps: [["01", "选择服务", "填写本次所需信息"], ["02", "免费试看", "先读一段个性化内容"], ["03", "登录支付", "确认有帮助后再解锁"], ["04", "阅读全文", "完整报告进入“我的报告”"]],
    refundPromise: "七日安心退款",
    refundPromiseText: "自报告生成并首次展示之日起 7 天内，如对内容不满意，可联系客服申请退款；核对订单后原路退回。",
    entitlementStatusLabel: "权益状态",
    entitlementLockedTitle: "可以先免费试看",
    entitlementLockedText: "先生成一段个性化试看；觉得有帮助，再登录并解锁完整报告。",
    entitlementReady: "已开通，可生成",
    entitlementRemaining: "剩余 {count} 次",
    entitlementUsedUp: "已用完",
    simulateUnlock: "测试开通",
    simulateUnlockAria: "测试开通：{product}",
    testUnlockCurrent: "测试开通当前服务",
    testUnlockHint: "测试入口，仅本地或测试链接显示。",
    testAccessReady: "测试通道已开启",
    testAccessHint: "可直接生成真实报告，本次测试不消耗正式权益。",
    entitlementActive: "已开通",
    entitlementLocked: "未开通",
    annualLabel: "年度节奏 · 生成日起算",
    annualTitle: "先看眼前，再看一年里的节奏。",
    annualText: "不是按自然年切一刀，而是从你生成这一刻，向后整理完整十二个月。眼前怎么稳，后面哪里调整，一并放进同一条路里。",
    timelineLabel: "后续十二月",
    coverageLabel: "报告区间",
    coverageValue: "生成日起 · 向后完整 12 个月",
    annualTimeline: [["生成当月", "先整理眼前重点。"], ["近三个月", "看选择的先后。"], ["后续半年", "看节奏变化。"], ["后续十二月", "把重点收成一条线。"]],
    sampleRegion: "产品预览样例",
    sampleKicker: "判断样本",
    sampleTitle: "话不必多，先说中要害。",
    previews: [["个人结构报告", "先知己，心不乱", "性格底色、用力方式、关系惯性"], ["一事分析", "此事宜稳，不宜跳", "趋势、风险、下一步"], ["年度节奏", "近处先稳，远处再调", "后续十二月、机会、留意处"]],
    methodRegion: "方法说明",
    methodKicker: "为什么值得信任",
    methodTitle: "信息先校准，建议才说得稳。",
    proof: [["结构化计算", "出生信息先进入规则系统，先把底座算准。"], ["顾问规则", "顾问定规则，表达不越界。"], ["清晰诠释", "把术语翻成能用的话。"], ["一致性记录", "同一份结构，前后判断不打架。"]],
    closingRegion: "我的报告入口",
    closingText: "个人结构、一事、年度节奏，都会归进我的报告。",
    closingTitle: "先看一眼，再决定往哪一层深入。",
    backToReading: "回到生成入口",
    viewProducts: "查看购买选择",
    footerTagline: "以东方文化结构，帮助你看清自己的节奏与选择。",
    footerDisclaimer: "报告由结构化规则与人工智能生成，仅供自我认知与选择参考，不替代医疗、法律、投资或心理等专业意见。",
    footerAge: "建议年满 18 周岁后使用。",
    footerCompanyLabel: "运营主体",
    footerIcpLabel: "ICP备案",
    footerSupportLabel: "客服邮箱",
    footerLinks: { terms: "服务条款", privacy: "隐私政策", refund: "退款政策", contact: "联系我们", license: "营业执照", ai: "AI 模型与标识" },
    businessDisclosureLabel: "经营主体与营业执照",
    businessDisclosureText: `${companyNameZh} · ${companyCreditCode}`,
    aiGeneratedLabel: "内容由人工智能生成，仅供参考",
    generationRecovery: {
      title: "发现一份尚未确认完成的报告",
      text: "刷新或网络中断不会重复扣次数。可以使用原请求编号检查结果。",
      action: "找回生成结果",
      checking: "正在检查…",
      pending: "报告仍在实时生成，请稍后再次检查。",
      released: "上次生成没有完成，权益已保留，可以重新发起。",
      missing: "未找到上次请求，已为你清理本机记录，可以重新生成。",
      error: "暂时无法检查，原请求编号仍保留，请稍后再试。",
      requestLabel: "请求编号",
      dismiss: "暂不处理",
    },
    legalBackHome: "回到首页",
    legalUpdated: "更新日期：2026 年 7 月 28 日",
    legalPages: {
      terms: {
        title: "服务条款",
        intro: "使用有数，即表示你理解并同意以下服务边界。本页面为上线测试版条款，正式商业化前可能继续更新。",
        sections: [
          ["服务性质", "有数提供基于传统文化结构、规则化解读与大模型生成的个人结构报告、一事分析和年度节奏参考。内容用于自我认知、情绪整理和选择辅助，不承诺预测结果必然发生。"],
          ["适用人群", "本服务建议 18 岁以上用户使用。若你正在处理医疗、法律、投资、心理危机或人身安全等高风险事项，请优先咨询合资格专业人士或当地紧急服务。"],
          ["用户责任", "你应提供相对准确的出生日期、出生时间、出生地和问题背景。若输入信息不准确，报告可能偏离你的实际情况。你也应自行判断是否采纳报告建议。"],
          ["数字内容交付", "付款成功后系统立即开始实时生成，完成后自动归档至“我的报告”。报告生成即完成数字内容交付，但不影响本服务明示的七日退款权益。"],
          ["AI 内容标识", "报告页面持续显示“内容由人工智能生成，仅供参考”。分享海报包含可见 AI 标识，下载图片同时写入生成属性、服务提供者和内容编号等元数据信息。用户对外分享时应保留标识，并按发布平台要求主动声明。"],
          ["禁止用途", "不得将本服务用于违法、骚扰、歧视、操纵他人、医疗诊断、金融承诺或其他高风险决策自动化。"],
          ["变更与联系", `我们可能根据产品测试情况调整页面、价格、权益和条款。如有问题，请联系 ${supportEmail}。`],
        ],
      },
      privacy: {
        title: "隐私政策",
        intro: "我们只收集生成报告所需的信息，并尽量让数据用途清楚、克制。",
        sections: [
          ["我们收集什么", "你主动填写的出生日期、出生时间、出生地、性别、关注方向、具体问题、语言偏好，以及生成报告所需的基础技术信息。"],
          ["如何使用", "这些信息用于结构化分析、生成报告、改进提示词与服务质量、处理客服请求，以及在接入账户后帮助你找回历史报告。"],
          ["大模型处理", "生成报告时，必要的结构化分析结果、问题背景和语言选项会发送给我们使用的大模型服务商。我们不会在前端展示或要求用户提交 DeepSeek API Key。"],
          ["保存期限", "本机报告最多保存最近 30 份，直到你主动删除或清理浏览器数据；云端报告在账户存续期间保存，删除报告或注销账户后进入删除流程；未完成的生成找回信息仅在本机保存，最长 24 小时；生成与安全日志原则上保存不超过 6 个月；订单、支付、退款和售后记录按适用法律要求保存，自交易完成之日起不少于 3 年。"],
          ["第三方与基础设施服务", "网站和接口部署在阿里云境内服务器；账户认证、报告归档、权益、邀请和反馈由国内生产数据库（PostgreSQL）处理；手机号验证码由阿里云短信发送；报告生成通过 DeepSeek 官方 API；订单和支付由支付宝处理。各方仅接收完成对应服务所必需的数据。"],
          ["你的权利", "你可以在“我的报告”删除单份报告；也可以申请查询、复制、更正、删除个人信息或注销账户。我们将在核验身份后处理；法律规定的保存期尚未届满时，将停止除保存和安全保护之外的处理。"],
          ["如何申请", `请点击“联系我们”或发送邮件至 ${supportEmail}，主题注明“个人信息请求”，并说明查询、更正、删除或注销需求。请勿在邮件中发送身份证照片或完整支付密码。`],
        ],
      },
      refund: {
        title: "退款政策",
        intro: "每一份报告都享有七日安心退款。自报告生成并首次展示之日起 7 天内，如对内容不满意，可以申请退款。",
        sections: [
          ["适用范围", "个人结构报告、一事分析和年度节奏报告均适用。对报告内容不满意，也可以在期限内提出申请。"],
          ["申请期限", "退款期限从报告生成并首次展示之时起计算 7 个自然日。超过期限的申请，我们仍会核对系统故障、重复扣款等异常情况。"],
          ["处理方式", `请发送退款申请至 ${supportEmail}，提供订单号、付款账号、购买项目和简要原因。核对订单后，款项原则上按原支付路径退回。`],
          ["处理时效", "我们会尽量在 2 个工作日内受理。实际到账时间由支付机构和银行处理周期决定。"],
          ["合理使用", "每个订单仅可退款一次。对于明显的批量套取内容、虚假订单、恶意重复退款或其他滥用行为，我们保留拒绝申请并暂停账户服务的权利。"],
        ],
      },
      contact: {
        title: "联系我们",
        intro: "报告、订单、退款、隐私和合作问题，都可以通过邮箱联系我们。我们会核对相关记录并尽快回复。",
        sections: [
          ["客服邮箱", supportEmail],
          ["运营主体", companyNameZh],
          ["服务范围", "个人结构报告、一事分析、年度节奏报告、订单退款与报告归档相关问题。"],
          ["回复时间", "我们会尽量在 2 个工作日内回复。复杂订单、退款或隐私请求可能需要更多时间核对。"],
        ],
      },
    },
    generationErrorTitle: "生成暂时未完成",
    apiErrors: {
      backendKey: "服务端模型配置正在调整，请稍后再试或联系客服。",
      questionRequired: "请先写下你想问的具体事情，再生成一事分析。",
      authRequired: "登录状态已失效，请重新登录后再生成。",
      entitlementRequired: "这项服务当前没有可用次数，请返回购买页确认权益。",
      inProgress: "这份报告已经在生成中，请稍等片刻再查看。",
      rateLimited: "操作有些频繁，请稍后再试。原有权益不会因此重复扣除。",
      default: "生成暂时没有完成，请稍后重试。",
    },
  },
  "zh-TW": {
    brandHome: "有數首頁",
    brandSmall: "東方文化人生參考",
    navLabel: "主導覽",
    nav: ["個人結構", "一事", "年度節奏", "購買", "方法"],
    navHrefs: ["#reading", "#products", "#products", "#products", "#method"],
    account: "我的報告",
    login: "登入",
    heroRegion: "首頁主視覺",
    heroSubtitle: "心中有數，選擇有光",
    heroLede: "先看結構，再看選擇。心裡有數，路就不亂。",
    primaryCta: "先看結構",
    servicesCta: "看產品",
    orbLabel: "旋轉陰陽動效",
    readingRegion: "結構校準",
    readingKicker: "結構校準",
    readingTitle: "先把資訊放準，再看當下方向。",
    readingText: "不急著要答案。先把資訊與問題放清楚，再看選擇從哪裡開始。",
    generateBazi: "生成個人結構報告",
    generateAnnual: "生成年度節奏",
    askQuestion: "一事分析",
    entryModeLabel: "選擇服務",
    entryModes: {
      bazi: {
        title: "個人結構報告",
        eyebrow: "先知己",
        summary: "看性格底色、用力方式與關係慣性。",
        focusLabel: "想看的方向",
        action: "生成個人結構報告",
        previewTitle: "先知己，心不亂",
        previewText: "先把自己的底色看清，再談選擇。",
        tags: ["性格底色", "用力方式", "關係慣性"],
      },
      annual: {
        title: "年度節奏",
        eyebrow: "看一年",
        summary: "從生成日起，向後看完整 12 個月。",
        focusLabel: "今年重點",
        action: "生成年度節奏",
        previewTitle: "先看眼前，再看一年裡的轉折",
        previewText: "不按自然年切開，而是從此刻往後看。",
        tags: ["後續十二月", "節奏窗口", "留意處"],
      },
      question: {
        title: "一事分析",
        eyebrow: "看一事",
        summary: "把一件具體的事拆清趨勢、風險和下一步。",
        action: "生成一事分析",
        previewTitle: "事到眼前，先辨輕重",
        previewText: "問題越具體，判斷越能落到下一步。",
        tags: ["趨勢", "風險邊界", "下一步"],
      },
    },
    birthPlace: "出生地",
    birthPlacePlaceholder: "請輸入出生城市",
    calendarType: "曆法",
    solarCalendar: "公曆（陽曆）",
    lunarCalendar: "農曆（陰曆）",
    lunarBirthDate: "農曆生日",
    lunarDatePlaceholder: "例如 1990-08-15",
    leapMonth: "閏月",
    gender: "性別",
    genderPlaceholder: "請選擇性別",
    male: "男",
    female: "女",
    questionLabel: "想分析的事",
    questionPlaceholder: "例如：接下來半年適合換工作嗎？",
    generationReviewTitle: "生成前確認",
    generationReviewText: "請核對資訊，確認後再開始生成。",
    generationReviewService: "服務",
    generationReviewBirth: "出生資訊",
    generationReviewPlace: "出生地",
    generationReviewCalendar: "曆法",
    generationReviewGender: "性別",
    generationReviewFocus: "關注方向",
    generationReviewQuestion: "具體事項",
    generationReviewUse: "確認後將使用 1 次{product}權益",
    generationReviewTestUse: "測試通道，本次不消耗正式權益。",
    generationReviewBack: "返回修改",
    generationReviewConfirm: "確認並生成",
    generationReviewMissing: "未填寫",
    generatingKicker: "報告生成中",
    generating: "正在把你的資訊整理成報告",
    generatingText: "先核對出生資訊，再梳理結構與重點。完成後會自動進入報告頁。",
    generatingSteps: ["核對出生資訊", "梳理個人結構", "收束重點建議"],
    generatingStepDetails: [
      "確認曆法、時間與出生地",
      "把資訊整理成一條清楚的結構",
      "轉成更容易理解和行動的表達",
    ],
    generatingNote: "不用重複操作，請保持此頁開啟。",
    generatedTitle: "生成結果",
    reportVerdict: "總斷",
    reportHighlights: "要點",
    reportOutline: "報告目錄",
    reportReady: "報告已成",
    reportPillars: "出生資訊",
    reportFootnote: "以下內容基於確定性結構化分析與有數規則生成，僅作選擇參考。",
    reportPageRegion: "報告詳情",
    reportPageKicker: "我的報告",
    reportPageTitle: "這份報告，單獨慢慢看。",
    reportPageText: "這份報告會依你的資訊歸檔，適合隔一段時間再回來讀。",
    reportBackHome: "回到首頁",
    previewReady: "試看已生成",
    previewPageText: "這是根據你剛才的資訊生成的個人化試看，不會使用付費次數。",
    previewUnlockTitle: "解鎖完整報告",
    previewUnlockText: "完整報告會繼續展開結構、關係線索、風險邊界與可執行建議。付款前先登入，訂單與報告會綁定到同一帳號。",
    previewUnlockAction: "登入並解鎖全文",
    noReportTitle: "還沒有可查看的報告",
    noReportText: "先回首頁生成一份報告，完成後會自動來到這裡。",
    reportGeneratedAt: "生成於",
    reportBirthInfo: "出生資訊",
    reportFocusInfo: "關注方向",
    reportQuestionInfo: "具體事項",
    reportFeedback: {
      title: "這份報告，貼合你的感受嗎？",
      text: "選一個最接近的感受，幫助我們把後續內容做得更具體。",
      helpful: "比較貼合",
      helpfulNote: "有啟發，也能找到可用的部分",
      unhelpful: "還不夠貼合",
      unhelpfulNote: "有些判斷太泛，或和你不一樣",
      helpfulPrompt: "哪些地方做得好？",
      unhelpfulPrompt: "最需要改進什麼？",
      reasons: {
        helpful: [["resonates", "像我"], ["insightful", "有啟發"], ["actionable", "建議能執行"], ["continue", "想繼續問"]],
        unhelpful: [["too_generic", "太泛了"], ["mismatch", "不太像我"], ["too_strong", "說重了"], ["hard_to_act", "建議不好執行"]],
      },
      commentLabel: "想再補充一句嗎？（選填）",
      commentPlaceholder: "例如：哪一段最像你，或哪一處需要更具體。",
      privacy: "只記錄評價和你主動填寫的內容，不提交出生資訊、具體問題或報告正文。",
      submit: "提交回饋",
      saving: "正在保存…",
      savedLabel: "已記錄",
      synced: "謝謝，回饋已記錄。",
      localSaved: "謝謝，回饋已保存在此裝置。",
      syncFallback: "回饋已保存在此裝置，雲端同步暫時未完成。",
      edit: "修改回饋",
      error: "保存沒有完成，請稍後再試。",
    },
    reportsPageRegion: "報告歸檔",
    reportsPageKicker: "報告歸檔",
    reportsPageTitle: "我的報告",
    reportsPageText: "生成過的個人結構、一事和年度節奏，都會歸在這裡。日後再看，不必從頭來過。",
    signedOutPageKicker: "帳號登入",
    signedOutPageTitle: "登入後查看你的報告",
    signedOutPageText: "先用中國大陸手機號登入。訂單、解鎖權益和生成過的報告都會綁定到這個帳號。",
    reportsCount: "份報告",
    reportFiltersLabel: "按報告類型篩選",
    reportFilters: { all: "全部", bazi: "個人結構", annual: "年度節奏", question: "一事分析" },
    reportFilterEmpty: "這一類報告還沒有歸檔。",
    reportsEmptyTitle: "這裡還沒有報告",
    reportsEmptyText: "先生成一份報告，完成後會自動歸檔到這裡。",
    reportOpenAction: "打開報告",
    reportDeleteAction: "刪除",
    reportDeleteLabel: "刪除報告：{title}",
    reportDeleteConfirm: "確認刪除這份報告？刪除後無法從本機恢復；已登入時也會同步刪除雲端副本。",
    privacyRightsTitle: "管理你的個人資訊",
    privacyRightsText: "可以刪除單份報告，或申請查詢、更正、刪除個人資訊和註銷帳號。",
    privacyRightsAction: "提交個人資訊請求",
    reportDeleteError: "報告暫時沒有刪除，請稍後再試。",
    reportUnknownType: "有數報告",
    authTitle: "登入後，報告會跟著你走。",
    authText: "目前瀏覽器會先保存報告。登入後，可把報告留到雲端，之後換設備也能找回。",
    authEmailLabel: "信箱",
    authEmailPlaceholder: "you@example.com",
    authEmailCodeLabel: "信箱驗證碼",
    authEmailCodePlaceholder: "6 位驗證碼",
    authPhoneTab: "手機號登入",
    authEmailTab: "信箱登入",
    authPhoneLabel: "中國大陸手機號",
    authPhonePlaceholder: "請輸入 11 位手機號",
    authPhoneInvalid: "請輸入正確的 11 位中國大陸手機號。",
    authPhoneCodeLabel: "簡訊驗證碼",
    authPhoneCodePlaceholder: "6 位驗證碼",
    authCodeInvalid: "請輸入簡訊中的 6 位驗證碼。",
    authSendCode: "取得驗證碼",
    authResendCode: "重新取得",
    authVerifyCode: "登入並同步報告",
    authCodeSent: "驗證碼已發送，請查看簡訊。",
    authPhoneError: "驗證碼沒有發送成功，請稍後重試。",
    authOverseas: "海外使用者",
    authGoogle: "Google 登入",
    authMagicLink: "取得信箱驗證碼",
    authSignedIn: "已登入",
    authSignOut: "退出登入",
    authCheckEmail: "驗證碼已發送，請檢查信箱，10 分鐘內有效。",
    authUnavailable: "雲端歸檔尚未配置，目前先保存到這台設備。",
    authError: "登入暫時沒有完成，請稍後再試。",
    birthDate: "出生日期",
    birthTime: "出生時間",
    currentFocus: "當前關注",
    timeOptions: ["23:00-01:00", "05:00-07:00", "11:00-13:00", "17:00-19:00", "21:00-23:00"],
    readings: {
      career: { option: "事業機會", title: "機會不急，先穩住能力半徑", tags: ["先穩後起", "外部機會", "節奏調整"], line: "機會未必馬上出現。先把手上的能力與資源整理好。" },
      relationship: { option: "感情關係", title: "先立邊界，再談靠近", tags: ["慢熱", "重承諾", "邊界感"], line: "關係不是越急越近。先看清自己需要怎樣的穩定。" },
      emotion: { option: "內耗與情緒", title: "心思重，責任也重", tags: ["思慮深", "責任重", "獨自消化"], line: "事不一定難，難的是你總想一個人扛完。" },
      money: { option: "財務選擇", title: "先看現金流，再談選擇", tags: ["穩現金流", "重判斷", "忌衝動"], line: "不怕慢，就怕心急時把節奏交出去。" },
      other: { option: "綜合趨勢", title: "先看整體，再找到真正需要用力的地方", tags: ["整體觀察", "釐清重點", "行動次序"], line: "暫時說不清也沒關係。先從整體結構裡找到最值得關注的部分。" },
    },
    productsRegion: "購買選擇",
    purchaseLabel: "購買項目",
    productKicker: "購買選擇",
    productTitle: "三項單次服務，按需要選擇。",
    productSubtitle: "先免費生成一段個人化試看；覺得有幫助，再登入並付款解鎖全文。完整報告生成後會歸入「我的報告」。",
    badges: { single: "單次", featured: "主推" },
    prices: {
      basic: { cny: "人民幣 ¥29.9", usd: "USD $4.2" },
      annual: { cny: "人民幣 ¥39.9", usd: "USD $5.6" },
    },
    products: [
      { key: "bazi", title: "個人結構報告", question: "先知己，再談選擇。", priceKey: "basic", action: "生成個人結構報告" },
      { key: "question", title: "一事分析", question: "事到眼前，先辨輕重。", priceKey: "basic", action: "生成一事分析" },
      { key: "annual", title: "年度節奏報告", question: "生成日起，向後看完整 12 個月。", priceKey: "annual", action: "看年度節奏" },
    ],
    productDelivery: "先免費試看，付款後解鎖完整報告",
    productRefund: "報告生成後 7 天內不滿意可申請退款",
    purchaseFlowLabel: "購買流程",
    purchaseFlowTitle: "先看是否有幫助，再決定要不要解鎖。",
    purchaseFlowText: "每次只選擇一項服務。試看無需登入；解鎖前先登入，訂單、權益和完整報告會綁定到同一帳號。",
    purchaseSteps: [["01", "選擇服務", "填寫本次所需資訊"], ["02", "免費試看", "先讀一段個人化內容"], ["03", "登入付款", "確認有幫助後再解鎖"], ["04", "閱讀全文", "完整報告進入「我的報告」"]],
    refundPromise: "七日安心退款",
    refundPromiseText: "自報告生成並首次展示之日起 7 天內，如對內容不滿意，可聯絡客服申請退款；核對訂單後原路退回。",
    entitlementStatusLabel: "權益狀態",
    entitlementLockedTitle: "可以先免費試看",
    entitlementLockedText: "先生成一段個人化試看；覺得有幫助，再登入並解鎖完整報告。",
    entitlementReady: "已開通，可生成",
    entitlementRemaining: "剩餘 {count} 次",
    entitlementUsedUp: "已用完",
    simulateUnlock: "測試開通",
    simulateUnlockAria: "測試開通：{product}",
    testUnlockCurrent: "測試開通目前服務",
    testUnlockHint: "測試入口，僅本地或測試連結顯示。",
    testAccessReady: "測試通道已開啟",
    testAccessHint: "可直接生成真實報告，本次測試不消耗正式權益。",
    entitlementActive: "已開通",
    entitlementLocked: "未開通",
    annualLabel: "年度節奏 · 生成日起算",
    annualTitle: "先看眼前，再看一年裡的節奏。",
    annualText: "不是按自然年切一刀，而是從你生成這一刻，向後整理完整十二個月。眼前怎麼穩，後面哪裡調整，一併放進同一條路裡。",
    timelineLabel: "後續十二月",
    coverageLabel: "報告區間",
    coverageValue: "生成日起 · 向後完整 12 個月",
    annualTimeline: [["生成當月", "先整理眼前重點。"], ["近三個月", "看選擇的先後。"], ["後續半年", "看節奏變化。"], ["後續十二月", "把重點收成一條線。"]],
    sampleRegion: "產品預覽樣例",
    sampleKicker: "判斷樣本",
    sampleTitle: "話不必多，先說中要害。",
    previews: [["個人結構報告", "先知己，心不亂", "性格底色、用力方式、關係慣性"], ["一事分析", "此事宜穩，不宜跳", "趨勢、風險、下一步"], ["年度節奏", "近處先穩，遠處再調", "後續十二月、機會、留意處"]],
    methodRegion: "方法說明",
    methodKicker: "為什麼值得信任",
    methodTitle: "資訊先校準，建議才說得穩。",
    proof: [["結構化計算", "出生資訊先進入規則系統，先把底座算準。"], ["顧問規則", "顧問定規則，表達不越界。"], ["清晰詮釋", "把術語翻成能用的話。"], ["一致性記錄", "同一份結構，前後判斷不打架。"]],
    closingRegion: "我的報告入口",
    closingText: "個人結構、一事、年度節奏，都會歸進我的報告。",
    closingTitle: "先看一眼，再決定往哪一層深入。",
    backToReading: "回到生成入口",
    viewProducts: "查看購買選擇",
    footerTagline: "以東方文化結構，幫助你看清自己的節奏與選擇。",
    footerDisclaimer: "報告由結構化規則與人工智慧生成，僅供自我認知與選擇參考，不替代醫療、法律、投資或心理等專業意見。",
    footerAge: "建議年滿 18 歲後使用。",
    footerCompanyLabel: "營運主體",
    footerIcpLabel: "ICP備案",
    footerSupportLabel: "客服信箱",
    footerLinks: { terms: "服務條款", privacy: "隱私政策", refund: "退款政策", contact: "聯絡我們", license: "營業執照", ai: "AI 模型與標識" },
    businessDisclosureLabel: "營運主體與營業執照",
    businessDisclosureText: `${companyNameZh} · ${companyCreditCode}`,
    aiGeneratedLabel: "內容由人工智慧生成，僅供參考",
    generationRecovery: {
      title: "發現一份尚未確認完成的報告",
      text: "重新整理或網路中斷不會重複扣次數。可以使用原請求編號檢查結果。",
      action: "找回生成結果",
      checking: "正在檢查…",
      pending: "報告仍在即時生成，請稍後再次檢查。",
      released: "上次生成沒有完成，權益已保留，可以重新發起。",
      missing: "未找到上次請求，已清理本機記錄，可以重新生成。",
      error: "暫時無法檢查，原請求編號仍保留，請稍後再試。",
      requestLabel: "請求編號",
      dismiss: "暫不處理",
    },
    legalBackHome: "回到首頁",
    legalUpdated: "更新日期：2026 年 7 月 28 日",
    legalPages: {
      terms: {
        title: "服務條款",
        intro: "使用有數，即表示你理解並同意以下服務邊界。本頁面為上線測試版條款，正式商業化前可能繼續更新。",
        sections: [
          ["服務性質", "有數提供基於傳統文化結構、規則化解讀與大模型生成的個人結構報告、一事分析和年度節奏參考。內容用於自我認知、情緒整理和選擇輔助，不承諾預測結果必然發生。"],
          ["適用人群", "本服務建議 18 歲以上用戶使用。若你正在處理醫療、法律、投資、心理危機或人身安全等高風險事項，請優先諮詢合資格專業人士或當地緊急服務。"],
          ["用戶責任", "你應提供相對準確的出生日期、出生時間、出生地和問題背景。若輸入資訊不準確，報告可能偏離你的實際情況。你也應自行判斷是否採納報告建議。"],
          ["數位內容交付", "付款成功後系統立即開始即時生成，完成後自動歸入「我的報告」。數位內容交付後仍適用本網站明示的七日安心退款規則。"],
          ["AI 內容標識", "報告頁面持續顯示 AI 生成提示；分享海報包含可見標識，下載圖片同時寫入生成屬性、服務提供者和內容編號等中繼資料。對外分享時應保留標識。"],
          ["禁止用途", "不得將本服務用於違法、騷擾、歧視、操縱他人、醫療診斷、金融承諾或其他高風險決策自動化。"],
          ["變更與聯絡", `我們可能根據產品測試情況調整頁面、價格、權益和條款。如有問題，請聯絡 ${supportEmail}。`],
        ],
      },
      privacy: {
        title: "隱私政策",
        intro: "我們只收集生成報告所需的資訊，並盡量讓資料用途清楚、克制。",
        sections: [
          ["我們收集什麼", "你主動填寫的出生日期、出生時間、出生地、性別、關注方向、具體問題、語言偏好，以及生成報告所需的基礎技術資訊。"],
          ["如何使用", "這些資訊用於結構化分析、生成報告、改進提示詞與服務品質、處理客服請求，以及在接入帳戶後幫助你找回歷史報告。"],
          ["大模型處理", "生成報告時，必要的結構化分析結果、問題背景和語言選項會發送給我們使用的大模型服務商。我們不會在前端展示或要求用戶提交 DeepSeek API Key。"],
          ["保存與刪除", "本機最多保存最近 30 份報告，直到你主動刪除或清理瀏覽器資料；雲端報告在帳戶存續期間保存；未完成的生成找回資訊在本機最長保存 24 小時；安全日誌原則上不超過 6 個月；訂單與售後記錄依適用法律保存。"],
          ["第三方與基礎設施服務", "網站與介面部署於阿里雲境內伺服器；帳戶認證、報告歸檔、權益、邀請和回饋由國內生產資料庫（PostgreSQL）處理；手機驗證碼由阿里雲簡訊發送；報告透過 DeepSeek 官方 API 生成；訂單與支付由支付寶處理。各方僅接收完成對應服務所必需的資料。"],
          ["你的權利", `你可以在「我的報告」刪除單份報告，也可以寄送郵件至 ${supportEmail} 申請查詢、更正、刪除個人資訊或註銷帳戶。`],
        ],
      },
      refund: {
        title: "退款政策",
        intro: "我們希望你先放心使用，再決定是否留下。三項單次服務均提供報告生成後七日內不滿意退款。",
        sections: [
          ["適用範圍", "個人結構報告、一事分析、年度節奏報告均適用本規則。自報告生成並首次展示之日起 7 個自然日內，如對內容不滿意，可申請退款。"],
          ["如何申請", `請發送郵件至 ${supportEmail}，提供帳戶、訂單時間、購買項目及簡要退款原因。我們會在 2 個工作日內確認受理。`],
          ["退款方式", "核對訂單後，款項原則上按原支付路徑退回。支付管道的實際到帳時間以其處理進度為準。"],
          ["異常情形", "如發生重複扣款、付款成功但未生成、系統故障等情況，我們會優先退款或重新交付。對短期內大量重複購買、生成後集中退款等明顯濫用情形，我們保留核驗和限制服務的權利。"],
        ],
      },
      contact: {
        title: "聯絡我們",
        intro: "報告、訂單、退款、隱私和合作問題，都可以透過信箱聯絡我們。我們會核對相關記錄並盡快回覆。",
        sections: [
          ["客服信箱", supportEmail],
          ["營運主體", companyNameZh],
          ["服務範圍", "個人結構報告、一事分析、年度節奏報告、訂單退款與報告歸檔相關問題。"],
          ["回覆時間", "我們會盡量在 2 個工作日內回覆。複雜訂單、退款或隱私請求可能需要更多時間核對。"],
        ],
      },
    },
    generationErrorTitle: "生成暫時未完成",
    apiErrors: {
      backendKey: "服務端模型配置正在調整，請稍後再試或聯絡客服。",
      questionRequired: "請先寫下你想問的具體事情，再生成一事分析。",
      authRequired: "登入狀態已失效，請重新登入後再生成。",
      entitlementRequired: "這項服務目前沒有可用次數，請返回購買頁確認權益。",
      inProgress: "這份報告已經在生成中，請稍候再查看。",
      rateLimited: "操作有些頻繁，請稍後再試。原有權益不會因此重複扣除。",
      default: "生成暫時沒有完成，請稍後重試。",
    },
  },
  en: {
    brandHome: "Youshu home",
    brandSmall: "Eastern culture life reference",
    navLabel: "Main navigation",
    nav: ["Structure", "Analyze", "Year rhythm", "Purchase", "Method"],
    navHrefs: ["#reading", "#products", "#products", "#products", "#method"],
    account: "My reports",
    login: "Sign in",
    heroRegion: "Hero",
    heroSubtitle: "A clear structure, a calmer choice.",
    heroLede: "Read the structure first, then decide. When the mind has a number, the path feels less tangled.",
    primaryCta: "Start a report",
    servicesCta: "View products",
    orbLabel: "Rotating yin-yang motion",
    readingRegion: "Structure Check",
    readingKicker: "Structure Check",
    readingTitle: "Set the information clearly, then read the direction.",
    readingText: "No need to rush the answer. Put the information and the question in order first.",
    generateBazi: "Generate personal structure report",
    generateAnnual: "Generate annual rhythm report",
    askQuestion: "Analyze one matter",
    entryModeLabel: "Choose a service",
    entryModes: {
      bazi: {
        title: "Personal Structure Report",
        eyebrow: "Know yourself",
        summary: "Read temperament, effort style, and relationship habits.",
        focusLabel: "Reading focus",
        action: "Generate personal structure report",
        previewTitle: "Know yourself; the mind steadies",
        previewText: "Read the base pattern first, then decide with more clarity.",
        tags: ["temperament", "effort style", "relationship habits"],
      },
      annual: {
        title: "Annual Rhythm Report",
        eyebrow: "Read the year",
        summary: "From the reading date, look across the next full 12 months.",
        focusLabel: "Annual focus",
        action: "Generate annual rhythm report",
        previewTitle: "Read what is near, then the turnings of the year",
        previewText: "Not a calendar cut. It reads forward from this moment.",
        tags: ["next 12 months", "rhythm windows", "what to notice"],
      },
      question: {
        title: "One-Matter Analysis",
        eyebrow: "Ask one thing",
        summary: "Separate one concrete matter into trend, risk, and next step.",
        action: "Generate one-matter analysis",
        previewTitle: "When the matter arrives, weigh it first",
        previewText: "The more concrete the question, the more usable the answer.",
        tags: ["trend", "risk boundary", "next step"],
      },
    },
    birthPlace: "Birth place",
    birthPlacePlaceholder: "Enter birth city",
    calendarType: "Calendar",
    solarCalendar: "Solar (Gregorian)",
    lunarCalendar: "Lunar (Chinese)",
    lunarBirthDate: "Lunar birth date",
    lunarDatePlaceholder: "Example: 1990-08-15",
    leapMonth: "Leap month",
    gender: "Gender",
    genderPlaceholder: "Select gender",
    male: "Male",
    female: "Female",
    questionLabel: "Question",
    questionPlaceholder: "Example: Should I change jobs in the next six months?",
    generationReviewTitle: "Review before generating",
    generationReviewText: "Check the details before the report begins.",
    generationReviewService: "Service",
    generationReviewBirth: "Birth information",
    generationReviewPlace: "Birth place",
    generationReviewCalendar: "Calendar",
    generationReviewGender: "Gender",
    generationReviewFocus: "Focus",
    generationReviewQuestion: "Specific matter",
    generationReviewUse: "Confirming will use 1 {product} entitlement",
    generationReviewTestUse: "Test mode is active. This will not use a paid entitlement.",
    generationReviewBack: "Return to edit",
    generationReviewConfirm: "Confirm and generate",
    generationReviewMissing: "Not provided",
    generatingKicker: "Generating report",
    generating: "Turning your information into a clear report",
    generatingText: "We check the birth data first, then shape the structure and key guidance. The report opens automatically when ready.",
    generatingSteps: ["Check birth data", "Map the structure", "Shape the guidance"],
    generatingStepDetails: [
      "Confirm calendar, time, and birthplace",
      "Arrange the information into a coherent pattern",
      "Turn the pattern into clear, usable language",
    ],
    generatingNote: "No need to repeat the action. Keep this page open.",
    generatedTitle: "Generated result",
    reportVerdict: "Main reading",
    reportHighlights: "Highlights",
    reportOutline: "Report outline",
    reportReady: "Report ready",
    reportPillars: "Birth fields",
    reportFootnote: "Generated from deterministic structure calculation and Youshu guidance rules. Use as decision support.",
    reportPageRegion: "Report detail",
    reportPageKicker: "My report",
    reportPageTitle: "A full report deserves its own page.",
    reportPageText: "This reading is archived with your information, ready to return to when the timing is right.",
    reportBackHome: "Back home",
    previewReady: "Preview ready",
    previewPageText: "This personalized preview was generated from your details and does not use paid access.",
    previewUnlockTitle: "Unlock the full report",
    previewUnlockText: "The full report continues with deeper patterns, relationship signals, risk boundaries, and practical guidance. Sign in before paying so the order and report stay attached to one account.",
    previewUnlockAction: "Sign in and unlock",
    noReportTitle: "No report yet",
    noReportText: "Return home and open a structure first. The report will appear here after generation.",
    reportGeneratedAt: "Generated",
    reportBirthInfo: "Birth info",
    reportFocusInfo: "Focus",
    reportQuestionInfo: "Question",
    reportFeedback: {
      title: "Did this report feel true to you?",
      text: "Choose the closest response. It helps us make future reports more specific.",
      helpful: "Mostly true",
      helpfulNote: "It offered insight and something useful",
      unhelpful: "Not quite true",
      unhelpfulNote: "Some parts felt too broad or did not fit",
      helpfulPrompt: "What worked well?",
      unhelpfulPrompt: "What needs the most improvement?",
      reasons: {
        helpful: [["resonates", "Felt like me"], ["insightful", "Gave me insight"], ["actionable", "Actionable advice"], ["continue", "I want to ask more"]],
        unhelpful: [["too_generic", "Too general"], ["mismatch", "Did not fit me"], ["too_strong", "Too definitive"], ["hard_to_act", "Hard to act on"]],
      },
      commentLabel: "Add one more thought? (optional)",
      commentPlaceholder: "For example, what resonated or what needed to be more specific.",
      privacy: "We save only your rating and what you choose to write—not birth data, your question, or the report text.",
      submit: "Submit feedback",
      saving: "Saving…",
      savedLabel: "Saved",
      synced: "Thank you. Your feedback was saved.",
      localSaved: "Thank you. Your feedback was saved on this device.",
      syncFallback: "Saved on this device. Cloud sync did not finish.",
      edit: "Edit feedback",
      error: "Feedback could not be saved. Please try again.",
    },
    reportsPageRegion: "Report archive",
    reportsPageKicker: "Report archive",
    reportsPageTitle: "My reports",
    reportsPageText: "Generated structures, questions, and annual rhythm reports return here. Next time, you do not start from zero.",
    signedOutPageKicker: "Account sign-in",
    signedOutPageTitle: "Sign in to view your reports",
    signedOutPageText: "Use a Mainland China mobile number. Orders, access, and generated reports stay attached to this account.",
    reportsCount: "reports",
    reportFiltersLabel: "Filter by report type",
    reportFilters: { all: "All", bazi: "Structure", annual: "Annual rhythm", question: "One matter" },
    reportFilterEmpty: "There are no archived reports in this category yet.",
    reportsEmptyTitle: "No saved reports yet",
    reportsEmptyText: "Open a structure first. The report will be saved here after generation.",
    reportOpenAction: "Open report",
    reportDeleteAction: "Delete",
    reportDeleteLabel: "Delete report: {title}",
    reportDeleteConfirm: "Delete this report? It cannot be recovered from this device, and the cloud copy will also be removed when signed in.",
    privacyRightsTitle: "Manage your personal information",
    privacyRightsText: "Delete an individual report, or request access, correction, deletion, and account closure.",
    privacyRightsAction: "Submit a privacy request",
    reportDeleteError: "The report could not be deleted. Please try again.",
    reportUnknownType: "Youshu report",
    authTitle: "Sign in and your reports can travel with you.",
    authText: "This browser keeps reports first. After sign-in, reports can be saved to the cloud and recovered on another device.",
    authEmailLabel: "Email",
    authEmailPlaceholder: "you@example.com",
    authEmailCodeLabel: "Email verification code",
    authEmailCodePlaceholder: "6-digit code",
    authPhoneTab: "Mobile sign-in",
    authEmailTab: "Email sign-in",
    authPhoneLabel: "Mainland China mobile number",
    authPhonePlaceholder: "11-digit mobile number",
    authPhoneInvalid: "Enter a valid 11-digit mainland China mobile number.",
    authPhoneCodeLabel: "SMS verification code",
    authPhoneCodePlaceholder: "6-digit code",
    authCodeInvalid: "Enter the 6-digit code from the text message.",
    authSendCode: "Send code",
    authResendCode: "Resend code",
    authVerifyCode: "Sign in and sync reports",
    authCodeSent: "Verification code sent. Check your messages.",
    authPhoneError: "The code was not sent. Please try again shortly.",
    authOverseas: "Overseas users",
    authGoogle: "Continue with Google",
    authMagicLink: "Send email code",
    authSignedIn: "Signed in",
    authSignOut: "Sign out",
    authCheckEmail: "Verification code sent. It remains valid for 10 minutes.",
    authUnavailable: "Cloud archive is not configured yet. Reports are saved on this device for now.",
    authError: "Sign-in could not finish. Please try again later.",
    birthDate: "Birth date",
    birthTime: "Birth hour",
    currentFocus: "Current focus",
    timeOptions: ["Zi hour 23:00-01:00", "Mao hour 05:00-07:00", "Wu hour 11:00-13:00", "You hour 17:00-19:00", "Hai hour 21:00-23:00"],
    readings: {
      career: { option: "Career opportunity", title: "Do not rush the opening; steady your range first", tags: ["steady first", "outside chances", "rhythm adjustment"], line: "The opening may not arrive immediately. Put your skills and resources in order first." },
      relationship: { option: "Relationships", title: "Set the boundary, then move closer", tags: ["slow warmth", "serious promise", "boundaries"], line: "Closeness is not made by rushing. First know what kind of steadiness you need." },
      emotion: { option: "Overthinking", title: "A heavy mind, and a heavy sense of duty", tags: ["deep thought", "responsibility", "quiet digestion"], line: "The matter may not be hard. The hard part is always trying to carry it alone." },
      money: { option: "Money choices", title: "Read cash flow first, then decide", tags: ["cash flow", "clear judgment", "avoid impulse"], line: "Slow is not the issue. The risk is handing away your rhythm when you get anxious." },
      other: { option: "Overall outlook", title: "Read the whole pattern, then find where effort matters most", tags: ["whole pattern", "clear priority", "next action"], line: "You do not need to name it perfectly yet. Start with the overall structure and locate what deserves attention." },
    },
    productsRegion: "Purchase options",
    purchaseLabel: "Purchase items",
    productKicker: "Purchase options",
    productTitle: "Three one-time services, chosen when you need them.",
    productSubtitle: "Generate a personalized preview for free. If it helps, sign in and pay to unlock the full report, which is then saved to My reports.",
    badges: { single: "single", featured: "recommended" },
    prices: {
      basic: { cny: "RMB ¥29.9", usd: "USD $4.2" },
      annual: { cny: "RMB ¥39.9", usd: "USD $5.6" },
    },
    products: [
      { key: "bazi", title: "Personal Structure Report", question: "Know yourself before you choose.", priceKey: "basic", action: "Generate personal structure report" },
      { key: "question", title: "One-Matter Analysis", question: "When the matter arrives, weigh it first.", priceKey: "basic", action: "Generate one-matter analysis" },
      { key: "annual", title: "Annual Rhythm Report", question: "From the reading date, look across the next 12 months.", priceKey: "annual", action: "Read annual rhythm report" },
    ],
    productDelivery: "Preview free; unlock the full report after payment",
    productRefund: "7-day dissatisfaction refund after generation",
    purchaseFlowLabel: "How purchase works",
    purchaseFlowTitle: "See whether it helps before you decide to unlock it.",
    purchaseFlowText: "Choose one service at a time. Preview without signing in; before unlocking, sign in so the order, access, and full report stay with one account.",
    purchaseSteps: [["01", "Choose", "Pick one service and enter details"], ["02", "Preview free", "Read a personalized excerpt"], ["03", "Sign in and pay", "Unlock only if the preview helps"], ["04", "Read the full report", "The complete report is saved to My reports"]],
    refundPromise: "7-day satisfaction promise",
    refundPromiseText: "Within 7 calendar days after a report is generated and first displayed, you may request a refund if you are dissatisfied. After the order is verified, the refund returns through the original payment method.",
    entitlementStatusLabel: "Access status",
    entitlementLockedTitle: "Start with a free preview",
    entitlementLockedText: "Generate a personalized preview first. If it helps, sign in to unlock the full report.",
    entitlementReady: "Opened, ready to generate",
    entitlementRemaining: "{count} left",
    entitlementUsedUp: "Used",
    simulateUnlock: "Test unlock",
    simulateUnlockAria: "Test unlock: {product}",
    testUnlockCurrent: "Test unlock current reading",
    testUnlockHint: "Test entry, shown only locally or through a test link.",
    testAccessReady: "Test access is open",
    testAccessHint: "Generate real reports directly. Test runs do not use paid access.",
    entitlementActive: "Opened",
    entitlementLocked: "Locked",
    annualLabel: "Annual rhythm · from generation date",
    annualTitle: "Read what is near, then the rhythm of the year.",
    annualText: "This is not cut by the calendar year. It starts from the moment you generate the report and organizes a full twelve months: what to steady now, and where to adjust later.",
    timelineLabel: "Next twelve months",
    coverageLabel: "Report range",
    coverageValue: "From reading date · full next 12 months",
    annualTimeline: [["Current month", "Settle the immediate priorities."], ["Next three months", "See the order of choices."], ["Next half year", "Watch the rhythm change."], ["Full twelve months", "Gather the priorities into one line."]],
    sampleRegion: "Product samples",
    sampleKicker: "Reading samples",
    sampleTitle: "Few words. The point first.",
    previews: [["Personal Structure Report", "Know yourself; the mind steadies", "temperament, effort style, relationship habits"], ["One-Matter Analysis", "This matter asks for steadiness", "trend, risk, next step"], ["Annual Rhythm Report", "Steady what is near, adjust what is far", "next twelve months, chances, things to notice"]],
    methodRegion: "Method",
    methodKicker: "Why it earns trust",
    methodTitle: "Information is checked first; only then should advice be steady.",
    proof: [["Structured calculation", "Birth data enters a rule system before interpretation."], ["Advisor rules", "Human rules set the boundary for expression."], ["Clear interpretation", "Technical terms become usable language."], ["Consistency memory", "The same structure should not contradict itself later."]],
    closingRegion: "My reports entry",
    closingText: "Structures, questions, and annual rhythm reports all return to My reports.",
    closingTitle: "Read a little first, then decide how deep to go.",
    backToReading: "Back to structure entry",
    viewProducts: "View purchase options",
    footerTagline: "Eastern structure for a clearer view of your rhythm and choices.",
    footerDisclaimer: "Reports combine structured rules with AI. They support self-reflection and decisions, but do not replace medical, legal, financial, or mental-health advice.",
    footerAge: "Recommended for adults aged 18 and above.",
    footerCompanyLabel: "Operator",
    footerIcpLabel: "ICP filing",
    footerSupportLabel: "Support",
    footerLinks: { terms: "Terms", privacy: "Privacy", refund: "Refunds", contact: "Contact", license: "Business registration", ai: "AI model and labels" },
    businessDisclosureLabel: "Operator and business registration",
    businessDisclosureText: `${companyNameEn} · ${companyCreditCode}`,
    aiGeneratedLabel: "Content generated by AI · For reference only",
    generationRecovery: {
      title: "An earlier report has not been confirmed complete",
      text: "A refresh or network interruption will not deduct another use. Check the result with the original request ID.",
      action: "Recover result",
      checking: "Checking…",
      pending: "The report is still generating in real time. Check again shortly.",
      released: "The earlier generation did not complete. Your use remains available.",
      missing: "The earlier request was not found. The local recovery record was cleared.",
      error: "The request cannot be checked right now. Its recovery ID is still saved.",
      requestLabel: "Request ID",
      dismiss: "Not now",
    },
    legalBackHome: "Back home",
    legalUpdated: "Last updated: July 28, 2026",
    legalPages: {
      terms: {
        title: "Terms of Service",
        intro: "By using Youshu, you acknowledge the service boundaries below. These terms are written for the current public test and may be updated before full commercial launch.",
        sections: [
          ["Service nature", "Youshu provides personal structure reports, one-matter analysis, and annual rhythm references generated from traditional-culture structures, interpretation rules, and large language model output. The content supports self-insight and decision-making; it does not guarantee that any predicted event will happen."],
          ["Who should use it", "The service is recommended for users aged 18 and above. For medical, legal, investment, mental health crisis, personal safety, or other high-risk matters, consult a qualified professional or local emergency service first."],
          ["Your responsibility", "You should provide reasonably accurate birth date, birth time, birth place, and question context. Inaccurate input may affect the report. You remain responsible for deciding whether and how to use any suggestion."],
          ["Digital delivery", "Generation starts immediately after payment and the completed report is automatically saved to My reports. The stated 7-day satisfaction refund remains available after digital delivery."],
          ["AI content labels", "Report pages continuously display an AI-generated notice. Posters include a visible label, and downloaded images also carry metadata for generated status, service provider, and content ID. Keep these labels when sharing."],
          ["Prohibited use", "Do not use the service for unlawful activity, harassment, discrimination, manipulation, medical diagnosis, financial promises, or automated high-risk decisions."],
          ["Changes and contact", `We may update pages, pricing, benefits, and terms as the product test evolves. Questions can be sent to ${supportEmail}.`],
        ],
      },
      privacy: {
        title: "Privacy Policy",
        intro: "We collect only the information needed to generate and support your readings, and we aim to keep the purpose of that data clear.",
        sections: [
          ["What we collect", "Information you provide, including birth date, birth time, birth place, gender, reading focus, question content, language preference, and basic technical information required to operate the service."],
          ["How we use it", "We use this information to calculate structures, generate reports, improve prompts and service quality, handle support requests, and, once accounts are connected, help you retrieve report history."],
          ["Large model processing", "When generating a report, necessary structure data, question context, and language options may be sent to our large model provider. We do not display or ask users to submit a DeepSeek API key on the customer page."],
          ["Retention and deletion", "This device keeps up to 30 recent reports until you delete them or clear browser data. Cloud reports are retained while the account remains active. A pending recovery request stays on this device for at most 24 hours; security logs are generally kept for no more than six months; order and support records follow applicable legal retention periods."],
          ["Third-party and infrastructure services", "The site and API run on Alibaba Cloud servers in mainland China. Account authentication, report archives, entitlements, referrals, and feedback are processed in a mainland China production PostgreSQL database. Alibaba Cloud SMS sends mobile verification codes, the official DeepSeek API generates reports, and Alipay processes orders and payments. Each provider receives only the data needed for its service."],
          ["Your rights", `You can delete individual reports in My reports or email ${supportEmail} to request access, correction, deletion, or account closure.`],
        ],
      },
      refund: {
        title: "Refund Policy",
        intro: "We want you to use the report with confidence before deciding to keep it. All three one-time services include a 7-day dissatisfaction refund after generation.",
        sections: [
          ["Coverage", "Personal Structure Reports, One-Matter Analysis, and Annual Rhythm Reports are covered. You may request a refund within 7 calendar days after the report is generated and first displayed if you are dissatisfied."],
          ["How to request", `Email ${supportEmail} with your account, order time, purchased item, and a brief reason. We will acknowledge the request within 2 business days.`],
          ["Refund method", "After order verification, approved refunds are returned through the original payment method. Actual arrival time depends on the payment provider."],
          ["Exceptions and abuse", "Duplicate charges, successful payments without generation, and delivery failures are prioritized for refund or redelivery. We may verify and restrict service where repeated purchases and concentrated refund requests indicate clear abuse."],
        ],
      },
      contact: {
        title: "Contact",
        intro: "For report, order, refund, privacy, or partnership questions, contact us by email. We will review the relevant records and reply as soon as possible.",
        sections: [
          ["Support email", supportEmail],
          ["Operator", companyNameEn],
          ["Service scope", "Personal structure reports, one-matter analysis, annual rhythm reports, order refunds, and report archive questions."],
          ["Response time", "We try to reply within 2 business days. Complex order, refund, or privacy requests may take longer to verify."],
        ],
      },
    },
    generationErrorTitle: "Generation paused",
    apiErrors: {
      backendKey: "The model service is being configured. Please try again later or contact support.",
      questionRequired: "Please write the specific question first, then generate a one-matter analysis.",
      authRequired: "Your sign-in has expired. Please sign in again before generating the report.",
      entitlementRequired: "There is no available use for this service. Please check your purchase.",
      inProgress: "This report is already being generated. Please wait a moment and check again.",
      rateLimited: "Too many attempts were made. Please wait and try again; no extra use will be deducted.",
      default: "The report could not be generated. Please try again later.",
    },
  },
};

function YinYangOrb({ label }) {
  return (
    <div className="orb-stage" aria-label={label}>
      <div className="orb-glow" />
      <div className="orb-ring ring-one" />
      <div className="orb-ring ring-two" />
      <div className="orb-ring ring-three" />
      <div className="gua gua-top">
        <i />
        <i />
        <i />
      </div>
      <div className="gua gua-bottom">
        <i />
        <i />
        <i />
      </div>
      <div className="yin-orb">
        <span className="fish fish-light" />
        <span className="fish fish-dark" />
        <span className="eye eye-dark" />
        <span className="eye eye-light" />
      </div>
    </div>
  );
}

function stripMarkdownMarkers(text = "") {
  return text
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/^[-*+]\s+/, "")
    .replace(/^\d+[.)]\s+/, "")
    .trim();
}

function renderInlineMarkdown(text) {
  const parts = [];
  const pattern = /\*\*([^*]+)\*\*/g;
  let lastIndex = 0;
  let match;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.slice(lastIndex, match.index));
    }
    parts.push(<strong key={`strong-${match.index}`}>{match[1]}</strong>);
    lastIndex = pattern.lastIndex;
  }

  if (lastIndex < text.length) {
    parts.push(text.slice(lastIndex));
  }

  return parts.length ? parts : text;
}

function parseReportSections(content) {
  const sections = [];
  let current = { heading: "", blocks: [] };

  function pushListItem(item) {
    const previousBlock = current.blocks[current.blocks.length - 1];
    if (previousBlock?.type === "list") {
      previousBlock.items.push(item);
      return;
    }
    current.blocks.push({ type: "list", items: [item] });
  }

  content
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .forEach((line) => {
      const heading = line.match(/^#{1,4}\s+(.+)$/);
      const listItem = line.match(/^(?:[-*+]|\d+[.)])\s+(.+)$/);

      if (heading) {
        if (current.heading || current.blocks.length) {
          sections.push(current);
        }
        current = { heading: stripMarkdownMarkers(heading[1]), blocks: [] };
        return;
      }

      if (listItem) {
        pushListItem(stripMarkdownMarkers(listItem[1]));
        return;
      }

      current.blocks.push({ type: "paragraph", text: line });
    });

  if (current.heading || current.blocks.length) {
    sections.push(current);
  }

  return sections;
}

function getBlockText(block) {
  if (!block) {
    return "";
  }

  if (block.type === "list") {
    return block.items[0] || "";
  }

  return block.text || "";
}

function firstMeaningfulText(sections) {
  for (const section of sections) {
    for (const block of section.blocks) {
      const rawText = getBlockText(block);
      if (stripMarkdownMarkers(rawText)) {
        return rawText;
      }
    }
  }
  return "";
}

function firstMeaningfulLocator(sections) {
  for (let sectionIndex = 0; sectionIndex < sections.length; sectionIndex += 1) {
    const section = sections[sectionIndex];
    for (let blockIndex = 0; blockIndex < section.blocks.length; blockIndex += 1) {
      const text = stripMarkdownMarkers(getBlockText(section.blocks[blockIndex]));
      if (text) {
        return { sectionIndex, blockIndex };
      }
    }
  }
  return null;
}

function getDisplayReportSections(sections, openingLocator) {
  return sections
    .map((section, sectionIndex) => {
      const blocks = section.blocks.filter((block, blockIndex) => {
        if (openingLocator?.sectionIndex === sectionIndex && openingLocator?.blockIndex === blockIndex) {
          return false;
        }

        return Boolean(stripMarkdownMarkers(getBlockText(block)));
      });

      return { ...section, blocks };
    })
    .filter((section) => section.blocks.length > 0);
}

function ReportBody({ content, t }) {
  if (!content) {
    return null;
  }

  const sections = parseReportSections(content);
  const openingText = firstMeaningfulText(sections);
  const openingLocator = firstMeaningfulLocator(sections);
  const displaySections = getDisplayReportSections(sections, openingLocator);

  return (
    <div className="report-body report-scroll">
      {openingText ? (
        <section className="report-verdict">
          <span>{t.reportVerdict}</span>
          <p>{renderInlineMarkdown(openingText)}</p>
        </section>
      ) : null}

      {displaySections.length ? (
        <nav className="report-outline" aria-label={t.reportOutline}>
          <span>{t.reportOutline}</span>
          <div>
            {displaySections.map((section, sectionIndex) => (
              <a href={`#report-section-${sectionIndex}`} key={`outline-${section.heading}-${sectionIndex}`}>
                <b>{String(sectionIndex + 1).padStart(2, "0")}</b>
                {section.heading || t.reportHighlights}
              </a>
            ))}
          </div>
        </nav>
      ) : null}

      <div className="report-chapters">
        {displaySections.map((section, sectionIndex) => (
          <section className="report-block" id={`report-section-${sectionIndex}`} key={`${section.heading}-${sectionIndex}`}>
            <div className="chapter-mark">{String(sectionIndex + 1).padStart(2, "0")}</div>
            <div>
              {section.heading ? <h4>{section.heading}</h4> : null}
              {section.blocks.map((block, blockIndex) => {
                if (block.type === "list") {
                  return (
                    <ul key={`${section.heading}-list-${blockIndex}`}>
                      {block.items.map((item, itemIndex) => (
                        <li key={`${section.heading}-item-${blockIndex}-${itemIndex}`}>{renderInlineMarkdown(item)}</li>
                      ))}
                    </ul>
                  );
                }

                return <p key={`${section.heading}-${blockIndex}`}>{renderInlineMarkdown(block.text)}</p>;
              })}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}

function readJsonStorage(storage, key, fallback) {
  if (!storage) {
    return fallback;
  }

  try {
    const value = storage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

function getStoredReport() {
  if (typeof window === "undefined") {
    return null;
  }

  return readJsonStorage(window.sessionStorage, reportStorageKey, null);
}

function getStoredReports() {
  if (typeof window === "undefined") {
    return [];
  }

  const reports = readJsonStorage(window.localStorage, reportArchiveStorageKey, []);
  return Array.isArray(reports) ? reports : [];
}

function getStoredEntitlements() {
  if (typeof window === "undefined") {
    return normalizeEntitlements();
  }

  return normalizeEntitlements(readJsonStorage(window.localStorage, entitlementStorageKey, {}));
}

function saveStoredEntitlements(entitlements) {
  if (typeof window === "undefined") {
    return;
  }

  try {
    window.localStorage.setItem(entitlementStorageKey, JSON.stringify(normalizeEntitlements(entitlements)));
  } catch {
    // Entitlements stay in memory if local storage is unavailable.
  }
}

function saveStoredReports(reports) {
  if (typeof window === "undefined") {
    return;
  }

  try {
    window.localStorage.setItem(reportArchiveStorageKey, JSON.stringify(reports.slice(0, maxStoredReports)));
  } catch {
    // Local archive is a P0 convenience; report delivery should not fail if storage is unavailable.
  }
}

function createReportId() {
  if (typeof window !== "undefined" && window.crypto?.randomUUID) {
    return window.crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function formatArchiveDate(value) {
  if (!value) {
    return "";
  }
  return value.replaceAll("-", "/");
}

function formatReportDateTime(value, language = "zh-CN") {
  if (!value) {
    return "";
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "";
  }

  if (language === "en") {
    return new Intl.DateTimeFormat("en", {
      timeZone: "Asia/Shanghai",
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(date);
  }

  const parts = new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  })
    .formatToParts(date)
    .reduce((result, part) => {
      result[part.type] = part.value;
      return result;
    }, {});

  return `${parts.year}/${parts.month}/${parts.day} ${parts.hour}:${parts.minute}`;
}

function formatBirthInfo(report) {
  return [formatArchiveDate(report?.birthDate), report?.birthTime, report?.birthPlace].filter(Boolean).join(" · ");
}

function getReportSummary(content) {
  if (!content) {
    return "";
  }

  const summaryLine = content
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .find((line) => !line.startsWith("#"));

  return summaryLine ? stripMarkdownMarkers(summaryLine) : "";
}

function buildConsistencyProfile(content) {
  const sections = parseReportSections(content);
  const openingLocator = firstMeaningfulLocator(sections);
  const displaySections = getDisplayReportSections(sections, openingLocator);
  const opening = stripMarkdownMarkers(firstMeaningfulText(sections));
  const points = displaySections.slice(0, 3).map((section) => {
    const detail = stripMarkdownMarkers(getBlockText(section.blocks[0]));
    return detail ? `${section.heading || "判断"}：${detail}` : "";
  });

  return [opening, ...points].filter(Boolean).join("\n").slice(0, 900);
}

function getLatestCoreProfile(reports) {
  const latestProfileReport = reports.find((savedReport) => savedReport.type === "bazi" && savedReport.content);
  if (!latestProfileReport) {
    return "";
  }

  return latestProfileReport.consistencyProfile || buildConsistencyProfile(latestProfileReport.content);
}

function buildArchivedReport(report, context) {
  const createdAt = new Date().toISOString();

  return {
    ...report,
    id: report.id || createReportId(),
    createdAt,
    birthDate: context.birthDate,
    birthTime: context.birthTime,
    birthPlace: context.birthPlace,
    calendarType: context.calendarType,
    isLeapMonth: context.isLeapMonth,
    useTrueSolarTime: context.useTrueSolarTime,
    birthLongitude: context.birthLongitude,
    ziHourConvention: context.ziHourConvention,
    focus: context.focus,
    question: context.question,
    summary: getReportSummary(report.content),
    consistencyProfile: buildConsistencyProfile(report.content),
    promptVersion: reportPromptVersion,
  };
}

function getCurrentPage() {
  if (typeof window === "undefined") {
    return "home";
  }

  const pathname = window.location.pathname.replace(/^\/+/, "") || "home";
  if (pathname === "reports") {
    return "reports";
  }
  if (pathname === "report") {
    return "report";
  }
  if (pathname === "checkout") {
    return "checkout";
  }
  if (pathname === "payment/result") {
    return "paymentResult";
  }
  if (legalPageIds.includes(pathname)) {
    return pathname;
  }
  return "home";
}

function getDisplayPrice(price, language) {
  return language === "en" ? price.usd : price.cny;
}

function formatGenerationReviewDate(value, language) {
  const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) {
    return value;
  }

  const [, year, month, day] = match;
  if (language === "en") {
    return `${year}/${month}/${day}`;
  }
  return `${year}年${Number(month)}月${Number(day)}日`;
}

function isTestUnlockMode() {
  if (typeof window === "undefined") {
    return false;
  }

  const hostname = window.location.hostname;
  const isLocalHost = hostname === "localhost" || hostname === "127.0.0.1" || hostname === "::1";
  return isLocalHost;
}

function isDirectTestAccessMode() {
  if (typeof window === "undefined") {
    return false;
  }

  const hostname = window.location.hostname;
  const isLocalHost = hostname === "localhost" || hostname === "127.0.0.1" || hostname === "::1";
  return isLocalHost && new URLSearchParams(window.location.search).get("test") === "1";
}

function getInitialEntryMode() {
  if (typeof window === "undefined") {
    return "bazi";
  }

  const requestedMode = new URLSearchParams(window.location.search).get("mode");
  return entryModeIds.includes(requestedMode) ? requestedMode : "bazi";
}

function friendlyApiError(rawError, t) {
  if (!rawError) {
    return t.apiErrors.default;
  }
  if (/DeepSeek API key is not configured/i.test(rawError)) {
    return t.apiErrors.backendKey;
  }
  if (/question is required/i.test(rawError)) {
    return t.apiErrors.questionRequired;
  }
  if (/Authentication required|Invalid or expired session/i.test(rawError)) {
    return t.apiErrors.authRequired;
  }
  if (/No report entitlement is available/i.test(rawError)) {
    return t.apiErrors.entitlementRequired;
  }
  if (/already being generated/i.test(rawError)) {
    return t.apiErrors.inProgress;
  }
  if (/Too many report requests/i.test(rawError)) {
    return t.apiErrors.rateLimited;
  }
  return t.apiErrors.default;
}

function fillTemplate(template, values) {
  return Object.entries(values).reduce((text, [key, value]) => text.replace(`{${key}}`, String(value)), template);
}

function normalizeChinaPhone(value) {
  const digits = value.replace(/\D/g, "");
  if (/^1[3-9]\d{9}$/.test(digits)) {
    return `+86${digits}`;
  }
  if (/^861[3-9]\d{9}$/.test(digits)) {
    return `+${digits}`;
  }
  return "";
}

function getAccessTitle(access, t) {
  if (access.unlocked && access.source === "test") {
    return t.testAccessReady;
  }
  if (access.unlocked) {
    return t.entitlementReady;
  }
  if (access.source === "used") {
    return t.entitlementUsedUp;
  }
  return t.entitlementLockedTitle;
}

function getProductStatusLabel(status, t) {
  if (status === "active") {
    return t.entitlementActive;
  }
  if (status === "used") {
    return t.entitlementUsedUp;
  }
  return t.entitlementLocked;
}

function LegalPage({ language, t, pageId, onBackHome }) {
  const page = t.legalPages[pageId]
    || complianceCopy[language]?.[pageId]
    || complianceCopy["zh-CN"][pageId]
    || t.legalPages.terms;

  return (
    <main className="legal-page">
      <section className="legal-hero" aria-label={page.title} role="region">
        <div className="legal-copy">
          <p className="kicker">{t.legalUpdated}</p>
          <h1>{page.title}</h1>
          <p>{page.intro}</p>
          <button className="primary-btn" type="button" onClick={onBackHome}>
            {t.legalBackHome}
          </button>
          {pageId === "license" ? (
            <a className="legal-external-link" href={businessRegistryUrl} target="_blank" rel="noreferrer">
              {language === "en" ? "Verify in the national registry ↗" : "前往国家企业信用信息公示系统核验 ↗"}
            </a>
          ) : null}
        </div>
        <article className="legal-card">
          {page.sections.map(([heading, text]) => (
            <section className="legal-block" key={heading}>
              <h2>{heading}</h2>
              <p>{text}</p>
            </section>
          ))}
        </article>
      </section>
    </main>
  );
}

function submitAlipayForm(checkout) {
  if (!checkout?.gatewayUrl || !checkout?.formFields) {
    throw new Error("Invalid Alipay checkout response");
  }

  const form = document.createElement("form");
  form.method = "POST";
  form.action = checkout.gatewayUrl;
  form.acceptCharset = "utf-8";
  Object.entries(checkout.formFields).forEach(([name, value]) => {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = name;
    input.value = String(value);
    form.appendChild(input);
  });
  document.body.appendChild(form);
  form.submit();
  form.remove();
}

function CheckoutPage({ language, t, navigate, supabaseClient, cloudUser }) {
  const [accepted, setAccepted] = useState(false);
  const [notice, setNotice] = useState("");
  const [isPaying, setIsPaying] = useState(false);
  const clientRequestIdRef = useRef("");
  const labels = checkoutCopy[language] || checkoutCopy["zh-CN"];
  const requestedProduct = typeof window === "undefined"
    ? "annual"
    : new URLSearchParams(window.location.search).get("product");
  const product = t.products.find((item) => item.key === requestedProduct) || t.products[2];
  const price = t.prices[product.priceKey].cny;
  const agreementLinks = [
    ["terms", t.footerLinks.terms],
    ["privacy", t.footerLinks.privacy],
    ["refund", t.footerLinks.refund],
  ];

  async function startAlipayPayment() {
    if (!supabaseClient || !cloudUser) {
      setNotice(labels.signInRequired);
      return;
    }

    setIsPaying(true);
    setNotice("");
    try {
      const { data } = await supabaseClient.auth.getSession();
      const accessToken = data?.session?.access_token;
      if (!accessToken) {
        setNotice(labels.signInRequired);
        return;
      }
      if (!clientRequestIdRef.current) {
        clientRequestIdRef.current = typeof globalThis.crypto?.randomUUID === "function"
          ? globalThis.crypto.randomUUID()
          : `checkout_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      }
      const response = await fetch("/api/payments/alipay/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          productKey: product.key,
          clientRequestId: clientRequestIdRef.current,
        }),
      });
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || "Unable to create payment order");
      }
      submitAlipayForm(result.checkout);
    } catch {
      setNotice(labels.payNotice);
    } finally {
      setIsPaying(false);
    }
  }

  return (
    <main className="checkout-page" lang={language}>
      <section className="checkout-shell" aria-label={labels.kicker} role="region">
        <div className="checkout-intro">
          <p className="kicker">{labels.kicker}</p>
          <h1>{labels.title}</h1>
          <p>{labels.subtitle}</p>
          <button className="checkout-back" type="button" onClick={() => navigate("/#products")}>
            ← {labels.back}
          </button>
        </div>

        <article className="checkout-card">
          <div className="checkout-product">
            <span>{labels.productLabel}</span>
            <h2>{product.title}</h2>
            <p>{product.question}</p>
          </div>

          <div className="checkout-total">
            <span>{labels.amountLabel}</span>
            <strong>{price}</strong>
          </div>

          <dl className="checkout-details">
            <div>
              <dt>{labels.deliveryLabel}</dt>
              <dd>{labels.deliveryValue}</dd>
            </div>
            <div>
              <dt>{labels.refundLabel}</dt>
              <dd>{labels.refundValue}</dd>
            </div>
          </dl>

          <label className="checkout-agreement">
            <input
              type="checkbox"
              checked={accepted}
              onChange={(event) => {
                setAccepted(event.target.checked);
                setNotice("");
              }}
            />
            <span>
              {labels.agreementPrefix}{" "}
              {agreementLinks.map(([pageId, text], index) => (
                <span key={pageId}>
                  {index ? labels.agreementJoin : ""}
                  <a
                    href={`/${pageId}`}
                    onClick={(event) => {
                      event.preventDefault();
                      navigate(`/${pageId}`);
                    }}
                  >
                    {text}
                  </a>
                </span>
              ))}
            </span>
          </label>

          <button
            className="alipay-button"
            type="button"
            disabled={!accepted || isPaying}
            onClick={startAlipayPayment}
          >
            <span aria-hidden="true">支</span>
            {isPaying ? labels.payingAction : labels.payAction}
          </button>
          <p className="checkout-secure-note">{labels.secureNote}</p>
          {notice ? (
            <div className="checkout-notice" role="status">
              <p>{notice}</p>
              {!cloudUser ? (
                <button type="button" onClick={() => navigate("/reports")}>{labels.signInAction}</button>
              ) : null}
            </div>
          ) : null}
        </article>
      </section>
    </main>
  );
}

function PaymentResultPage({
  language,
  t,
  navigate,
  supabaseClient,
  cloudUser,
  onPaymentConfirmed,
  onContinue,
}) {
  const labels = paymentResultCopy[language] || paymentResultCopy["zh-CN"];
  const searchParams = typeof window === "undefined"
    ? new URLSearchParams()
    : new URLSearchParams(window.location.search);
  const orderNo = searchParams.get("out_trade_no") || searchParams.get("orderNo") || "";
  const isDevPaidPreview = import.meta.env.DEV && searchParams.get("ui_preview") === "paid";
  const previewOrder = isDevPaidPreview
    ? {
        orderNo: orderNo || "YS-UI-PREVIEW",
        productKey: searchParams.get("product") || "bazi",
        amount: searchParams.get("amount") || "29.90",
        status: "paid",
      }
    : null;
  const [order, setOrder] = useState(previewOrder);
  const [status, setStatus] = useState(isDevPaidPreview ? labels.paid : orderNo ? labels.checking : labels.missing);
  const [isChecking, setIsChecking] = useState(false);
  const [resultState, setResultState] = useState(isDevPaidPreview ? "paid" : orderNo ? "checking" : "missing");
  const [deliveryState, setDeliveryState] = useState(isDevPaidPreview ? "generating" : "idle");
  const pollCountRef = useRef(0);
  const autoContinueRef = useRef(false);

  async function checkOrder({ silent = false } = {}) {
    if (isDevPaidPreview) {
      return;
    }
    if (!orderNo) {
      setResultState("missing");
      setStatus(labels.missing);
      return;
    }
    if (!supabaseClient || !cloudUser) {
      setResultState("signin");
      setStatus(labels.signInRequired);
      return;
    }
    setIsChecking(true);
    if (!silent) {
      setResultState("checking");
      setStatus(labels.checking);
    }
    try {
      const { data } = await supabaseClient.auth.getSession();
      const accessToken = data?.session?.access_token;
      if (!accessToken) {
        setResultState("signin");
        setStatus(labels.signInRequired);
        return;
      }
      const response = await fetch(`/api/payments/orders/${encodeURIComponent(orderNo)}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      const result = await response.json();
      if (!response.ok || !result.order) {
        setResultState("failed");
        setStatus(labels.failed);
        return;
      }
      setOrder(result.order);
      if (result.order.status === "paid") {
        setResultState("paid");
        setStatus(labels.paid);
        await onPaymentConfirmed();
      } else {
        setResultState("pending");
        setStatus(labels.pending);
      }
    } catch {
      setResultState("failed");
      setStatus(labels.failed);
    } finally {
      setIsChecking(false);
    }
  }

  useEffect(() => {
    checkOrder();
  }, [cloudUser, orderNo]);

  useEffect(() => {
    if (resultState !== "pending" || pollCountRef.current >= 24) {
      return undefined;
    }
    const timer = window.setTimeout(() => {
      pollCountRef.current += 1;
      checkOrder({ silent: true });
    }, 2500);
    return () => window.clearTimeout(timer);
  }, [resultState, order?.status]);

  useEffect(() => {
    if (isDevPaidPreview || resultState !== "paid" || !order?.productKey || autoContinueRef.current) {
      return;
    }
    autoContinueRef.current = true;
    setDeliveryState("generating");
    Promise.resolve(onContinue(order.productKey))
      .then((started) => {
        if (started === false) {
          setDeliveryState("needs-input");
        }
      })
      .catch(() => {
        setDeliveryState("failed");
      });
  }, [resultState, order?.productKey]);

  const product = t?.products?.find((item) => item.key === order?.productKey);
  const price = product?.priceKey ? t?.prices?.[product.priceKey]?.cny : null;
  const amount = order?.amount ? `¥${Number(order.amount).toFixed(2)}` : price || "—";
  const accountValue = String(cloudUser?.phone || cloudUser?.email || "");
  const maskedAccount = accountValue
    ? accountValue.includes("@")
      ? accountValue.replace(/^(.{2}).*(@.*)$/, "$1***$2")
      : accountValue.replace(/^(\+?86)?(\d{3})\d{4}(\d{4})$/, "$1 $2****$3").trim()
    : "—";
  const completedProgress = resultState === "paid"
    ? 2
    : resultState === "pending" || resultState === "checking"
      ? 1
      : 0;

  function continueDelivery() {
    if (!order?.productKey || deliveryState === "generating") {
      return;
    }
    if (deliveryState === "needs-input") {
      navigate("/#reading");
      return;
    }
    setDeliveryState("generating");
    Promise.resolve(onContinue(order.productKey))
      .then((started) => {
        if (started === false) {
          setDeliveryState("needs-input");
        }
      })
      .catch(() => {
        setDeliveryState("failed");
      });
  }

  return (
    <main className="payment-result-page" lang={language}>
      <section className={`payment-result-shell is-${resultState}`} aria-label={labels.kicker} role="region">
        <header className="payment-result-header">
          <div className="payment-result-heading-group">
            {resultState === "paid" ? (
              <div className="payment-result-mark" aria-hidden="true">
                <span>✓</span>
                <small>{labels.confirmed}</small>
              </div>
            ) : null}
            <div className="payment-result-header-copy">
              <p className="kicker">
                {resultState === "paid" ? labels.confirmedKicker : labels.kicker}
              </p>
              <h1>{labels.titles[resultState]}</h1>
              <p>{labels.descriptions[resultState]}</p>
            </div>
          </div>
          {resultState === "paid" ? (
            <div className="payment-result-confirmation" aria-label={labels.orderSummary}>
              <span>{labels.paidReceipt}</span>
              <strong>{amount}</strong>
              <small>{product?.title || order?.productKey || labels.accountBound}</small>
            </div>
          ) : null}
        </header>

        <div className="payment-result-body">
          <section className="payment-delivery" aria-labelledby="payment-delivery-title">
            <div className="payment-section-heading">
              <h2 id="payment-delivery-title">
                {resultState === "paid" ? labels.delivery : labels.resultStatus}
              </h2>
            </div>
            {resultState === "paid" ? (
              <div className="payment-delivery-lead">
                <span className="payment-delivery-live" aria-hidden="true" />
                <div>
                  <strong>{labels.deliveryLead}</strong>
                  <p>{labels.deliveryLeadText}</p>
                </div>
              </div>
            ) : null}
            {resultState === "paid" ? (
              <ol className="payment-progress">
                {labels.progress.map((step, index) => (
                  <li
                    className={index < completedProgress ? "is-complete" : index === completedProgress ? "is-current" : ""}
                    key={step}
                  >
                    <span aria-hidden="true">{index < completedProgress ? "✓" : index + 1}</span>
                    <div>
                      <strong>
                        {index === 2 && deliveryState === "needs-input" ? labels.restoreDraftStep : step}
                      </strong>
                      <small>{labels.progressDetails[index]}</small>
                    </div>
                  </li>
                ))}
              </ol>
            ) : null}
            <p className={`payment-result-status ${resultState === "paid" ? "is-paid" : ""}`} role="status">
              {resultState === "paid" && deliveryState === "needs-input"
                ? labels.restoreDraftStatus
                : status}
            </p>
            {resultState !== "missing" ? (
              <div className="payment-result-assurance">
                <strong>{resultState === "paid" ? labels.assuranceTitle : labels.orderSafeTitle}</strong>
                <p>{resultState === "paid" ? labels.assuranceText : labels.orderSafeText}</p>
              </div>
            ) : null}
          </section>

          <section className="payment-order-summary" aria-labelledby="payment-order-summary-title">
            <div className="payment-section-heading">
              <h2 id="payment-order-summary-title">{labels.orderSummary}</h2>
            </div>
            <dl className="payment-order-facts">
              <div>
                <dt>{labels.product}</dt>
                <dd>{product?.title || order?.productKey || "—"}</dd>
              </div>
              <div>
                <dt>{labels.amount}</dt>
                <dd>{amount}</dd>
              </div>
              <div>
                <dt>{labels.account}</dt>
                <dd>{maskedAccount}</dd>
              </div>
            </dl>
            <div className="payment-order-reference">
              <span>{labels.orderNo}</span>
              <code>{orderNo || "—"}</code>
            </div>
          </section>
        </div>

        <div className="payment-result-actions">
          {resultState === "signin" ? (
            <button
              className="primary-btn"
              type="button"
              onClick={() => navigate(`/reports?next=payment-result&orderNo=${encodeURIComponent(orderNo)}`)}
            >
              {labels.signIn}
            </button>
          ) : order?.status === "paid" ? (
            deliveryState !== "generating" ? (
              <button
                className="primary-btn"
                type="button"
                onClick={continueDelivery}
              >
                {deliveryState === "needs-input"
                    ? labels.restoreDraft
                  : deliveryState === "failed"
                    ? labels.retryDelivery
                    : labels.continue}
              </button>
            ) : null
          ) : orderNo ? (
            <button className="primary-btn" type="button" onClick={() => checkOrder()} disabled={isChecking || !orderNo}>
              {isChecking ? labels.checking : labels.checkAgain}
            </button>
          ) : null}
          {resultState === "paid" && deliveryState === "generating" ? (
            <p className="payment-result-auto-open" role="status">
              <span aria-hidden="true" />
              {labels.keepOpen}
            </p>
          ) : null}
          <div className="payment-result-links">
            <button className="text-btn" type="button" onClick={() => navigate("/reports")}>
              {labels.reports}
            </button>
            <button className="text-btn" type="button" onClick={() => navigate("/refund")}>
              {labels.support}
            </button>
          </div>
        </div>
      </section>
    </main>
  );
}

function SiteFooter({ t, navigate }) {
  return (
    <footer className="site-footer">
      <div className="footer-brand">
        <span className="brand-mark">有</span>
        <div>
          <strong>有数</strong>
          <p>{t.footerTagline}</p>
        </div>
      </div>
      <nav aria-label={t.footerLinks.terms}>
        {legalPageIds.map((pageId) => (
          <a href={`/${pageId}`} key={pageId} onClick={(event) => {
            event.preventDefault();
            navigate(`/${pageId}`);
          }}>
            {t.footerLinks[pageId]}
          </a>
        ))}
      </nav>
      <div className="footer-meta">
        <p>{t.footerDisclaimer}</p>
        <p>{t.footerAge}</p>
        <a
          className="footer-business-disclosure"
          href="/license"
          onClick={(event) => {
            event.preventDefault();
            navigate("/license");
          }}
        >
          <span>{t.businessDisclosureLabel}</span>
          <strong>{t.businessDisclosureText}</strong>
        </a>
        <p>
          {t.footerIcpLabel}：
          <a href={icpUrl} target="_blank" rel="noreferrer">
            {icpNumber}
          </a>
        </p>
        <p>
          {t.footerSupportLabel}：<a href={`mailto:${supportEmail}`}>{supportEmail}</a>
        </p>
      </div>
    </footer>
  );
}

function getReportTypeLabel(report, t) {
  return t.entryModes[report?.type]?.title || t.reportUnknownType;
}

function getReportTypeEyebrow(report, t) {
  return t.entryModes[report?.type]?.eyebrow || t.reportPageKicker;
}

function getReportArchiveContext(report, t) {
  if (report?.type === "question" && report.question) {
    return report.question;
  }
  if (report?.type === "annual") {
    return t.entryModes.annual.summary;
  }
  return report?.focus || t.entryModes.bazi.summary;
}

function AuthPanel({
  t,
  cloudEnabled,
  user,
  authMethod,
  phone,
  phoneCode,
  phoneOtpSent,
  email,
  status,
  onAuthMethodChange,
  onPhoneChange,
  onPhoneCodeChange,
  onSendPhoneCode,
  onVerifyPhoneCode,
  onEmailChange,
  onGoogleSignIn,
  onMagicLink,
  onVerifyEmailCode,
  onSignOut,
}) {
  if (!cloudEnabled) {
    return <p className="auth-note">{t.authUnavailable}</p>;
  }

  if (user) {
    return (
      <div className="auth-panel signed-in">
        <div>
          <span>{t.authSignedIn}</span>
          <strong>{user.email || user.phone}</strong>
        </div>
        <button type="button" onClick={onSignOut}>
          {t.authSignOut}
        </button>
      </div>
    );
  }

  return (
    <div className="auth-panel">
      <div>
        <h2>{t.authTitle}</h2>
        <p>{t.authText}</p>
      </div>
      <div className="auth-actions">
        <p className="auth-method-heading">{t.authPhoneTab}</p>
        <div className="auth-form auth-phone-form">
          <label>
            {t.authPhoneLabel}
            <input
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              value={phone}
              onChange={(event) => onPhoneChange(event.target.value)}
              placeholder={t.authPhonePlaceholder}
            />
          </label>
          <label>
            {t.authPhoneCodeLabel}
            <input
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={phoneCode}
              onChange={(event) => onPhoneCodeChange(event.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder={t.authPhoneCodePlaceholder}
            />
          </label>
          <div className="auth-phone-actions">
            <button type="button" onClick={onSendPhoneCode}>
              {phoneOtpSent ? t.authResendCode : t.authSendCode}
            </button>
            <button
              className="auth-verify-button"
              type="button"
              onClick={onVerifyPhoneCode}
              disabled={!/^\d{6}$/.test(phoneCode)}
            >
              {t.authVerifyCode}
            </button>
          </div>
        </div>
      </div>
      {status ? <p className="auth-note">{status}</p> : null}
    </div>
  );
}

function ReportsPage({
  t,
  reports,
  onOpenReport,
  onDeleteReport,
  onBackHome,
  cloudEnabled,
  cloudUser,
  authMethod,
  authPhone,
  authPhoneCode,
  phoneOtpSent,
  authEmail,
  authStatus,
  onAuthMethodChange,
  onAuthPhoneChange,
  onAuthPhoneCodeChange,
  onSendPhoneCode,
  onVerifyPhoneCode,
  onAuthEmailChange,
  onGoogleSignIn,
  onMagicLink,
  onVerifyEmailCode,
  onSignOut,
}) {
  const [activeFilter, setActiveFilter] = useState("all");
  const reportTypes = ["all", "bazi", "annual", "question"];
  const filteredReports = activeFilter === "all" ? reports : reports.filter((savedReport) => savedReport.type === activeFilter);

  return (
    <main className="report-page reports-page">
      <section className="report-hero reports-hero" aria-label={t.reportsPageRegion} role="region">
        <div className="report-hero-copy">
          <p className="kicker">{cloudUser ? t.reportsPageKicker : t.signedOutPageKicker}</p>
          <h1>{cloudUser ? t.reportsPageTitle : t.signedOutPageTitle}</h1>
          <p>{cloudUser ? t.reportsPageText : t.signedOutPageText}</p>
          <button className="primary-btn" type="button" onClick={onBackHome}>
            {t.backToReading}
          </button>
        </div>
        <article className="report-archive-card" aria-label={t.reportsPageRegion}>
          <AuthPanel
            t={t}
            cloudEnabled={cloudEnabled}
            user={cloudUser}
            authMethod={authMethod}
            phone={authPhone}
            phoneCode={authPhoneCode}
            phoneOtpSent={phoneOtpSent}
            email={authEmail}
            status={authStatus}
            onAuthMethodChange={onAuthMethodChange}
            onPhoneChange={onAuthPhoneChange}
            onPhoneCodeChange={onAuthPhoneCodeChange}
            onSendPhoneCode={onSendPhoneCode}
            onVerifyPhoneCode={onVerifyPhoneCode}
            onEmailChange={onAuthEmailChange}
            onGoogleSignIn={onGoogleSignIn}
            onMagicLink={onMagicLink}
            onVerifyEmailCode={onVerifyEmailCode}
            onSignOut={onSignOut}
          />
          {cloudUser ? (
            <>
              <aside className="privacy-rights-entry">
                <div>
                  <strong>{t.privacyRightsTitle}</strong>
                  <p>{t.privacyRightsText}</p>
                </div>
                <a href={`mailto:${supportEmail}?subject=${encodeURIComponent("有数个人信息请求")}`}>
                  {t.privacyRightsAction}
                </a>
              </aside>
              {reports.length ? (
                <>
                  <div className="report-archive-head">
                    <div>
                      <span>
                        {reports.length} {t.reportsCount}
                      </span>
                    </div>
                    <div className="report-filter" role="group" aria-label={t.reportFiltersLabel}>
                      {reportTypes.map((type) => (
                        <button
                          className={activeFilter === type ? "is-active" : ""}
                          type="button"
                          key={type}
                          aria-pressed={activeFilter === type}
                          onClick={() => setActiveFilter(type)}
                        >
                          {t.reportFilters[type]}
                        </button>
                      ))}
                    </div>
                  </div>
                  {filteredReports.length ? (
                    <div className="report-list">
                      {filteredReports.map((savedReport) => {
                        const reportType = getReportTypeLabel(savedReport, t);
                        const birthLine = [formatArchiveDate(savedReport.birthDate), savedReport.birthPlace].filter(Boolean).join(" · ");
                        const createdAt = formatReportDateTime(savedReport.createdAt, savedReport.language || "zh-CN");
                        const context = getReportArchiveContext(savedReport, t);

                        return (
                          <div className="report-list-row" key={savedReport.id}>
                            <button
                              className={`report-list-item report-type-${savedReport.type || "unknown"}`}
                              type="button"
                              onClick={() => onOpenReport(savedReport)}
                            >
                              <span>{reportType}</span>
                              <strong>{savedReport.summary || reportType}</strong>
                              <p>{context}</p>
                              <div className="report-list-meta">
                                {birthLine ? <small>{birthLine}</small> : null}
                                {createdAt ? <small>{createdAt}</small> : null}
                              </div>
                              <em>{t.reportOpenAction}</em>
                            </button>
                            <button
                              className="report-delete-button"
                              type="button"
                              aria-label={fillTemplate(t.reportDeleteLabel, { title: savedReport.summary || reportType })}
                              onClick={() => {
                                if (window.confirm(t.reportDeleteConfirm)) {
                                  onDeleteReport(savedReport);
                                }
                              }}
                            >
                              {t.reportDeleteAction}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="report-filter-empty">{t.reportFilterEmpty}</p>
                  )}
                </>
              ) : (
                <div className="empty-report">
                  <h2>{t.reportsEmptyTitle}</h2>
                  <p>{t.reportsEmptyText}</p>
                </div>
              )}
            </>
          ) : null}
        </article>
      </section>
    </main>
  );
}

function SharePosterPanel({ report, cloudUser, inviteUrl, onRequestInvite, onClose }) {
  const canvasRef = useRef(null);
  const [styleId, setStyleId] = useState("ink");
  const [inviterLabel, setInviterLabel] = useState("我");
  const [isRendering, setIsRendering] = useState(true);
  const [status, setStatus] = useState("");
  const effectiveUrl = inviteUrl || buildReferralUrl(
    typeof window === "undefined" ? "https://dongfangyoushu.com.cn" : window.location.origin,
    "",
  );

  useEffect(() => {
    let active = true;
    setIsRendering(true);
    renderSharePoster(canvasRef.current, {
      report,
      styleId,
      inviteUrl: effectiveUrl,
      inviterLabel: inviterLabel.trim() || "我",
    }).then(() => {
      if (active) {
        setIsRendering(false);
      }
    }).catch(() => {
      if (active) {
        setStatus("海报生成失败，请稍后重试。");
        setIsRendering(false);
      }
    });
    return () => {
      active = false;
    };
  }, [effectiveUrl, inviterLabel, report, styleId]);

  async function prepareRewardLink() {
    setStatus("");
    try {
      await onRequestInvite();
      setStatus("邀请二维码已绑定。每位新用户首次登录体验只计 1 次。");
    } catch (error) {
      setStatus(error.message || "邀请二维码生成失败。");
    }
  }

  return (
    <div className="share-poster-backdrop" role="dialog" aria-modal="true" aria-labelledby="share-poster-title">
      <section className="share-poster-panel">
        <button className="share-poster-close" type="button" onClick={onClose} aria-label="关闭海报">×</button>
        <div className="share-poster-copy">
          <p className="kicker">朋友圈分享海报</p>
          <h2 id="share-poster-title">分享一点共鸣，不分享你的隐私。</h2>
          <p>只说你愿意被看见的部分：一句近况、三个关键词。生辰、出生地、具体问题和报告内容都不会出现。</p>

          <label className="share-poster-label">
            <span>海报称呼（可选，建议不用真名）</span>
            <input
              value={inviterLabel}
              maxLength={8}
              onChange={(event) => setInviterLabel(event.target.value)}
              placeholder="例如：我、小林"
            />
          </label>

          <div className="share-poster-styles" role="group" aria-label="选择海报风格">
            {sharePosterStyles.map((style) => (
              <button
                type="button"
                key={style.id}
                className={styleId === style.id ? "is-active" : ""}
                aria-pressed={styleId === style.id}
                onClick={() => setStyleId(style.id)}
              >
                <img src={style.image} alt="" />
                <span>{style.name}</span>
              </button>
            ))}
          </div>

          {!cloudUser ? (
            <p className="share-poster-notice">先登录“我的报告”，才能把二维码绑定到你的奖励账户。当前可预览，但下载前需要登录。</p>
          ) : !inviteUrl ? (
          <p className="share-poster-notice">生成绑定二维码后，朋友通过二维码首次登录，你将获得 1 次问事机会。</p>
          ) : (
            <p className="share-poster-success">二维码已绑定 · 同一新用户只奖励一次 · 自己扫码无效</p>
          )}
          {status ? <p className="share-poster-status" role="status">{status}</p> : null}

          <div className="share-poster-actions">
            {!inviteUrl ? (
              <button className="primary-btn" type="button" disabled={!cloudUser} onClick={prepareRewardLink}>
                {cloudUser ? "绑定奖励二维码" : "登录后绑定"}
              </button>
            ) : (
              <button
                className="primary-btn"
                type="button"
                disabled={isRendering}
                onClick={() => downloadPoster(
                  canvasRef.current,
                  `有数-${sharePosterStyles.find((style) => style.id === styleId)?.name || "分享海报"}.png`,
                  { contentId: report?.id },
                )}
              >
                {isRendering ? "正在生成…" : "下载高清海报"}
              </button>
            )}
            <button className="text-btn" type="button" onClick={onClose}>稍后再说</button>
          </div>
        </div>
        <div className="share-poster-preview">
          <canvas ref={canvasRef} aria-label="个性化分享海报预览" />
        </div>
      </section>
    </div>
  );
}

function ReportFeedback({ t, report, onSave }) {
  const labels = t.reportFeedback;
  const [savedFeedback, setSavedFeedback] = useState(() => getStoredReportFeedback(report?.id));
  const [rating, setRating] = useState(savedFeedback?.rating || "");
  const [reasons, setReasons] = useState(savedFeedback?.reasons || []);
  const [comment, setComment] = useState(savedFeedback?.comment || "");
  const [isEditing, setIsEditing] = useState(!savedFeedback);
  const [isSaving, setIsSaving] = useState(false);
  const [status, setStatus] = useState("");

  useEffect(() => {
    const nextFeedback = getStoredReportFeedback(report?.id);
    setSavedFeedback(nextFeedback);
    setRating(nextFeedback?.rating || "");
    setReasons(nextFeedback?.reasons || []);
    setComment(nextFeedback?.comment || "");
    setIsEditing(!nextFeedback);
    setStatus("");
  }, [report?.id]);

  function selectRating(nextRating) {
    if (rating !== nextRating) {
      setReasons([]);
    }
    setRating(nextRating);
    setStatus("");
  }

  function toggleReason(reasonId) {
    setReasons((currentReasons) => currentReasons.includes(reasonId)
      ? currentReasons.filter((item) => item !== reasonId)
      : [...currentReasons, reasonId]);
  }

  async function submitFeedback(event) {
    event.preventDefault();
    if (!rating || isSaving) {
      return;
    }

    setIsSaving(true);
    setStatus("");
    try {
      const result = await onSave(report, { rating, reasons, comment });
      setSavedFeedback(result.feedback);
      setIsEditing(false);
      setStatus(
        result.cloudStatus === "synced"
          ? labels.synced
          : result.cloudStatus === "fallback"
          ? labels.syncFallback
          : labels.localSaved,
      );
    } catch {
      setStatus(labels.error);
    } finally {
      setIsSaving(false);
    }
  }

  const selectedReasonLabels = savedFeedback?.reasons
    ?.map((reasonId) => Object.values(labels.reasons).flat().find(([id]) => id === reasonId)?.[1])
    .filter(Boolean) || [];

  return (
    <section className="report-feedback" aria-labelledby="report-feedback-title">
      <header>
        <h2 id="report-feedback-title">{labels.title}</h2>
        <p>{labels.text}</p>
      </header>

      {savedFeedback && !isEditing ? (
        <div className="report-feedback-saved">
          <div>
            <span>{labels.savedLabel}</span>
            <strong>{savedFeedback.rating === "helpful" ? labels.helpful : labels.unhelpful}</strong>
            {selectedReasonLabels.length ? <p>{selectedReasonLabels.join(" · ")}</p> : null}
          </div>
          <button type="button" onClick={() => setIsEditing(true)}>{labels.edit}</button>
        </div>
      ) : (
        <form onSubmit={submitFeedback}>
          <fieldset className="report-feedback-rating">
            <legend>{labels.title}</legend>
            <button
              type="button"
              aria-label={labels.helpful}
              aria-pressed={rating === "helpful"}
              onClick={() => selectRating("helpful")}
            >
              <span className="report-feedback-choice-mark" aria-hidden="true">✓</span>
              <span className="report-feedback-choice-copy">
                <strong>{labels.helpful}</strong>
                <small>{labels.helpfulNote}</small>
              </span>
            </button>
            <button
              type="button"
              aria-label={labels.unhelpful}
              aria-pressed={rating === "unhelpful"}
              onClick={() => selectRating("unhelpful")}
            >
              <span className="report-feedback-choice-mark" aria-hidden="true">—</span>
              <span className="report-feedback-choice-copy">
                <strong>{labels.unhelpful}</strong>
                <small>{labels.unhelpfulNote}</small>
              </span>
            </button>
          </fieldset>

          {rating ? (
            <div className="report-feedback-details">
              <fieldset className="report-feedback-reasons">
                <legend>{rating === "helpful" ? labels.helpfulPrompt : labels.unhelpfulPrompt}</legend>
                <div>
                  {labels.reasons[rating].map(([reasonId, reasonLabel]) => (
                    <button
                      type="button"
                      key={reasonId}
                      aria-pressed={reasons.includes(reasonId)}
                      onClick={() => toggleReason(reasonId)}
                    >
                      {reasonLabel}
                    </button>
                  ))}
                </div>
              </fieldset>

              <div className="report-feedback-comment">
                <label htmlFor="report-feedback-comment">{labels.commentLabel}</label>
                <textarea
                  id="report-feedback-comment"
                  value={comment}
                  maxLength={300}
                  onChange={(event) => setComment(event.target.value)}
                  placeholder={labels.commentPlaceholder}
                />
                <small>{comment.length}/300</small>
              </div>

              <div className="report-feedback-action-row">
                <p className="report-feedback-privacy">{labels.privacy}</p>
                <button className="report-feedback-submit" type="submit" disabled={isSaving}>
                  {isSaving ? labels.saving : labels.submit}
                </button>
              </div>
            </div>
          ) : null}
        </form>
      )}
      {status ? <p className="report-feedback-status" role="status">{status}</p> : null}
    </section>
  );
}

function ReportPage({
  t,
  report,
  onBackHome,
  onUnlock,
  cloudUser,
  inviteUrl,
  onRequestInvite,
  onSaveFeedback,
}) {
  const [showSharePoster, setShowSharePoster] = useState(false);
  const reportType = getReportTypeLabel(report, t);
  const generatedAt = formatReportDateTime(report?.createdAt, report?.language || "zh-CN");
  const birthInfo = formatBirthInfo(report);
  const isPreview = report?.access === "preview";

  return (
    <main className={`report-page report-detail-page ${report ? "" : "is-empty"}`} lang={report?.language || undefined}>
      <section className="report-hero" aria-label={t.reportPageRegion} role="region">
        <div className="report-hero-copy report-detail-intro">
          <p className="kicker">{t.reportPageKicker}</p>
          <h1>{report ? reportType : t.noReportTitle}</h1>
          <p>{report ? (isPreview ? t.previewPageText : t.reportPageText) : t.noReportText}</p>
          <div className="report-hero-actions">
            <button className="primary-btn" type="button" onClick={onBackHome}>
              {t.reportBackHome}
            </button>
            {report && !isPreview ? (
              <button className="secondary-btn" type="button" onClick={() => setShowSharePoster(true)}>
                生成分享海报
              </button>
            ) : null}
          </div>
        </div>
        {report ? (
          <article className={`generated-report report-page-card report-type-${report.type || "unknown"}`} aria-label={t.generatedTitle}>
            <header className="report-heading">
                <div className="report-heading-status">
                  <span>{isPreview ? t.previewReady : t.reportReady}</span>
                  <em>{getReportTypeEyebrow(report, t)}</em>
                </div>
                <p className="ai-content-label">{t.aiGeneratedLabel}</p>
                <div className="report-context-line">
                  {generatedAt ? <span>{t.reportGeneratedAt} {generatedAt}</span> : null}
                  {birthInfo ? <span>{t.reportBirthInfo} {birthInfo}</span> : null}
                  {report.type !== "question" && report.focus ? <span>{t.reportFocusInfo} {report.focus}</span> : null}
                </div>
                {report.question ? <p className="report-question"><span>{t.reportQuestionInfo}</span>{report.question}</p> : null}
                {report.paipan ? (
                  <p className="report-meta">
                    <strong>{t.reportPillars}</strong>
                    {report.paipan.pillars.year.value} · {report.paipan.pillars.month.value} · {report.paipan.pillars.day.value} · {report.paipan.pillars.hour.value}
                  </p>
                ) : null}
              </header>
              <ReportBody content={report.content} t={t} />
              {isPreview ? (
                <section className="report-unlock-card" aria-labelledby="report-unlock-title">
                  <div>
                    <p className="kicker">{t.previewReady}</p>
                    <h2 id="report-unlock-title">{t.previewUnlockTitle}</h2>
                    <p>{t.previewUnlockText}</p>
                  </div>
                  <button className="primary-btn" type="button" onClick={() => onUnlock?.(report)}>
                    {t.previewUnlockAction}
                  </button>
                </section>
              ) : null}
              <p className="report-footnote">{t.reportFootnote}</p>
              <p className="report-footnote">{t.footerDisclaimer}</p>
              {!isPreview ? <ReportFeedback t={t} report={report} onSave={onSaveFeedback} /> : null}
          </article>
        ) : null}
      </section>
      {showSharePoster ? (
        <SharePosterPanel
          report={report}
          cloudUser={cloudUser}
          inviteUrl={inviteUrl}
          onRequestInvite={onRequestInvite}
          onClose={() => setShowSharePoster(false)}
        />
      ) : null}
    </main>
  );
}

export default function App() {
  const supabaseClient = getSupabaseClient();
  const [language, setLanguage] = useState("zh-CN");
  const [focus, setFocus] = useState("career");
  const [birthDate, setBirthDate] = useState("");
  const [birthTime, setBirthTime] = useState("");
  const [gender, setGender] = useState("");
  const [birthPlace, setBirthPlace] = useState("");
  const [calendarType, setCalendarType] = useState("solar");
  const [isLeapMonth, setIsLeapMonth] = useState(false);
  const useTrueSolarTime = false;
  const birthLongitude = "";
  const ziHourConvention = "zi-chu";
  const [question, setQuestion] = useState("");
  const [entryMode, setEntryMode] = useState(getInitialEntryMode);
  const [entitlements, setEntitlements] = useState(getStoredEntitlements);
  const [reports, setReports] = useState(getStoredReports);
  const [report, setReport] = useState(getStoredReport);
  const [page, setPage] = useState(getCurrentPage);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStageIndex, setGenerationStageIndex] = useState(0);
  const [isGenerationReviewOpen, setIsGenerationReviewOpen] = useState(false);
  const [cloudUser, setCloudUser] = useState(null);
  const [authReady, setAuthReady] = useState(!supabaseClient);
  const [authMethod, setAuthMethod] = useState("phone");
  const [authPhone, setAuthPhone] = useState("");
  const [authPhoneCode, setAuthPhoneCode] = useState("");
  const [phoneOtpSent, setPhoneOtpSent] = useState(false);
  const [authEmail, setAuthEmail] = useState("");
  const [authStatus, setAuthStatus] = useState("");
  const [inviteUrl, setInviteUrl] = useState("");
  const [pendingGeneration, setPendingGeneration] = useState(() => (
    typeof window === "undefined" ? null : loadPendingGeneration(window.localStorage)
  ));
  const [readingDraft, setReadingDraft] = useState(() => (
    typeof window === "undefined" ? null : loadReadingDraft(window.localStorage)
  ));
  const [isRecoveringGeneration, setIsRecoveringGeneration] = useState(false);
  const [generationRecoveryStatus, setGenerationRecoveryStatus] = useState("");
  const t = copy[language];
  const activeEntry = t.entryModes[entryMode];
  const testUnlockEnabled = isTestUnlockMode();
  const directTestAccessEnabled = isDirectTestAccessMode();
  const activeAccess = directTestAccessEnabled
    ? { unlocked: true, source: "test", remaining: null }
    : getModeAccess(entitlements, entryMode);
  const featuredProduct = t.products[2];
  const purchaseOptions = t.products;
  const cloudEnabled = Boolean(supabaseClient);
  const reportIdFromUrl = typeof window === "undefined" ? "" : new URLSearchParams(window.location.search).get("id");
  const displayedReport = reportIdFromUrl
    ? reports.find((savedReport) => savedReport.id === reportIdFromUrl) || null
    : report;
  const generationReviewRef = useRef(null);
  const generationStageRef = useRef(null);
  const reviewBirthDate = formatGenerationReviewDate(birthDate, language);
  const reviewCalendar = [
    calendarType === "lunar" ? t.lunarCalendar : t.solarCalendar,
    calendarType === "lunar" && isLeapMonth ? t.leapMonth : "",
  ].filter(Boolean).join(" · ");

  useEffect(() => {
    function handlePopState() {
      setPage(getCurrentPage());
    }

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  useEffect(() => {
    document.documentElement.lang = language === "en" ? "en" : language;
  }, [language]);

  useEffect(() => {
    setIsGenerationReviewOpen(false);
  }, [
    birthDate,
    birthLongitude,
    birthPlace,
    birthTime,
    calendarType,
    entryMode,
    focus,
    gender,
    isLeapMonth,
    language,
    question,
    useTrueSolarTime,
    ziHourConvention,
  ]);

  useEffect(() => {
    if (isGenerationReviewOpen) {
      generationReviewRef.current?.focus({ preventScroll: true });
    }
  }, [isGenerationReviewOpen]);

  useEffect(() => {
    if (!isGenerating) {
      setGenerationStageIndex(0);
      return undefined;
    }

    const revealFrame = window.requestAnimationFrame(() => {
      generationStageRef.current?.scrollIntoView?.({ block: "center", behavior: "auto" });
    });
    const structureTimer = window.setTimeout(() => setGenerationStageIndex(1), 4500);
    const guidanceTimer = window.setTimeout(() => setGenerationStageIndex(2), 14000);
    return () => {
      window.cancelAnimationFrame(revealFrame);
      window.clearTimeout(structureTimer);
      window.clearTimeout(guidanceTimer);
    };
  }, [isGenerating]);

  useEffect(() => {
    if (!supabaseClient) {
      return undefined;
    }

    let mounted = true;

    async function loadUserAndReports() {
      try {
        const { data } = await supabaseClient.auth.getSession();
        const nextUser = data?.session?.user || null;
        if (!mounted) {
          return;
        }
        setCloudUser(nextUser);
        if (nextUser) {
          await refreshCloudData(nextUser);
        }
      } finally {
        if (mounted) {
          setAuthReady(true);
        }
      }
    }

    const subscription = supabaseClient.auth.onAuthStateChange((_event, session) => {
      const nextUser = session?.user || null;
      setCloudUser(nextUser);
      setAuthReady(true);
      if (nextUser) {
        refreshCloudData(nextUser);
      }
    });

    loadUserAndReports();

    return () => {
      mounted = false;
      subscription?.data?.subscription?.unsubscribe?.();
    };
  }, [supabaseClient]);

  useEffect(() => {
    if (page !== "checkout" || !authReady || cloudUser) {
      return;
    }
    const productKey = new URLSearchParams(window.location.search).get("product");
    const nextProduct = entryModeIds.includes(productKey) ? productKey : "annual";
    navigate(`/reports?next=checkout&product=${nextProduct}`);
  }, [authReady, cloudUser, page]);

  useEffect(() => {
    const payload = readingDraft?.payload;
    if (!payload) {
      return;
    }
    setEntryMode(entryModeIds.includes(payload.type) ? payload.type : "bazi");
    setLanguage(payload.language || "zh-CN");
    setBirthDate(payload.birthDate || "");
    setBirthTime(payload.birthTime || "");
    setGender(payload.gender || "");
    setBirthPlace(payload.birthPlace || "");
    setCalendarType(payload.calendarType || "solar");
    setIsLeapMonth(Boolean(payload.isLeapMonth));
    setQuestion(payload.question || "");
  }, []);

  useEffect(() => {
    if (!cloudUser || page !== "reports") {
      return;
    }
    const search = new URLSearchParams(window.location.search);
    const productKey = search.get("product");
    if (search.get("next") === "checkout" && entryModeIds.includes(productKey)) {
      navigate(`/checkout?product=${productKey}`);
      return;
    }
    const orderNo = search.get("orderNo");
    if (search.get("next") === "payment-result" && orderNo) {
      navigate(`/payment/result?out_trade_no=${encodeURIComponent(orderNo)}`);
    }
  }, [cloudUser, page]);

  useEffect(() => {
    const codeFromUrl = new URLSearchParams(window.location.search).get("ref");
    if (codeFromUrl) {
      window.localStorage.setItem(pendingReferralStorageKey, codeFromUrl);
    }
  }, []);

  useEffect(() => {
    if (!supabaseClient || !cloudUser) {
      return;
    }

    const pendingCode = window.localStorage.getItem(pendingReferralStorageKey);
    if (!pendingCode) {
      return;
    }

    let active = true;
    supabaseClient.auth.getSession().then(async ({ data }) => {
      const accessToken = data?.session?.access_token;
      if (!accessToken) {
        return;
      }
      const response = await fetch("/api/referrals/claim", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ code: pendingCode }),
      });
      const result = await response.json();
      if (!active) {
        return;
      }
      if (response.ok) {
        window.localStorage.removeItem(pendingReferralStorageKey);
        if (result.status === "rewarded") {
          setAuthStatus("邀请已确认，分享者已获得 1 次问事机会。");
        }
      }
    }).catch(() => {
      // Keep the code so the claim can retry after the next authenticated visit.
    });

    return () => {
      active = false;
    };
  }, [cloudUser, supabaseClient]);

  function mergeReports(primaryReports, fallbackReports) {
    const seen = new Set();
    return [...primaryReports, ...fallbackReports].filter((item) => {
      if (!item?.id || seen.has(item.id)) {
        return false;
      }
      seen.add(item.id);
      return true;
    });
  }

  async function refreshCloudData(user = cloudUser) {
    if (!supabaseClient || !user) {
      return;
    }

    try {
      const [cloudReports, cloudEntitlements] = await Promise.all([
        loadCloudReports(supabaseClient, user),
        loadCloudEntitlements(supabaseClient, user),
      ]);
      setReports((currentReports) => mergeReports(cloudReports, currentReports));
      setEntitlements(cloudEntitlements);
      saveStoredEntitlements(cloudEntitlements);
    } catch {
      setAuthStatus(t.authError);
    }
  }

  async function signInWithGoogle() {
    if (!supabaseClient) {
      setAuthStatus(t.authUnavailable);
      return;
    }

    const { error } = await supabaseClient.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: directTestAccessEnabled ? `${window.location.origin}/?test=1` : window.location.origin,
      },
    });
    setAuthStatus(error ? t.authError : "");
  }

  async function sendMagicLink() {
    if (!supabaseClient || !authEmail.trim()) {
      setAuthStatus(t.authError);
      return;
    }

    const { error } = await supabaseClient.auth.signInWithOtp({
      email: authEmail.trim(),
      options: {
        emailRedirectTo: directTestAccessEnabled ? `${window.location.origin}/?test=1` : window.location.origin,
      },
    });
    setAuthStatus(error ? t.authError : t.authCheckEmail);
  }

  async function verifyEmailCode(code) {
    if (!supabaseClient || !authEmail.trim() || !/^\d{6}$/.test(String(code || ""))) {
      setAuthStatus(t.authError);
      return;
    }
    const { error } = await supabaseClient.auth.verifyOtp({
      email: authEmail.trim(),
      token: String(code),
      type: "email",
    });
    setAuthStatus(error ? t.authError : "");
  }

  async function sendPhoneCode() {
    const phone = normalizeChinaPhone(authPhone);
    if (!supabaseClient) {
      setAuthStatus(t.authUnavailable);
      return;
    }
    if (!phone) {
      setAuthStatus(t.authPhoneInvalid);
      return;
    }

    const { error } = await supabaseClient.auth.signInWithOtp({ phone });
    if (error) {
      setAuthStatus(t.authPhoneError);
      return;
    }
    setPhoneOtpSent(true);
    setAuthStatus(t.authCodeSent);
  }

  async function verifyPhoneCode() {
    const phone = normalizeChinaPhone(authPhone);
    const token = authPhoneCode.replace(/\D/g, "");
    if (!supabaseClient) {
      setAuthStatus(t.authUnavailable);
      return;
    }
    if (!phone) {
      setAuthStatus(t.authPhoneInvalid);
      return;
    }
    if (!/^\d{6}$/.test(token)) {
      setAuthStatus(t.authCodeInvalid);
      return;
    }

    const { error } = await supabaseClient.auth.verifyOtp({
      phone,
      token,
      type: "sms",
    });
    setAuthStatus(error ? t.authError : "");
  }

  async function signOut() {
    if (!supabaseClient) {
      return;
    }

    await supabaseClient.auth.signOut();
    setCloudUser(null);
  }

  async function requestInviteLink() {
    if (!supabaseClient || !cloudUser) {
      throw new Error("请先登录“我的报告”。");
    }
    const { data } = await supabaseClient.auth.getSession();
    const accessToken = data?.session?.access_token;
    if (!accessToken) {
      throw new Error("登录状态已失效，请重新登录。");
    }
    const response = await fetch("/api/referrals/code", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    });
    const result = await response.json();
    if (!response.ok || !result.code) {
      throw new Error(result.error || "邀请二维码生成失败。");
    }
    const nextInviteUrl = buildReferralUrl(window.location.origin, result.code);
    setInviteUrl(nextInviteUrl);
    return nextInviteUrl;
  }

  async function saveFeedback(reportToRate, input) {
    const feedback = saveStoredReportFeedback(reportToRate, input);
    if (!supabaseClient || !cloudUser) {
      return { feedback, cloudStatus: "local" };
    }

    try {
      await saveCloudReportFeedback(supabaseClient, cloudUser, feedback);
      return { feedback, cloudStatus: "synced" };
    } catch {
      return { feedback, cloudStatus: "fallback" };
    }
  }

  function updateEntitlements(updater) {
    setEntitlements((currentEntitlements) => {
      const nextEntitlements = updater(currentEntitlements);
      saveStoredEntitlements(nextEntitlements);
      return nextEntitlements;
    });
  }

  function openTestEntitlement(productKey) {
    updateEntitlements((currentEntitlements) => grantProduct(currentEntitlements, productKey));
  }

  function consumeProductEntitlement(productKey) {
    updateEntitlements((currentEntitlements) => consumeEntitlement(currentEntitlements, productKey));
  }

  function forgetPendingGeneration() {
    clearPendingGeneration(window.localStorage);
    setPendingGeneration(null);
  }

  function rememberPendingGeneration(payload, requestId) {
    const pending = buildPendingGeneration(payload, requestId);
    savePendingGeneration(pending, window.localStorage);
    setPendingGeneration(pending);
    return pending;
  }

  function generationArchiveContext(payload) {
    return {
      birthDate: payload.birthDate,
      birthTime: payload.birthTime,
      birthPlace: payload.birthPlace,
      calendarType: payload.calendarType,
      isLeapMonth: payload.isLeapMonth,
      useTrueSolarTime: payload.useTrueSolarTime,
      birthLongitude: payload.birthLongitude,
      ziHourConvention: payload.ziHourConvention,
      focus: payload.focus,
      question: payload.question,
    };
  }

  function getCurrentGenerationPayload() {
    return {
      type: entryMode,
      language,
      birthDate,
      birthTime,
      gender,
      birthPlace,
      calendarType,
      isLeapMonth,
      useTrueSolarTime,
      birthLongitude: birthLongitude ? Number(birthLongitude) : undefined,
      ziHourConvention,
      ...(entryMode === "question"
        ? { question: question.trim() }
        : { focus: t.readings[focus].option }),
      coreProfile: getLatestCoreProfile(reports),
    };
  }

  function forgetReadingDraft() {
    clearReadingDraft(window.localStorage);
    setReadingDraft(null);
  }

  async function generatePreview() {
    const payload = getCurrentGenerationPayload();
    setIsGenerationReviewOpen(false);
    setIsGenerating(true);
    setReport(null);

    try {
      const response = await fetch("/api/generate/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await response.json();
      if (!response.ok || !json.content) {
        storeAndOpenReport({
          title: t.generationErrorTitle,
          content: friendlyApiError(json.error, t),
          language,
        }, { archive: false });
        return;
      }

      const draft = buildReadingDraft({
        payload,
        preview: {
          content: json.content,
          paipan: json.paipan,
          type: json.type || payload.type,
          language: payload.language,
        },
      });
      saveReadingDraft(draft, window.localStorage);
      setReadingDraft(draft);
      storeAndOpenReport({
        id: draft.id,
        access: "preview",
        title: t.generatedTitle,
        content: json.content,
        paipan: json.paipan,
        language: payload.language,
        type: json.type || payload.type,
        createdAt: draft.createdAt,
        ...generationArchiveContext(payload),
      }, { archive: false });
    } catch (error) {
      storeAndOpenReport({
        title: t.generationErrorTitle,
        content: friendlyApiError(error.message, t),
        language,
      }, { archive: false });
    } finally {
      setIsGenerating(false);
    }
  }

  function unlockPreview(previewReport) {
    const draft = readingDraft || loadReadingDraft(window.localStorage);
    const productKey = draft?.productKey || previewReport?.type || entryMode;
    if (!entryModeIds.includes(productKey)) {
      return;
    }
    setEntryMode(productKey);
    if (!cloudUser) {
      navigate(`/reports?next=checkout&product=${productKey}`);
      return;
    }
    navigate(`/checkout?product=${productKey}`);
  }

  async function continuePaidReading(productKey) {
    const draft = readingDraft || loadReadingDraft(window.localStorage);
    if (!draft?.payload || draft.productKey !== productKey) {
      if (entryModeIds.includes(productKey)) {
        setEntryMode(productKey);
      }
      return false;
    }
    setEntryMode(productKey);
    await generate(draft.payload, { ignoreClientAccess: true });
    return true;
  }

  function selectEntryMode(modeId) {
    setIsGenerationReviewOpen(false);
    setEntryMode(modeId);
    if (!directTestAccessEnabled) {
      return;
    }

    const nextUrl = new URL(window.location.href);
    nextUrl.searchParams.set("mode", modeId);
    window.history.replaceState({}, "", `${nextUrl.pathname}${nextUrl.search}${nextUrl.hash}`);
  }

  function startProductPreview(modeId) {
    selectEntryMode(modeId);
    window.history.pushState({}, "", "/#reading");
    setPage("home");
    if (!window.navigator.userAgent.includes("jsdom")) {
      window.requestAnimationFrame(() => {
        document.getElementById("reading")?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }
  }

  function navigate(path) {
    const nextUrl = new URL(path, window.location.origin);
    if (directTestAccessEnabled) {
      nextUrl.searchParams.set("test", "1");
      nextUrl.searchParams.set("mode", entryMode);
    }
    window.history.pushState({}, "", `${nextUrl.pathname}${nextUrl.search}${nextUrl.hash}`);
    setPage(getCurrentPage());
    if (!window.navigator.userAgent.includes("jsdom")) {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  function openSavedReport(savedReport) {
    setReport(savedReport);
    try {
      window.sessionStorage.setItem(reportStorageKey, JSON.stringify(savedReport));
    } catch {
      // Session storage is only a convenience for reloads.
    }
    navigate(`/report?id=${encodeURIComponent(savedReport.id)}`);
  }

  async function deleteSavedReport(savedReport) {
    const nextReports = reports.filter((item) => item.id !== savedReport?.id);
    setReports(nextReports);
    saveStoredReports(nextReports);

    if (report?.id === savedReport?.id) {
      setReport(null);
      try {
        window.sessionStorage.removeItem(reportStorageKey);
      } catch {
        // The local report list has still been updated.
      }
    }

    if (supabaseClient && cloudUser && savedReport?.id) {
      try {
        await deleteCloudReport(supabaseClient, cloudUser, savedReport.id);
      } catch {
        setAuthStatus(t.reportDeleteError);
      }
    }
  }

  function storeAndOpenReport(nextReport, { archive = true, context } = {}) {
    let reportToOpen = nextReport;

    if (archive) {
      reportToOpen = buildArchivedReport(nextReport, context || {
        birthDate,
        birthTime,
        birthPlace,
        calendarType,
        isLeapMonth,
        useTrueSolarTime,
        birthLongitude,
        ziHourConvention,
        ...(entryMode === "question"
          ? { question: question.trim() }
          : { focus: t.readings[focus].option }),
      });
      const nextReports = [reportToOpen, ...reports.filter((savedReport) => savedReport.id !== reportToOpen.id)].slice(0, maxStoredReports);
      setReports(nextReports);
      saveStoredReports(nextReports);
      if (supabaseClient && cloudUser) {
        saveCloudReport(supabaseClient, cloudUser, reportToOpen).catch(() => {
          setAuthStatus(t.authError);
        });
      }
    }

    setReport(reportToOpen);
    try {
      window.sessionStorage.setItem(reportStorageKey, JSON.stringify(reportToOpen));
    } catch {
      // Session storage is only a convenience for reloads.
    }
    navigate(archive ? `/report?id=${encodeURIComponent(reportToOpen.id)}` : "/report");
  }

  async function recoverGeneration() {
    if (!pendingGeneration || isRecoveringGeneration) {
      return;
    }

    setIsRecoveringGeneration(true);
    setGenerationRecoveryStatus("");
    try {
      const { data } = supabaseClient
        ? await supabaseClient.auth.getSession()
        : { data: { session: null } };
      const accessToken = data?.session?.access_token;
      if (!accessToken) {
        setGenerationRecoveryStatus(t.apiErrors.authRequired);
        return;
      }

      const response = await fetch(
        `/api/generate/status?requestId=${encodeURIComponent(pendingGeneration.requestId)}`,
        { headers: { Authorization: `Bearer ${accessToken}` } },
      );
      const result = await response.json();
      if (!response.ok) {
        setGenerationRecoveryStatus(friendlyApiError(result.error, t));
        return;
      }

      if (result.status === "completed" && result.response?.content) {
        const payload = pendingGeneration.payload;
        forgetPendingGeneration();
        storeAndOpenReport({
          title: t.generatedTitle,
          content: result.response.content,
          paipan: result.response.paipan,
          language: payload.language,
          type: result.response.type || payload.type,
        }, { context: generationArchiveContext(payload) });
        consumeProductEntitlement(result.response.type || payload.type);
        return;
      }

      if (result.status === "reserved") {
        setGenerationRecoveryStatus(t.generationRecovery.pending);
        return;
      }

      forgetPendingGeneration();
      setGenerationRecoveryStatus(
        result.status === "released"
          ? t.generationRecovery.released
          : t.generationRecovery.missing,
      );
      await refreshCloudData();
    } catch {
      setGenerationRecoveryStatus(t.generationRecovery.error);
    } finally {
      setIsRecoveringGeneration(false);
    }
  }

  async function generate(payloadOverride = null, { ignoreClientAccess = false } = {}) {
    if (pendingGeneration && !testUnlockEnabled) {
      setGenerationRecoveryStatus(t.generationRecovery.pending);
      return;
    }
    const payload = payloadOverride?.type ? payloadOverride : getCurrentGenerationPayload();
    const nextAccess = directTestAccessEnabled
      ? { unlocked: true, source: "test", remaining: null }
      : getModeAccess(entitlements, payload.type);
    if (!ignoreClientAccess && !nextAccess.unlocked) {
      return;
    }

    setIsGenerationReviewOpen(false);
    setIsGenerating(true);
    setReport(null);
    try {
      const { data: sessionData } = supabaseClient
        ? await supabaseClient.auth.getSession()
        : { data: { session: null } };
      const accessToken = sessionData?.session?.access_token || "";
      if (!testUnlockEnabled && !accessToken) {
        throw new Error("Authentication required");
      }
      const requestId = (
        typeof globalThis.crypto?.randomUUID === "function"
          ? globalThis.crypto.randomUUID()
          : `report_${Date.now()}_${Math.random().toString(36).slice(2)}`
      );
      if (!testUnlockEnabled) {
        rememberPendingGeneration(payload, requestId);
      }
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        },
        body: JSON.stringify({ requestId, ...payload }),
      });
      const json = await response.json();
      if (!response.ok) {
        if (!(response.status === 409 && /already being generated/i.test(String(json.error || "")))) {
          forgetPendingGeneration();
        }
        storeAndOpenReport({
          title: t.generationErrorTitle,
          content: friendlyApiError(json.error, t),
          language: payload.language,
        }, { archive: false });
        return;
      }
      forgetPendingGeneration();
      storeAndOpenReport({
        title: t.generatedTitle,
        content: json.content,
        paipan: json.paipan,
        language: payload.language,
        type: payload.type,
      }, { context: generationArchiveContext(payload) });
      if (readingDraft?.productKey === payload.type || loadReadingDraft(window.localStorage)?.productKey === payload.type) {
        forgetReadingDraft();
      }
      if (!directTestAccessEnabled) {
        consumeProductEntitlement(payload.type);
      }
    } catch (error) {
      storeAndOpenReport({
        title: t.generationErrorTitle,
        content: friendlyApiError(error.message, t),
        language: payload.language,
      }, { archive: false });
    } finally {
      setIsGenerating(false);
    }
  }

  return (
    <>
      <header className="site-header">
        <a
          className={`brand${page === "home" ? "" : " brand-back"}`}
          href={page === "home" ? "#top" : "/"}
          aria-label={t.brandHome}
          onClick={(event) => {
            if (page === "home") {
              return;
            }
            event.preventDefault();
            navigate("/");
          }}
        >
          {page === "home" ? null : <span className="brand-back-icon" aria-hidden="true">←</span>}
          <span className="brand-mark">有</span>
          <span>
            <strong>有数</strong>
            <small>{t.brandSmall}</small>
          </span>
        </a>
        <nav aria-label={t.navLabel}>
          {t.nav.map((item, index) => (
            <a href={t.navHrefs[index]} key={item}>
              {item}
            </a>
          ))}
        </nav>
        <div className="header-actions">
          <label className="language-switch">
            <span>语言 / Language</span>
            <select value={language} onChange={(event) => setLanguage(event.target.value)}>
              {languageOptions.map((option) => (
                <option value={option.value} key={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
          <a
            className="account-link"
            href="/reports"
            onClick={(event) => {
              event.preventDefault();
              navigate("/reports");
            }}
          >
            {cloudUser ? t.account : t.login}
          </a>
        </div>
      </header>

      {page === "checkout" && (!authReady || !cloudUser) ? (
        <main className="checkout-page" lang={language}>
          <section className="checkout-shell checkout-auth-redirect" aria-live="polite">
            <div className="checkout-intro">
              <p className="kicker">{checkoutCopy[language]?.kicker || checkoutCopy["zh-CN"].kicker}</p>
              <h1>
                {language === "en"
                  ? "Sign in before payment"
                  : language === "zh-TW"
                    ? "付款前，先登入帳號"
                    : "付款前，先登录账号"}
              </h1>
              <p>
                {language === "en"
                  ? "Your order, entitlement, and report will stay attached to this account."
                  : language === "zh-TW"
                    ? "訂單、解鎖權益和報告都會綁定到這個帳號。"
                    : "订单、解锁权益和报告都会绑定到这个账号。"}
              </p>
            </div>
          </section>
        </main>
      ) : page === "checkout" ? (
        <CheckoutPage
          language={language}
          t={t}
          navigate={navigate}
          supabaseClient={supabaseClient}
          cloudUser={cloudUser}
        />
      ) : page === "paymentResult" ? (
        <PaymentResultPage
          language={language}
          t={t}
          navigate={navigate}
          supabaseClient={supabaseClient}
          cloudUser={cloudUser}
          onPaymentConfirmed={() => refreshCloudData()}
          onContinue={continuePaidReading}
        />
      ) : page === "report" ? (
        <ReportPage
          t={t}
          report={displayedReport}
          onBackHome={() => navigate("/")}
          onUnlock={unlockPreview}
          cloudUser={cloudUser}
          inviteUrl={inviteUrl}
          onRequestInvite={requestInviteLink}
          onSaveFeedback={saveFeedback}
        />
      ) : page === "reports" ? (
        <ReportsPage
          t={t}
          reports={reports}
          onOpenReport={openSavedReport}
          onDeleteReport={deleteSavedReport}
          onBackHome={() => navigate("/#reading")}
          cloudEnabled={cloudEnabled}
          cloudUser={cloudUser}
          authMethod={authMethod}
          authPhone={authPhone}
          authPhoneCode={authPhoneCode}
          phoneOtpSent={phoneOtpSent}
          authEmail={authEmail}
          authStatus={authStatus}
          onAuthMethodChange={(method) => {
            setAuthMethod(method);
            setAuthStatus("");
          }}
          onAuthPhoneChange={(value) => {
            setAuthPhone(value);
            setPhoneOtpSent(false);
            setAuthPhoneCode("");
            setAuthStatus("");
          }}
          onAuthPhoneCodeChange={setAuthPhoneCode}
          onSendPhoneCode={sendPhoneCode}
          onVerifyPhoneCode={verifyPhoneCode}
          onAuthEmailChange={setAuthEmail}
          onGoogleSignIn={signInWithGoogle}
          onMagicLink={sendMagicLink}
          onVerifyEmailCode={verifyEmailCode}
          onSignOut={signOut}
        />
      ) : legalPageIds.includes(page) ? (
        <LegalPage language={language} t={t} pageId={page} onBackHome={() => navigate("/")} />
      ) : (
      <main id="top" lang={language}>
        <section className="hero" aria-label={t.heroRegion} role="region">
          <div className="hero-copy">
            <h1>有数</h1>
            <p className="hero-subtitle">{t.heroSubtitle}</p>
            <p className="hero-lede">{t.heroLede}</p>
            <div className="hero-actions">
              <a className="primary-btn" href="#reading">{t.primaryCta}</a>
              <a className="text-btn" href="#products">{t.servicesCta}</a>
            </div>
          </div>
          <div className="hero-visual compact">
            <YinYangOrb label={t.orbLabel} />
          </div>
        </section>

        <section
          className={`reading${isGenerating ? " is-generating" : ""}`}
          id="reading"
          aria-label={t.readingRegion}
          role="region"
        >
          <div className="section-copy">
            <p className="kicker">{t.readingKicker}</p>
            <h2>{t.readingTitle}</h2>
            <p>{t.readingText}</p>
          </div>
          <div className="reading-panel">
            <div className="mode-switcher" aria-label={t.entryModeLabel}>
              {entryModeIds.map((modeId) => {
                const mode = t.entryModes[modeId];

                return (
                  <button
                    className="mode-option"
                    type="button"
                    aria-pressed={entryMode === modeId}
                    key={modeId}
                    onClick={() => selectEntryMode(modeId)}
                  >
                    <span>{mode.eyebrow}</span>
                    <strong>{mode.title}</strong>
                    <em>{mode.summary}</em>
                  </button>
                );
              })}
            </div>

            {pendingGeneration ? (
              <aside className="generation-recovery" aria-live="polite">
                <div>
                  <span>{t.generationRecovery.title}</span>
                  <p>{t.generationRecovery.text}</p>
                  <code>{t.generationRecovery.requestLabel}：{pendingGeneration.requestId}</code>
                  {generationRecoveryStatus ? <strong>{generationRecoveryStatus}</strong> : null}
                </div>
                <div className="generation-recovery-actions">
                  <button type="button" onClick={recoverGeneration} disabled={isRecoveringGeneration}>
                    {isRecoveringGeneration ? t.generationRecovery.checking : t.generationRecovery.action}
                  </button>
                </div>
              </aside>
            ) : generationRecoveryStatus ? (
              <p className="generation-recovery-result" role="status">{generationRecoveryStatus}</p>
            ) : null}

            <form
              className={`birth-form ${entryMode === "question" ? "with-question" : ""}`}
              onSubmit={(event) => {
                event.preventDefault();
                if (isGenerating || (pendingGeneration && !testUnlockEnabled)) {
                  return;
                }
                if (!activeAccess.unlocked) {
                  generatePreview();
                  return;
                }
                setIsGenerationReviewOpen(true);
              }}
            >
              <div className="calendar-toolbar">
                <fieldset className="calendar-switcher">
                  <legend>{t.calendarType}</legend>
                  <div>
                    <button
                      type="button"
                      aria-pressed={calendarType === "solar"}
                      onClick={() => {
                        setCalendarType("solar");
                        setIsLeapMonth(false);
                      }}
                    >
                      {t.solarCalendar}
                    </button>
                    <button
                      type="button"
                      aria-pressed={calendarType === "lunar"}
                      onClick={() => setCalendarType("lunar")}
                    >
                      {t.lunarCalendar}
                    </button>
                  </div>
                </fieldset>
                {calendarType === "lunar" ? (
                  <label className="inline-check">
                    <input
                      type="checkbox"
                      checked={isLeapMonth}
                      onChange={(event) => setIsLeapMonth(event.target.checked)}
                    />
                    <span>{t.leapMonth}</span>
                  </label>
                ) : null}
              </div>
              <label>
                {calendarType === "lunar" ? t.lunarBirthDate : t.birthDate}
                <input
                  type={calendarType === "lunar" ? "text" : "date"}
                  inputMode={calendarType === "lunar" ? "numeric" : undefined}
                  pattern={calendarType === "lunar" ? "\\d{4}-\\d{2}-\\d{2}" : undefined}
                  placeholder={calendarType === "lunar" ? t.lunarDatePlaceholder : undefined}
                  value={birthDate}
                  onChange={(event) => setBirthDate(event.target.value)}
                  required
                />
              </label>
              <label>
                {t.birthTime}
                <input
                  type="time"
                  value={birthTime}
                  onChange={(event) => setBirthTime(event.target.value)}
                  required
                />
              </label>
              <label>
                {t.birthPlace}
                <input
                  value={birthPlace}
                  onChange={(event) => setBirthPlace(event.target.value)}
                  placeholder={t.birthPlacePlaceholder}
                  maxLength={80}
                />
              </label>
              <label>
                {t.gender}
                <select value={gender} onChange={(event) => setGender(event.target.value)}>
                  <option value="" disabled>
                    {t.genderPlaceholder}
                  </option>
                  <option value="male">{t.male}</option>
                  <option value="female">{t.female}</option>
                </select>
              </label>
              {entryMode === "question" ? null : (
                <label className="focus-field">
                  {activeEntry.focusLabel}
                  <select value={focus} onChange={(event) => setFocus(event.target.value)}>
                    {focusIds.map((item) => (
                      <option value={item} key={item}>
                        {t.readings[item].option}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              {entryMode === "question" ? (
                <label className="question-field">
                  {t.questionLabel}
                  <textarea
                    value={question}
                    onChange={(event) => setQuestion(event.target.value)}
                    placeholder={t.questionPlaceholder}
                    maxLength={500}
                    required
                  />
                </label>
              ) : null}
              <aside className={`entitlement-state ${activeAccess.unlocked ? "is-open" : "is-locked"}`} aria-live="polite">
                <span>{t.entitlementStatusLabel}</span>
                <strong>{getAccessTitle(activeAccess, t)}</strong>
                <p>
                  {activeAccess.source === "test"
                    ? t.testAccessHint
                    : activeAccess.unlocked
                    ? fillTemplate(t.entitlementRemaining, { count: activeAccess.remaining })
                    : t.entitlementLockedText}
                </p>
              </aside>
              {testUnlockEnabled && !directTestAccessEnabled ? (
                <div className="test-unlock-panel">
                  <button type="button" onClick={() => openTestEntitlement(entryMode)}>
                    {t.testUnlockCurrent}
                  </button>
                  <span>{t.testUnlockHint}</span>
                </div>
              ) : null}
              {isGenerationReviewOpen ? (
                <section
                  className="generation-review"
                  ref={generationReviewRef}
                  tabIndex="-1"
                  aria-labelledby="generation-review-title"
                >
                  <header>
                    <h3 id="generation-review-title">{t.generationReviewTitle}</h3>
                    <p>{t.generationReviewText}</p>
                  </header>
                  <dl className="generation-review-details">
                    <div>
                      <dt>{t.generationReviewService}</dt>
                      <dd>{activeEntry.title}</dd>
                    </div>
                    <div>
                      <dt>{t.generationReviewBirth}</dt>
                      <dd>{`${reviewBirthDate} ${birthTime}`}</dd>
                    </div>
                    <div>
                      <dt>{t.generationReviewPlace}</dt>
                      <dd>{birthPlace.trim() || t.generationReviewMissing}</dd>
                    </div>
                    <div>
                      <dt>{t.generationReviewCalendar}</dt>
                      <dd>{reviewCalendar}</dd>
                    </div>
                    <div>
                      <dt>{t.generationReviewGender}</dt>
                      <dd>{gender === "male" ? t.male : gender === "female" ? t.female : t.generationReviewMissing}</dd>
                    </div>
                    {entryMode === "question" ? null : (
                      <div>
                        <dt>{t.generationReviewFocus}</dt>
                        <dd>{t.readings[focus].option}</dd>
                      </div>
                    )}
                    {entryMode === "question" ? (
                      <div className="generation-review-question">
                        <dt>{t.generationReviewQuestion}</dt>
                        <dd>{question.trim()}</dd>
                      </div>
                    ) : null}
                  </dl>
                  <p className="generation-review-entitlement" role="status">
                    {directTestAccessEnabled
                      ? t.generationReviewTestUse
                      : fillTemplate(t.generationReviewUse, { product: activeEntry.title })}
                  </p>
                  <div className="generation-review-actions">
                    <button
                      className="generation-review-back"
                      type="button"
                      onClick={() => setIsGenerationReviewOpen(false)}
                    >
                      {t.generationReviewBack}
                    </button>
                    <button
                      className="generation-review-confirm"
                      type="button"
                      onClick={() => generate()}
                      disabled={isGenerating || (pendingGeneration && !testUnlockEnabled)}
                    >
                      {t.generationReviewConfirm}
                    </button>
                  </div>
                </section>
              ) : (
                <div className="form-submit api-actions single-action" aria-live="polite">
                  <button
                    type="submit"
                    disabled={isGenerating || (pendingGeneration && !testUnlockEnabled)}
                  >
                    {activeEntry.action}
                  </button>
                </div>
              )}
            </form>

            {isGenerating ? (
              <div
                className="insight-stage"
                id="reading-result"
                ref={generationStageRef}
                aria-live="polite"
              >
                <article className="loading-report" aria-label={t.generating}>
                  <div className="loading-visual" aria-hidden="true">
                    <div className="loading-yinyang">
                      <YinYangOrb label="" />
                    </div>
                  </div>
                  <div className="loading-report-copy">
                    <p className="loading-report-kicker">{t.generatingKicker}</p>
                    <h3>{t.generating}</h3>
                    <p>{t.generatingText}</p>
                    <ol>
                      {t.generatingSteps.map((step, index) => (
                        <li
                          className={
                            index < generationStageIndex
                              ? "is-complete"
                              : index === generationStageIndex
                              ? "is-active"
                              : ""
                          }
                          aria-current={index === generationStageIndex ? "step" : undefined}
                          key={step}
                        >
                          <span className="loading-step-mark" aria-hidden="true">
                            {index < generationStageIndex ? "✓" : index + 1}
                          </span>
                          <span>
                            <strong>{step}</strong>
                            <small>{t.generatingStepDetails[index]}</small>
                          </span>
                        </li>
                      ))}
                    </ol>
                    <p className="loading-report-note">{t.generatingNote}</p>
                  </div>
                </article>
              </div>
            ) : null}
          </div>
        </section>

        <section className="product-section" id="products" aria-label={t.productsRegion} role="region">
          <div className="section-copy narrow product-intro">
            <p className="kicker">{t.productKicker}</p>
            <h2>{t.productTitle}</h2>
            <p>{t.productSubtitle}</p>
          </div>
          <div className="service-board">
            <div className="service-choices" aria-label={t.purchaseLabel}>
              {purchaseOptions.map((product) => {
                const price = t.prices[product.priceKey];
                const displayPrice = getDisplayPrice(price, language);
                const isFeatured = product.title === featuredProduct.title;
                const productStatus = getProductStatus(entitlements, product.key);

                return (
                  <article className={`service-choice ${isFeatured ? "featured" : ""}`} key={product.title}>
                    <span>{isFeatured ? t.badges.featured : t.badges.single}</span>
                    <strong className="dual-price single-price" aria-label={displayPrice}>
                      <span>{displayPrice}</span>
                    </strong>
                    <h3>{product.title}</h3>
                    <p>{product.question}</p>
                    <div className="product-card-meta">
                      <span>{t.productDelivery}</span>
                      <span>{t.productRefund}</span>
                    </div>
                    <div className="product-card-footer">
                      <em className="entitlement-pill">{getProductStatusLabel(productStatus, t)}</em>
                      <a
                        className="purchase-link"
                        href="#reading"
                        onClick={(event) => {
                          event.preventDefault();
                          startProductPreview(product.key);
                        }}
                      >
                        {language === "en" ? "Preview free" : language === "zh-TW" ? "免費試看" : "免费试看"}
                      </a>
                    </div>
                  </article>
                );
              })}
            </div>

            <div className="service-detail-grid compact-service-detail">
              <article className="service-feature annual-detail">
                <div className="service-feature-copy">
                  <span className="service-label">{t.annualLabel}</span>
                  <h3>{t.annualTitle}</h3>
                  <p>{t.annualText}</p>
                </div>
                <div className="timeline-preview" aria-label={t.timelineLabel}>
                  <div className="coverage-note">
                    <span>{t.coverageLabel}</span>
                    <strong>{t.coverageValue}</strong>
                  </div>
                  {t.annualTimeline.map(([season, text]) => (
                    <div className="timeline-row" key={season}>
                      <strong>{season}</strong>
                      <p>{text}</p>
                    </div>
                  ))}
                </div>
                <a
                  href="#reading"
                  onClick={(event) => {
                    event.preventDefault();
                    startProductPreview(featuredProduct.key);
                  }}
                >
                  {featuredProduct.action}
                </a>
              </article>

              <article className="service-feature purchase-flow-detail">
                <div className="service-feature-copy">
                  <span className="service-label">{t.purchaseFlowLabel}</span>
                  <h3>{t.purchaseFlowTitle}</h3>
                  <p>{t.purchaseFlowText}</p>
                </div>
                <ol className="purchase-steps">
                  {t.purchaseSteps.map(([number, title, text]) => (
                    <li key={number}>
                      <span>{number}</span>
                      <div>
                        <strong>{title}</strong>
                        <p>{text}</p>
                      </div>
                    </li>
                  ))}
                </ol>
                <div className="refund-promise">
                  <strong>{t.refundPromise}</strong>
                  <p>{t.refundPromiseText}</p>
                </div>
              </article>
            </div>
          </div>
        </section>

        <section className="method compact-method" id="method" aria-label={t.methodRegion} role="region">
          <div className="section-copy narrow">
            <p className="kicker">{t.methodKicker}</p>
            <h2>{t.methodTitle}</h2>
          </div>
          <div className="method-line">
            {t.proof.map(([title, text]) => (
              <article key={title}>
                <span>{title}</span>
                <p>{text}</p>
              </article>
            ))}
          </div>
        </section>
      </main>
      )}
      {page === "checkout" ? null : <SiteFooter t={t} navigate={navigate} />}
    </>
  );
}
