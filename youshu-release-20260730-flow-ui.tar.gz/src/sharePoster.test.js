import { describe, expect, it } from "vitest";
import { addPngTextChunk, buildReferralUrl, getPosterCopy, getPrivacySafePosterProfile } from "./sharePoster.js";

describe("sharePoster", () => {
  it("creates a stable profile without exposing raw private report fields", () => {
    const report = {
      id: "private-report-1",
      type: "question",
      birthDate: "1992-08-18",
      birthPlace: "北京市朝阳区",
      question: "我应该离开现在的公司吗？",
      focus: "事业机会",
      paipan: {
        pillars: {
          year: { value: "壬申" },
          month: { value: "戊申" },
          day: { value: "甲子" },
          hour: { value: "己巳" },
        },
      },
    };

    const first = getPrivacySafePosterProfile(report);
    const second = getPrivacySafePosterProfile(report);
    const rendered = JSON.stringify(first);

    expect(first).toEqual(second);
    expect(first.keywords).toHaveLength(3);
    expect(new Set(first.keywords).size).toBe(3);
    expect(rendered).not.toContain(report.birthDate);
    expect(rendered).not.toContain(report.birthPlace);
    expect(rendered).not.toContain(report.question);
    expect(rendered).not.toContain("壬申");
  });

  it("adds only the referral code to the public landing URL", () => {
    expect(buildReferralUrl("https://example.com/report?id=private", "ABCD1234")).toBe(
      "https://example.com/?ref=ABCD1234",
    );
  });

  it("uses distinct share-first copy without leaking report content", () => {
    const report = {
      type: "question",
      question: "这段关系还有必要继续吗？",
      birthPlace: "上海",
    };

    const directions = ["ink", "orbit", "gold", "moon"].map((styleId) => getPosterCopy(report, styleId));
    const headlines = directions.map(({ headline }) => headline);
    const rendered = JSON.stringify(directions);

    expect(new Set(headlines).size).toBe(4);
    expect(rendered).toContain("哪三个词");
    expect(rendered).toContain("只分享关键词");
    expect(rendered).not.toContain("问事机会");
    expect(rendered).not.toContain(report.question);
    expect(rendered).not.toContain(report.birthPlace);
  });

  it("adds an AIGC metadata chunk to exported PNG bytes", () => {
    const onePixelPng = Uint8Array.from(
      Buffer.from(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=",
        "base64",
      ),
    );
    const marked = addPngTextChunk(onePixelPng, "AIGC", '{"generated":true,"contentId":"report-1"}');
    const text = new TextDecoder().decode(marked);

    expect(marked.length).toBeGreaterThan(onePixelPng.length);
    expect(text).toContain("tEXtAIGC");
    expect(text).toContain('"generated":true');
    expect(text).toContain('"contentId":"report-1"');
  });
});
