export const sharePosterStyles = [
  {
    id: "ink",
    name: "山水留白",
    image: "/share-posters/ink-mountain.webp",
    dark: false,
    accent: "#7b5a23",
  },
  {
    id: "orbit",
    name: "星轨罗盘",
    image: "/share-posters/orbit-compass.webp",
    dark: true,
    accent: "#d4a84f",
  },
  {
    id: "gold",
    name: "金箔结构",
    image: "/share-posters/gold-structure.webp",
    dark: true,
    accent: "#e3bb68",
  },
  {
    id: "moon",
    name: "月门见山",
    image: "/share-posters/moon-gate.webp",
    dark: false,
    accent: "#8a6728",
  },
];

const keywordBanks = {
  bazi: [
    "稳中有进",
    "边界清晰",
    "慢热长线",
    "先定后动",
    "内稳外柔",
    "重诺守序",
    "看清再选",
    "留有余地",
  ],
  annual: [
    "先稳后起",
    "顺势换挡",
    "蓄力成势",
    "把握窗口",
    "松紧有度",
    "长期主义",
    "节奏优先",
    "稳步向前",
  ],
  question: [
    "先辨轻重",
    "减少内耗",
    "行动有序",
    "先看条件",
    "不急于答",
    "守住边界",
    "聚焦一步",
    "给事期限",
  ],
};

const posterCopyByStyle = {
  ink: {
    bazi: "比起成为别人期待的样子，\n我更想把自己的路走清楚。",
    annual: "不是每一步都要快，\n走在自己的节奏里就好。",
    question: "事情没有变，\n但我看清了下一步从哪里开始。",
  },
  orbit: {
    bazi: "看清自己的运行方式，\n比一直向外找答案更有用。",
    annual: "这一年不必硬闯，\n先找到属于自己的窗口。",
    question: "答案没有替我决定，\n只是把重要的变量一一照亮。",
  },
  gold: {
    bazi: "成年人的清醒，\n是知道什么值得长期用力。",
    annual: "把力气用在对的阶段，\n比一直用力更重要。",
    question: "真正的选择，\n是知道自己要守住什么。",
  },
  moon: {
    bazi: "理解自己以后，\n很多事就不必再勉强。",
    annual: "慢一点没关系，\n方向和节奏都在变清楚。",
    question: "有些答案不用马上得到，\n先走清楚眼前这一步。",
  },
};

function stableHash(value) {
  const text = String(value || "");
  let hash = 2166136261;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function reportSeed(report) {
  const pillars = report?.paipan?.pillars;
  return [
    report?.id,
    report?.type,
    report?.focus,
    pillars?.year?.value,
    pillars?.month?.value,
    pillars?.day?.value,
    pillars?.hour?.value,
  ].filter(Boolean).join("|");
}

export function getPrivacySafePosterProfile(report) {
  const type = keywordBanks[report?.type] ? report.type : "bazi";
  const seed = stableHash(reportSeed(report) || type);
  const bank = keywordBanks[type];
  const keywords = [];

  for (let offset = 0; keywords.length < 3 && offset < bank.length * 2; offset += 1) {
    const keyword = bank[(seed + offset * 3) % bank.length];
    if (!keywords.includes(keyword)) {
      keywords.push(keyword);
    }
  }

  return {
    keywords,
  };
}

export function getPosterCopy(report, styleId = "ink") {
  const type = keywordBanks[report?.type] ? report.type : "bazi";
  return {
    headline: posterCopyByStyle[styleId]?.[type] || posterCopyByStyle.ink[type],
    keywordIntro: "这是我最近留下的三个词",
    cta: "也来看看，你会留下哪三个词。",
    ctaDetail: "扫码生成 · 结果只在你自己的报告里可见",
    privacy: "只分享关键词，不分享生辰和问题",
    aiLabel: "AI生成内容 · 仅供参考",
  };
}

export function buildReferralUrl(origin, code) {
  const url = new URL("/", origin || "https://dongfangyoushu.com.cn");
  if (code) {
    url.searchParams.set("ref", code);
  }
  return url.toString();
}

function loadImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error(`Unable to load poster asset: ${source}`));
    image.src = source;
  });
}

function drawCover(context, image, width, height) {
  const scale = Math.max(width / image.naturalWidth, height / image.naturalHeight);
  const drawWidth = image.naturalWidth * scale;
  const drawHeight = image.naturalHeight * scale;
  context.drawImage(image, (width - drawWidth) / 2, (height - drawHeight) / 2, drawWidth, drawHeight);
}

function roundedRect(context, x, y, width, height, radius) {
  const safeRadius = Math.min(radius, width / 2, height / 2);
  context.beginPath();
  context.moveTo(x + safeRadius, y);
  context.arcTo(x + width, y, x + width, y + height, safeRadius);
  context.arcTo(x + width, y + height, x, y + height, safeRadius);
  context.arcTo(x, y + height, x, y, safeRadius);
  context.arcTo(x, y, x + width, y, safeRadius);
  context.closePath();
}

function drawWrappedText(context, text, x, y, maxWidth, lineHeight, maxLines = 3) {
  const characters = Array.from(text);
  let line = "";
  let lineIndex = 0;

  characters.forEach((character, index) => {
    if (lineIndex >= maxLines) {
      return;
    }
    const nextLine = `${line}${character}`;
    if (context.measureText(nextLine).width > maxWidth && line) {
      context.fillText(line, x, y + lineIndex * lineHeight);
      lineIndex += 1;
      line = character;
    } else {
      line = nextLine;
    }

    if (index === characters.length - 1 && lineIndex < maxLines) {
      context.fillText(line, x, y + lineIndex * lineHeight);
    }
  });
}

export async function renderSharePoster(canvas, {
  report,
  styleId = "ink",
  inviteUrl,
  inviterLabel = "我的",
} = {}) {
  if (!canvas) {
    return;
  }

  const width = 1080;
  const height = 1440;
  const context = canvas.getContext("2d");
  const style = sharePosterStyles.find((item) => item.id === styleId) || sharePosterStyles[0];
  const profile = getPrivacySafePosterProfile(report);
  const posterCopy = getPosterCopy(report, style.id);
  const qrImagePromise = import("qrcode")
    .then(({ default: QRCode }) => QRCode.toDataURL(inviteUrl || "https://dongfangyoushu.com.cn", {
      errorCorrectionLevel: "H",
      margin: 2,
      width: 256,
      color: {
        dark: "#111820",
        light: "#ffffff",
      },
    }))
    .then(loadImage);
  const [background, qrImage] = await Promise.all([
    loadImage(style.image),
    qrImagePromise,
  ]);

  canvas.width = width;
  canvas.height = height;
  context.clearRect(0, 0, width, height);
  drawCover(context, background, width, height);

  const ink = style.dark ? "#f7f3e8" : "#111820";
  const muted = style.dark ? "rgba(247,243,232,0.72)" : "rgba(17,24,32,0.68)";
  const panel = style.dark ? "rgba(8,10,13,0.76)" : "rgba(255,252,244,0.82)";
  const panelLine = style.dark ? "rgba(247,243,232,0.16)" : "rgba(17,24,32,0.12)";

  const wash = context.createLinearGradient(0, 0, 0, height);
  wash.addColorStop(0, style.dark ? "rgba(8,10,13,0.18)" : "rgba(255,252,244,0.10)");
  wash.addColorStop(0.58, style.dark ? "rgba(8,10,13,0.08)" : "rgba(255,252,244,0.04)");
  wash.addColorStop(1, style.dark ? "rgba(8,10,13,0.42)" : "rgba(255,252,244,0.20)");
  context.fillStyle = wash;
  context.fillRect(0, 0, width, height);

  context.fillStyle = style.accent;
  context.font = '700 28px "PingFang SC", "Microsoft YaHei", sans-serif';
  context.fillText("有数 · 东方文化人生参考", 72, 92);

  context.fillStyle = ink;
  context.font = '700 60px "Songti SC", "Noto Serif CJK SC", serif';
  posterCopy.headline.split("\n").forEach((line, index) => {
    context.fillText(line, 72, 200 + index * 82);
  });

  const cleanLabel = String(inviterLabel || "我").trim().replace(/的$/, "") || "我";
  context.fillStyle = muted;
  context.font = '600 27px "PingFang SC", "Microsoft YaHei", sans-serif';
  context.fillText(`${cleanLabel}最近留下的三个词`, 76, 378);

  const keywordPositions = [
    { x: 72, y: 430 },
    { x: 360, y: 566 },
    { x: 648, y: 702 },
  ];
  profile.keywords.forEach((keyword, index) => {
    const position = keywordPositions[index];
    roundedRect(context, position.x, position.y, 260, 84, 22);
    context.fillStyle = panel;
    context.fill();
    context.strokeStyle = panelLine;
    context.lineWidth = 2;
    context.stroke();

    context.fillStyle = style.accent;
    context.font = '700 19px "PingFang SC", "Microsoft YaHei", sans-serif';
    context.fillText(`0${index + 1}`, position.x + 22, position.y + 32);
    context.fillStyle = ink;
    context.font = '700 31px "PingFang SC", "Microsoft YaHei", sans-serif';
    context.fillText(keyword, position.x + 70, position.y + 53);
  });

  roundedRect(context, 62, 916, 956, 330, 30);
  context.fillStyle = panel;
  context.fill();
  context.strokeStyle = panelLine;
  context.lineWidth = 2;
  context.stroke();

  context.fillStyle = ink;
  context.font = '700 42px "Songti SC", "Noto Serif CJK SC", serif';
  context.fillText(posterCopy.cta, 106, 997);
  context.fillStyle = muted;
  context.font = '500 23px "PingFang SC", "Microsoft YaHei", sans-serif';
  context.fillText(posterCopy.ctaDetail, 106, 1054);
  context.fillStyle = style.accent;
  context.font = '700 22px "PingFang SC", "Microsoft YaHei", sans-serif';
  context.fillText(posterCopy.privacy, 106, 1124);

  roundedRect(context, 760, 955, 216, 216, 24);
  context.fillStyle = "#ffffff";
  context.fill();
  context.drawImage(qrImage, 774, 969, 188, 188);

  context.fillStyle = muted;
  context.font = '500 20px "PingFang SC", "Microsoft YaHei", sans-serif';
  context.textAlign = "center";
  context.fillText("长按识别二维码", 868, 1208);
  context.textAlign = "left";

  context.fillStyle = style.dark ? "rgba(247,243,232,0.64)" : "rgba(17,24,32,0.64)";
  context.font = '600 19px "PingFang SC", "Microsoft YaHei", sans-serif';
  context.fillText(posterCopy.aiLabel, 72, 1364);
}

function uint32Bytes(value) {
  return new Uint8Array([
    (value >>> 24) & 0xff,
    (value >>> 16) & 0xff,
    (value >>> 8) & 0xff,
    value & 0xff,
  ]);
}

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function concatBytes(...arrays) {
  const length = arrays.reduce((total, array) => total + array.length, 0);
  const output = new Uint8Array(length);
  let offset = 0;
  arrays.forEach((array) => {
    output.set(array, offset);
    offset += array.length;
  });
  return output;
}

export function addPngTextChunk(pngBytes, key, value) {
  const bytes = pngBytes instanceof Uint8Array ? pngBytes : new Uint8Array(pngBytes);
  const signature = [137, 80, 78, 71, 13, 10, 26, 10];
  if (bytes.length < 20 || signature.some((byte, index) => bytes[index] !== byte)) {
    throw new Error("A valid PNG file is required");
  }

  const encoder = new TextEncoder();
  const type = encoder.encode("tEXt");
  const data = concatBytes(encoder.encode(String(key || "AIGC")), new Uint8Array([0]), encoder.encode(String(value || "")));
  const chunk = concatBytes(uint32Bytes(data.length), type, data, uint32Bytes(crc32(concatBytes(type, data))));

  let offset = 8;
  while (offset + 12 <= bytes.length) {
    const view = new DataView(bytes.buffer, bytes.byteOffset + offset, 4);
    const length = view.getUint32(0);
    const chunkType = String.fromCharCode(...bytes.slice(offset + 4, offset + 8));
    if (chunkType === "IEND") {
      return concatBytes(bytes.slice(0, offset), chunk, bytes.slice(offset));
    }
    offset += 12 + length;
  }

  throw new Error("PNG IEND chunk is missing");
}

function canvasToBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) {
        resolve(blob);
      } else {
        reject(new Error("Unable to export poster"));
      }
    }, "image/png");
  });
}

export async function downloadPoster(canvas, filename = "有数-我的结构关键词.png", {
  contentId = "",
  serviceProvider = "北京一叶泛舟文化科技有限公司",
} = {}) {
  if (!canvas) {
    return;
  }

  const blob = await canvasToBlob(canvas);
  const markedBytes = addPngTextChunk(
    new Uint8Array(await blob.arrayBuffer()),
    "AIGC",
    JSON.stringify({
      generated: true,
      serviceProvider,
      contentId: String(contentId || ""),
    }),
  );
  const markedBlob = new Blob([markedBytes], { type: "image/png" });
  const objectUrl = URL.createObjectURL(markedBlob);
  const link = document.createElement("a");
  link.download = filename;
  link.href = objectUrl;
  link.click();
  setTimeout(() => URL.revokeObjectURL(objectUrl), 0);
}
