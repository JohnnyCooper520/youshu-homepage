import { act, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App.jsx";

beforeEach(() => {
  window.history.pushState({}, "", "/");
  window.sessionStorage.clear();
  window.localStorage.clear();
  delete window.__youshuSupabaseClient;
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

async function testUnlock(user, productName = "个人结构报告") {
  const readingRegion = screen.getByRole("region", { name: "结构校准" });
  const entryNames = {
    个人结构报告: /先知己.*个人结构报告/,
    一事分析: /看一事.*一事分析/,
    年度节奏报告: /看一年.*年度节奏/,
  };
  await user.click(within(readingRegion).getByRole("button", { name: entryNames[productName] }));
  await user.click(within(readingRegion).getByRole("button", { name: "测试开通当前服务" }));
}

async function fillBirthProfile(user) {
  fireEvent.change(screen.getByLabelText("出生日期"), { target: { value: "1988-01-14" } });
  fireEvent.change(screen.getByLabelText("出生时间"), { target: { value: "11:25" } });
  await user.type(screen.getByLabelText("出生地"), "长春");
  await user.selectOptions(screen.getByLabelText("性别"), "male");
}

function ensureRequiredBirthFields() {
  const form = document.querySelector(".birth-form");
  const dateInput = form?.querySelector('input[type="date"], input[inputmode="numeric"]');
  const timeInput = form?.querySelector('input[type="time"]');
  if (dateInput && !dateInput.value) {
    fireEvent.change(dateInput, { target: { value: "1988-01-14" } });
  }
  if (timeInput && !timeInput.value) {
    fireEvent.change(timeInput, { target: { value: "11:25" } });
  }
}

function mockSignedInArchiveClient() {
  window.__youshuSupabaseClient = {
    auth: {
      getSession: vi.fn(async () => ({
        data: {
          session: {
            access_token: "archive-access-token",
            user: { id: "archive-user", phone: "+8613812345678" },
          },
        },
        error: null,
      })),
      onAuthStateChange: vi.fn(() => ({ data: { subscription: { unsubscribe: vi.fn() } } })),
    },
    from: vi.fn(() => ({
      select: () => ({
        eq: () => ({
          order: async () => ({ data: [], error: null }),
        }),
      }),
      upsert: async () => ({ error: null }),
      delete: () => ({
        eq: () => ({
          eq: async () => ({ error: null }),
        }),
      }),
    })),
  };
}

async function confirmGeneration(user, actionName, confirmName = "确认并生成") {
  ensureRequiredBirthFields();
  await user.click(screen.getByRole("button", { name: actionName }));
  await user.click(await screen.findByRole("button", { name: confirmName }));
}

describe("Youshu homepage", () => {
  it("presents a three-product premium landing page with account access", () => {
    render(<App />);

    expect(screen.getByRole("heading", { name: "有数" })).toBeInTheDocument();
    expect(within(screen.getByRole("region", { name: "首页主视觉" })).getByText("心中有数，选择有光")).toBeInTheDocument();
    expect(within(screen.getByRole("region", { name: "首页主视觉" })).getByText("先看结构，再看选择。心里有数，路就不乱。")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "AI 模型与标识" })).toBeInTheDocument();
    expect(screen.getByLabelText("旋转阴阳动效")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "登录" })).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "我的报告" })).not.toBeInTheDocument();
    expect(screen.getByText("结构校准")).toBeInTheDocument();
    expect(within(screen.getByRole("region", { name: "结构校准" })).getByText("先把信息放准，再看当下方向。")).toBeInTheDocument();
    expect(within(screen.getByRole("region", { name: "结构校准" })).queryByRole("link", { name: "看结构关键词" })).not.toBeInTheDocument();
    expect(within(screen.getByRole("region", { name: "结构校准" })).queryByRole("link", { name: "看三项服务" })).not.toBeInTheDocument();
    expect(screen.queryByText("生成结构校准")).not.toBeInTheDocument();
    expect(screen.getAllByText("个人结构报告").length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText("一事分析").length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText("年度节奏报告").length).toBeGreaterThanOrEqual(1);
    expect(screen.queryByText("年度会员")).not.toBeInTheDocument();
    expect(screen.getAllByText("人民币 ¥29.9")).toHaveLength(2);
    expect(screen.getByText("人民币 ¥39.9")).toBeInTheDocument();
    expect(screen.queryByText("人民币 ¥299/年")).not.toBeInTheDocument();
    expect(screen.queryByText(/美元约/)).not.toBeInTheDocument();
    const purchaseRegion = screen.getByRole("region", { name: "购买选择" });
    expect(within(purchaseRegion).getByLabelText("购买项目")).toBeInTheDocument();
    expect(document.querySelectorAll(".service-choice")).toHaveLength(3);
    expect(within(purchaseRegion).getByText("三项单次服务，按需要选择。")).toBeInTheDocument();
    expect(within(purchaseRegion).getByText("先免费生成一段个性化试看；觉得有帮助，再登录并支付解锁全文。完整报告生成后会归入“我的报告”。")).toBeInTheDocument();
    expect(within(purchaseRegion).getByText("年度节奏 · 生成日起算")).toBeInTheDocument();
    expect(within(purchaseRegion).getByText("生成日起，向后看完整 12 个月。")).toBeInTheDocument();
    expect(within(purchaseRegion).getByText("生成日起 · 向后完整 12 个月")).toBeInTheDocument();
    expect(within(purchaseRegion).getByText("后续十二月")).toBeInTheDocument();
    expect(within(purchaseRegion).getByText("先看眼前，再看一年里的节奏。")).toBeInTheDocument();
    expect(within(purchaseRegion).getAllByRole("link", { name: "看年度节奏" })).toHaveLength(1);
    expect(within(purchaseRegion).queryByRole("link", { name: "生成个人结构报告" })).not.toBeInTheDocument();
    expect(within(purchaseRegion).queryByRole("link", { name: "生成一事分析" })).not.toBeInTheDocument();
    expect(within(purchaseRegion).getAllByRole("link", { name: "免费试看" })).toHaveLength(3);
    expect(within(purchaseRegion).queryByRole("button")).not.toBeInTheDocument();
    expect(within(purchaseRegion).queryByText("春季蓄势")).not.toBeInTheDocument();
    expect(within(purchaseRegion).getByText("报告区间")).toBeInTheDocument();
    expect(within(purchaseRegion).getAllByText("先免费试看，支付后解锁完整报告")).toHaveLength(3);
    expect(within(purchaseRegion).getAllByText("报告生成后 7 天内不满意可申请退款")).toHaveLength(3);
    expect(within(purchaseRegion).getByText("先看是否有帮助，再决定要不要解锁。")).toBeInTheDocument();
    expect(within(purchaseRegion).getByText("七日安心退款")).toBeInTheDocument();
    expect(screen.queryByText("流年十二月解读")).not.toBeInTheDocument();
    expect(screen.queryByText("上半年蓄势，下半年换挡")).not.toBeInTheDocument();
    expect(screen.getByText("为什么值得信任")).toBeInTheDocument();
    expect(screen.queryByText("用一段结构校准校准个人结构倾向；若它贴近你的处境，再进入完整个人结构、一事分析或年度路径。")).not.toBeInTheDocument();
    expect(screen.getByText("报告由结构化规则与人工智能生成，仅供自我认知与选择参考，不替代医疗、法律、投资或心理等专业意见。")).toBeInTheDocument();
    expect(screen.getAllByText(/北京一叶泛舟文化科技有限公司/)).toHaveLength(1);
    const footer = document.querySelector(".site-footer");
    expect(within(footer).getByRole("link", { name: /经营主体与营业执照/ })).toHaveAttribute("href", "/license");
    expect(within(screen.getByRole("region", { name: "首页主视觉" })).queryByText("经营主体与营业执照")).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "京ICP备2026045183号-1" })).toHaveAttribute(
      "href",
      "https://beian.miit.gov.cn/",
    );
    expect(screen.getByRole("link", { name: "服务条款" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "隐私政策" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "退款政策" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "联系我们" })).toBeInTheDocument();
    expect(screen.getAllByRole("region")).toHaveLength(4);
  });

  it("shows My reports in the header only after sign-in", async () => {
    window.__youshuSupabaseClient = {
      auth: {
        getSession: vi.fn(async () => ({
          data: { session: { user: { id: "user-1", email: "user@example.com" } } },
          error: null,
        })),
        onAuthStateChange: vi.fn(() => ({ data: { subscription: { unsubscribe: vi.fn() } } })),
      },
      from: vi.fn(() => ({
        select: () => ({
          eq: () => ({
            order: async () => ({ data: [], error: null }),
          }),
        }),
      })),
    };

    render(<App />);

    expect(await screen.findByRole("link", { name: "我的报告" })).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "登录" })).not.toBeInTheDocument();
  });

  it("opens legal pages with company, support, and refund rules", async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole("link", { name: "退款政策" }));

    expect(window.location.pathname).toBe("/refund");
    expect(screen.getByRole("heading", { name: "退款政策" })).toBeInTheDocument();
    expect(screen.getByText("每一份报告都享有七日安心退款。", { exact: false })).toBeInTheDocument();
    expect(screen.getByText("对报告内容不满意，也可以在期限内提出申请。", { exact: false })).toBeInTheDocument();

    await user.click(screen.getByRole("link", { name: "联系我们" }));

    expect(window.location.pathname).toBe("/contact");
    expect(screen.getByRole("heading", { name: "联系我们" })).toBeInTheDocument();
    expect(screen.queryByText(/P0 测试期/)).not.toBeInTheDocument();
    expect(screen.getByText("我们会核对相关记录并尽快回复。", { exact: false })).toBeInTheDocument();
    expect(screen.getAllByText("qinyuneo@gmail.com").length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText("北京一叶泛舟文化科技有限公司").length).toBeGreaterThanOrEqual(1);

    await user.click(screen.getByRole("link", { name: "营业执照" }));
    expect(screen.getByRole("heading", { name: "营业执照信息公示" })).toBeInTheDocument();
    expect(screen.getByText("91110114MACEGQFU0Q")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /国家企业信用信息公示系统/ })).toHaveAttribute(
      "href",
      "https://www.gsxt.gov.cn/",
    );

    await user.click(screen.getByRole("link", { name: "AI 模型与标识" }));
    expect(screen.getByRole("heading", { name: "AI 模型与内容标识说明" })).toBeInTheDocument();
    expect(screen.getByText(/Beijing-DeepseekChat-202404280016/)).toBeInTheDocument();
  });

  it("starts the selected annual preview before any login or checkout", async () => {
    const user = userEvent.setup();
    render(<App />);

    const purchaseRegion = screen.getByRole("region", { name: "购买选择" });
    const annualHeading = within(purchaseRegion).getByRole("heading", { name: "年度节奏报告" });
    const annualCard = annualHeading.closest("article");

    await user.click(within(annualCard).getByRole("link", { name: "免费试看" }));

    expect(window.location.pathname).toBe("/");
    expect(window.location.hash).toBe("#reading");
    expect(screen.getByRole("button", { name: /看一年.*年度节奏/ })).toHaveAttribute("aria-pressed", "true");
    expect(screen.getByRole("button", { name: "生成年度节奏" })).toBeInTheDocument();
    expect(screen.queryByRole("region", { name: "确认订单" })).not.toBeInTheDocument();
  });

  it("creates an authenticated order and submits the signed fields to Alipay", async () => {
    const user = userEvent.setup();
    window.history.pushState({}, "", "/checkout?product=annual");
    const getSession = vi.fn(async () => ({
      data: {
        session: {
          access_token: "payment-access-token",
          user: { id: "user-1", email: "user@example.com" },
        },
      },
      error: null,
    }));
    window.__youshuSupabaseClient = {
      auth: {
        getSession,
        onAuthStateChange: vi.fn(() => ({ data: { subscription: { unsubscribe: vi.fn() } } })),
      },
      from: vi.fn((table) => ({
        select: () => ({
          eq: () => ({
            order: async () => ({ data: [], error: null }),
          }),
        }),
      })),
    };
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({
      ok: true,
      order: {
        orderNo: "YS20260728ABCDEF1234567890",
        productKey: "annual",
        amount: "39.90",
        status: "created",
      },
      checkout: {
        gatewayUrl: "https://openapi.alipay.com/gateway.do",
        formFields: {
          app_id: "2026000000000000",
          method: "alipay.trade.page.pay",
          sign: "signed-request",
        },
      },
    }), { status: 201, headers: { "Content-Type": "application/json" } }));
    vi.stubGlobal("fetch", fetchMock);
    let submittedForm = null;
    vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function submit() {
      submittedForm = {
        action: this.action,
        method: this.method,
        fields: Object.fromEntries(new FormData(this).entries()),
      };
    });

    render(<App />);
    await waitFor(() => expect(getSession).toHaveBeenCalled());
    await user.click(screen.getByRole("checkbox"));
    await user.click(screen.getByRole("button", { name: "支付宝支付" }));

    await waitFor(() => expect(submittedForm).not.toBeNull());
    expect(fetchMock).toHaveBeenCalledWith("/api/payments/alipay/orders", expect.objectContaining({
      method: "POST",
      headers: expect.objectContaining({ Authorization: "Bearer payment-access-token" }),
    }));
    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toMatchObject({
      productKey: "annual",
      clientRequestId: expect.any(String),
    });
    expect(submittedForm).toEqual({
      action: "https://openapi.alipay.com/gateway.do",
      method: "post",
      fields: {
        app_id: "2026000000000000",
        method: "alipay.trade.page.pay",
        sign: "signed-request",
      },
    });
  });

  it("checks the server-side order after returning from Alipay", async () => {
    window.history.pushState({}, "", "/payment/result?out_trade_no=YS20260728ABCDEF1234567890");
    window.__youshuSupabaseClient = {
      auth: {
        getSession: vi.fn(async () => ({
          data: {
            session: {
              access_token: "payment-access-token",
              user: { id: "user-1", email: "user@example.com" },
            },
          },
          error: null,
        })),
        onAuthStateChange: vi.fn(() => ({ data: { subscription: { unsubscribe: vi.fn() } } })),
      },
      from: vi.fn((table) => ({
        select: () => ({
          eq: () => ({
            order: async () => ({
              data: table === "reports"
                ? []
                : [{ product_key: "annual", status: "active", included_quantity: 1, used_quantity: 0 }],
              error: null,
            }),
          }),
        }),
      })),
    };
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({
      ok: true,
      order: {
        orderNo: "YS20260728ABCDEF1234567890",
        productKey: "annual",
        amount: "39.90",
        status: "paid",
      },
    }), { status: 200, headers: { "Content-Type": "application/json" } })));

    render(<App />);

    expect(await screen.findByText("正在读取你刚才提交的信息并生成完整报告，请不要重复付款。")).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "付款成功" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "你的报告正在生成" })).toBeInTheDocument();
    expect(screen.getByText("接下来不用再操作")).toBeInTheDocument();
    expect(screen.getAllByText("年度节奏报告")).toHaveLength(2);
    expect(screen.getAllByText("¥39.90")).toHaveLength(2);
    expect(screen.getByText("us***@example.com")).toBeInTheDocument();
    expect(screen.getByText("订单与报告已经绑定")).toBeInTheDocument();
    expect(screen.getByText("正在撰写并校验完整内容")).toBeInTheDocument();
    expect(await screen.findByRole("button", { name: "补充资料并生成" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "退款与售后" })).toBeInTheDocument();
  });

  it("does not show a report-generation timeline when the payment result has no order number", () => {
    window.history.pushState({}, "", "/payment/result");

    render(<App />);

    expect(screen.getByRole("heading", { name: "没有找到订单信息" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "订单状态" })).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "你的报告正在生成" })).not.toBeInTheDocument();
    expect(screen.queryByText("订单已绑定")).not.toBeInTheDocument();
    expect(screen.queryByText("已绑定当前账号")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "重新查询" })).not.toBeInTheDocument();
  });

  it("asks the user to sign in again without losing the returned Alipay order", async () => {
    const user = userEvent.setup();
    window.history.pushState({}, "", "/payment/result?out_trade_no=YS20260730SESSIONEXPIRED");
    window.__youshuSupabaseClient = {
      auth: {
        getSession: vi.fn(async () => ({ data: { session: null }, error: null })),
        onAuthStateChange: vi.fn(() => ({ data: { subscription: { unsubscribe: vi.fn() } } })),
      },
      from: vi.fn(() => ({
        select: () => ({
          eq: () => ({
            order: async () => ({ data: [], error: null }),
          }),
        }),
      })),
    };

    render(<App />);

    expect(await screen.findByRole("heading", { name: "登录后继续确认付款" })).toBeInTheDocument();
    expect(screen.getByText("付款记录已经绑定账号。重新登录后会继续查询，不需要再次付款。")).toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: "重新登录并继续" }));

    expect(window.location.pathname).toBe("/reports");
    expect(window.location.search).toBe(
      "?next=payment-result&orderNo=YS20260730SESSIONEXPIRED",
    );
    expect(screen.getByRole("heading", { name: "登录后查看你的报告" })).toBeInTheDocument();
  });

  it("returns to the homepage from the top-left brand on subpages", async () => {
    const user = userEvent.setup();
    window.history.pushState({}, "", "/reports");
    render(<App />);

    expect(screen.getByRole("heading", { name: "登录后查看你的报告" })).toBeInTheDocument();

    await user.click(screen.getByRole("link", { name: "有数首页" }));

    expect(window.location.pathname).toBe("/");
    expect(screen.getByRole("heading", { name: "有数" })).toBeInTheDocument();
  });

  it("keeps the idle reading entry focused on inputs instead of a demo result", async () => {
    const user = userEvent.setup();
    render(<App />);

    expect(screen.getByLabelText("出生日期")).toHaveValue("");
    expect(screen.getByLabelText("出生时间")).toHaveValue("");
    expect(screen.getByLabelText("出生地")).toHaveValue("");
    expect(screen.getByLabelText("性别")).toHaveValue("");
    expect(screen.getByPlaceholderText("请输入出生城市")).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "请选择性别" })).toBeDisabled();

    await user.selectOptions(screen.getByLabelText("想看的方向"), "感情关系");

    expect(screen.getByLabelText("想看的方向")).toHaveValue("relationship");
    expect(screen.queryByText("有数 · 结构关键词")).not.toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "慢热深情，先立边界" })).not.toBeInTheDocument();
    expect(screen.queryByText("后面的判断，留给深度报告慢慢展开")).not.toBeInTheDocument();
  });

  it("switches the entry form by product before generation", async () => {
    const user = userEvent.setup();
    const { container } = render(<App />);
    const readingRegion = screen.getByRole("region", { name: "结构校准" });
    const modeSwitcher = within(readingRegion).getByLabelText("选择服务");
    const birthForm = container.querySelector(".birth-form");

    expect(within(modeSwitcher).getByRole("button", { name: /个人结构报告/ })).toHaveAttribute("aria-pressed", "true");
    expect(within(readingRegion).queryByLabelText("想分析的事")).not.toBeInTheDocument();
    expect(within(readingRegion).getByRole("button", { name: "生成个人结构报告" })).toBeInTheDocument();
    expect(within(readingRegion).getByRole("button", { name: "生成个人结构报告" })).toBeEnabled();
    expect(within(readingRegion).getByText("可以先免费试看")).toBeInTheDocument();
    expect(within(birthForm).getByRole("button", { name: "生成个人结构报告" })).toBeInTheDocument();

    await user.click(within(modeSwitcher).getByRole("button", { name: /年度节奏/ }));

    expect(within(modeSwitcher).getByRole("button", { name: /年度节奏/ })).toHaveAttribute("aria-pressed", "true");
    expect(within(readingRegion).getByText("从生成日起，向后看完整 12 个月。")).toBeInTheDocument();
    expect(within(readingRegion).queryByLabelText("想分析的事")).not.toBeInTheDocument();
    expect(within(readingRegion).getByRole("button", { name: "生成年度节奏" })).toBeInTheDocument();
    expect(within(readingRegion).getByText("可以先免费试看")).toBeInTheDocument();

    await user.click(within(modeSwitcher).getByRole("button", { name: /一事分析/ }));

    expect(within(modeSwitcher).getByRole("button", { name: /一事分析/ })).toHaveAttribute("aria-pressed", "true");
    expect(within(readingRegion).getByText("把一件具体的事拆清趋势、风险和下一步。")).toBeInTheDocument();
    expect(within(readingRegion).queryByLabelText("分析方向")).not.toBeInTheDocument();
    expect(within(readingRegion).getByLabelText("想分析的事")).toBeInTheDocument();
    expect(within(readingRegion).getByPlaceholderText("例如：接下来半年适合换工作吗？")).toBeInTheDocument();
    expect(within(readingRegion).getByRole("button", { name: "生成一事分析" })).toBeInTheDocument();
    expect(within(readingRegion).getByText("可以先免费试看")).toBeInTheDocument();
  });

  it("generates a personalized preview before asking the user to sign in and pay", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({
      ok: true,
      type: "bazi",
      access: "preview",
      content: "# 先看见你的底色\n你习惯先判断一件事能不能长期站得住。",
      paipan: {
        pillars: {
          year: { value: "丁卯" },
          month: { value: "癸丑" },
          day: { value: "戊辰" },
          hour: { value: "戊午" },
        },
      },
    }), { status: 200, headers: { "Content-Type": "application/json" } }));
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    const readingRegion = screen.getByRole("region", { name: "结构校准" });
    const reportButton = within(readingRegion).getByRole("button", { name: "生成个人结构报告" });
    expect(reportButton).toBeEnabled();
    expect(within(readingRegion).getByText("可以先免费试看")).toBeInTheDocument();

    await fillBirthProfile(user);
    await user.click(reportButton);
    expect((await screen.findAllByText("试看已生成")).length).toBeGreaterThanOrEqual(1);
    expect(window.location.pathname).toBe("/report");
    expect(screen.getByText("解锁完整报告")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "登录并解锁全文" })).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledWith("/api/generate/preview", expect.objectContaining({ method: "POST" }));
    expect(window.localStorage.getItem("youshu:reading-draft")).toContain("\"productKey\":\"bazi\"");
  });

  it("does not carry a one-matter question into an annual preview", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({
      ok: true,
      type: "annual",
      access: "preview",
      content: "# 年度节奏\n先收拢重点，再逐步放大成果。",
      paipan: {
        pillars: {
          year: { value: "丁卯" },
          month: { value: "癸丑" },
          day: { value: "戊辰" },
          hour: { value: "戊午" },
        },
      },
    }), { status: 200, headers: { "Content-Type": "application/json" } }));
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await fillBirthProfile(user);
    const readingRegion = screen.getByRole("region", { name: "结构校准" });
    const modeSwitcher = within(readingRegion).getByLabelText("选择服务");
    await user.click(within(modeSwitcher).getByRole("button", { name: /一事分析/ }));
    await user.type(within(readingRegion).getByLabelText("想分析的事"), "未来半年是否适合调整事业方向？");
    await user.click(within(modeSwitcher).getByRole("button", { name: /年度节奏/ }));
    await user.click(within(readingRegion).getByRole("button", { name: "生成年度节奏" }));

    const requestBody = JSON.parse(fetchMock.mock.calls[0][1].body);
    expect(requestBody).toMatchObject({
      type: "annual",
      focus: "事业机会",
    });
    expect(requestBody).not.toHaveProperty("question");
    expect((await screen.findAllByText("试看已生成")).length).toBeGreaterThanOrEqual(1);
    expect(screen.queryByText("未来半年是否适合调整事业方向？")).not.toBeInTheDocument();
  });

  it("keeps the preview draft and sends a signed-out user to login before checkout", async () => {
    const user = userEvent.setup();
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({
      ok: true,
      type: "bazi",
      access: "preview",
      content: "# 先看见你的底色\n你习惯先判断一件事能不能长期站得住。",
      paipan: {
        pillars: {
          year: { value: "丁卯" },
          month: { value: "癸丑" },
          day: { value: "戊辰" },
          hour: { value: "戊午" },
        },
      },
    }), { status: 200, headers: { "Content-Type": "application/json" } })));
    render(<App />);

    await fillBirthProfile(user);
    await user.click(within(screen.getByRole("region", { name: "结构校准" }))
      .getByRole("button", { name: "生成个人结构报告" }));
    await user.click(await screen.findByRole("button", { name: "登录并解锁全文" }));

    expect(window.location.pathname).toBe("/reports");
    expect(window.location.search).toBe("?next=checkout&product=bazi");
    expect(screen.getByRole("heading", { name: "登录后查看你的报告" })).toBeInTheDocument();
    expect(window.localStorage.getItem("youshu:reading-draft")).toContain("\"productKey\":\"bazi\"");
  });

  it("continues to the same product checkout after login without losing the reading draft", async () => {
    let authListener = null;
    window.localStorage.setItem("youshu:reading-draft", JSON.stringify({
      id: "draft-login-resume",
      productKey: "bazi",
      payload: {
        type: "bazi",
        language: "zh-CN",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        gender: "male",
        birthPlace: "长春",
        calendarType: "solar",
        focus: "事业机会",
      },
      preview: {
        type: "bazi",
        language: "zh-CN",
        content: "# 免费试看\n先看见自己的底色。",
      },
      createdAt: new Date().toISOString(),
    }));
    window.history.pushState({}, "", "/reports?next=checkout&product=bazi");
    window.__youshuSupabaseClient = {
      auth: {
        getSession: vi.fn(async () => ({ data: { session: null }, error: null })),
        onAuthStateChange: vi.fn((listener) => {
          authListener = listener;
          return { data: { subscription: { unsubscribe: vi.fn() } } };
        }),
      },
      from: vi.fn(() => ({
        select: () => ({
          eq: () => ({
            order: async () => ({ data: [], error: null }),
          }),
        }),
      })),
    };
    render(<App />);

    expect(await screen.findByRole("heading", { name: "登录后查看你的报告" })).toBeInTheDocument();
    await act(async () => {
      authListener("SIGNED_IN", {
        access_token: "login-resume-token",
        user: { id: "user-resume", phone: "+8613812345678" },
      });
    });

    await waitFor(() => expect(window.location.pathname).toBe("/checkout"));
    expect(window.location.search).toBe("?product=bazi");
    expect(screen.getByRole("region", { name: "确认订单" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "个人结构报告" })).toBeInTheDocument();
    expect(window.localStorage.getItem("youshu:reading-draft")).toContain("draft-login-resume");
  });

  it("generates and archives the preserved full report after a paid order is confirmed", async () => {
    const draft = {
      id: "draft-paid-delivery",
      productKey: "annual",
      payload: {
        type: "annual",
        language: "zh-CN",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        gender: "male",
        birthPlace: "长春",
        calendarType: "solar",
        focus: "综合趋势",
      },
      preview: {
        type: "annual",
        language: "zh-CN",
        content: "# 年度试看\n先稳住眼前的节奏。",
      },
      createdAt: new Date().toISOString(),
    };
    window.localStorage.setItem("youshu:reading-draft", JSON.stringify(draft));
    window.history.pushState({}, "", "/payment/result?out_trade_no=YS20260730PAIDDELIVERY");
    window.__youshuSupabaseClient = {
      auth: {
        getSession: vi.fn(async () => ({
          data: {
            session: {
              access_token: "paid-delivery-token",
              user: { id: "paid-user", phone: "+8613812345678" },
            },
          },
          error: null,
        })),
        onAuthStateChange: vi.fn(() => ({ data: { subscription: { unsubscribe: vi.fn() } } })),
      },
      from: vi.fn((table) => ({
        select: () => ({
          eq: () => ({
            order: async () => ({
              data: table === "reports"
                ? []
                : [{ product_key: "annual", status: "active", included_quantity: 1, used_quantity: 0 }],
              error: null,
            }),
          }),
        }),
        upsert: async () => ({ error: null }),
      })),
    };
    vi.stubGlobal("fetch", vi.fn(async (url) => {
      if (String(url).startsWith("/api/payments/orders/")) {
        return new Response(JSON.stringify({
          ok: true,
          order: {
            orderNo: "YS20260730PAIDDELIVERY",
            productKey: "annual",
            amount: "39.90",
            status: "paid",
          },
        }), { status: 200, headers: { "Content-Type": "application/json" } });
      }
      if (url === "/api/generate") {
        return new Response(JSON.stringify({
          ok: true,
          type: "annual",
          content: "# 完整年度节奏\n这是付款后自动生成的完整报告。",
          paipan: {
            pillars: {
              year: { value: "丁卯" },
              month: { value: "癸丑" },
              day: { value: "戊辰" },
              hour: { value: "戊午" },
            },
          },
        }), { status: 200, headers: { "Content-Type": "application/json" } });
      }
      throw new Error(`Unexpected request: ${url}`);
    }));

    render(<App />);

    expect(await screen.findByText("这是付款后自动生成的完整报告。")).toBeInTheDocument();
    expect(window.location.pathname).toBe("/report");
    expect(screen.queryByText("解锁完整报告")).not.toBeInTheDocument();
    expect(window.localStorage.getItem("youshu:reading-draft")).toBeNull();
    expect(window.localStorage.getItem("youshu:reports")).toContain("这是付款后自动生成的完整报告");
  });

  it("keeps the explicit test link open after a reading has been used", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async () =>
      new Response(
        JSON.stringify({
          ok: true,
          type: "annual",
          content: "# 年度节奏报告\n先看眼前，再看一年里的转折。",
          paipan: {
            pillars: {
              year: { value: "丁卯" },
              month: { value: "癸丑" },
              day: { value: "戊辰" },
              hour: { value: "戊午" },
            },
          },
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      ),
    );
    vi.stubGlobal("fetch", fetchMock);
    window.localStorage.setItem(
      "youshu:entitlements",
      JSON.stringify({ purchases: { annual: true }, remaining: { annual: 0 }, updatedAt: "2026-07-18T00:00:00.000Z" }),
    );
    window.history.pushState({}, "", "/?test=1&mode=annual");
    render(<App />);

    const readingRegion = screen.getByRole("region", { name: "结构校准" });
    const modeSwitcher = within(readingRegion).getByLabelText("选择服务");

    expect(within(modeSwitcher).getByRole("button", { name: /年度节奏/ })).toHaveAttribute("aria-pressed", "true");
    expect(within(readingRegion).getByText("测试通道已开启")).toBeInTheDocument();
    expect(within(readingRegion).getByText("可直接生成真实报告，本次测试不消耗正式权益。")).toBeInTheDocument();
    expect(within(readingRegion).getByRole("button", { name: "生成年度节奏" })).toBeEnabled();
    expect(within(readingRegion).queryByRole("button", { name: "测试开通当前服务" })).not.toBeInTheDocument();
    expect(within(readingRegion).queryByText("已用完")).not.toBeInTheDocument();

    await confirmGeneration(user, "生成年度节奏");

    expect(await screen.findByText("报告已成")).toBeInTheDocument();
    expect(window.location.pathname).toBe("/report");
    expect(new URLSearchParams(window.location.search).get("test")).toBe("1");
    expect(JSON.parse(window.localStorage.getItem("youshu:entitlements")).remaining.annual).toBe(0);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("loads paid entitlements from Supabase after sign in", async () => {
    const user = { id: "user-1", email: "qinyuneo@gmail.com" };
    const reportsOrderMock = vi.fn(async () => ({ data: [], error: null }));
    const reportsEqMock = vi.fn(() => ({ order: reportsOrderMock }));
    const reportsSelectMock = vi.fn(() => ({ eq: reportsEqMock }));
    const entitlementsOrderMock = vi.fn(async () => ({
      data: [{ product_key: "bazi", included_quantity: 1, used_quantity: 0, status: "active", expires_at: null }],
      error: null,
    }));
    const entitlementsEqMock = vi.fn(() => ({ order: entitlementsOrderMock }));
    const entitlementsSelectMock = vi.fn(() => ({ eq: entitlementsEqMock }));

    window.__youshuSupabaseClient = {
      auth: {
        getSession: vi.fn(async () => ({ data: { session: { user } }, error: null })),
        onAuthStateChange: vi.fn(() => ({ data: { subscription: { unsubscribe: vi.fn() } } })),
      },
      from: vi.fn((table) => {
        if (table === "reports") {
          return { select: reportsSelectMock };
        }
        if (table === "user_entitlements") {
          return { select: entitlementsSelectMock };
        }
        throw new Error(`Unexpected table: ${table}`);
      }),
    };

    render(<App />);

    const readingRegion = screen.getByRole("region", { name: "结构校准" });
    expect(await within(readingRegion).findByText("已开通，可生成")).toBeInTheDocument();
    expect(within(readingRegion).getByText("剩余 1 次")).toBeInTheDocument();
    expect(within(readingRegion).getByRole("button", { name: "生成个人结构报告" })).toBeEnabled();
    expect(entitlementsSelectMock).toHaveBeenCalledWith("product_key,included_quantity,used_quantity,status,expires_at");
  });

  it("keeps each one-time product entitlement independent", async () => {
    const user = userEvent.setup();
    render(<App />);

    await testUnlock(user, "年度节奏报告");

    const readingRegion = screen.getByRole("region", { name: "结构校准" });
    const modeSwitcher = within(readingRegion).getByLabelText("选择服务");
    await user.click(within(modeSwitcher).getByRole("button", { name: /年度节奏/ }));

    expect(within(readingRegion).getByText("已开通，可生成")).toBeInTheDocument();
    expect(within(readingRegion).getByText("剩余 1 次")).toBeInTheDocument();
    expect(within(readingRegion).getByRole("button", { name: "生成年度节奏" })).toBeEnabled();

    await user.click(within(modeSwitcher).getByRole("button", { name: /一事分析/ }));

    expect(within(readingRegion).getByText("可以先免费试看")).toBeInTheDocument();
    expect(within(readingRegion).getByRole("button", { name: "生成一事分析" })).toBeEnabled();
  });

  it("switches the web page between simplified Chinese, traditional Chinese, and English", async () => {
    const user = userEvent.setup();
    render(<App />);

    const languageSelect = screen.getByLabelText("语言 / Language");
    expect(languageSelect).toHaveValue("zh-CN");
    expect(document.documentElement).toHaveAttribute("lang", "zh-CN");
    expect(screen.getByRole("option", { name: "简体中文" })).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "繁體中文" })).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "English" })).toBeInTheDocument();

    await user.selectOptions(languageSelect, "zh-TW");

    expect(document.documentElement).toHaveAttribute("lang", "zh-TW");
    expect(screen.getByRole("link", { name: "登入" })).toBeInTheDocument();
    expect(screen.getByText("心中有數，選擇有光")).toBeInTheDocument();
    expect(screen.getAllByText("個人結構報告").length).toBeGreaterThanOrEqual(1);
    expect(screen.getByText("人民幣 ¥39.9")).toBeInTheDocument();
    expect(screen.queryByText(/美元約/)).not.toBeInTheDocument();

    await user.selectOptions(languageSelect, "en");

    expect(document.documentElement).toHaveAttribute("lang", "en");
    expect(screen.getByRole("link", { name: "Sign in" })).toBeInTheDocument();
    expect(screen.getByText("A clear structure, a calmer choice.")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "AI model and labels" })).toBeInTheDocument();
    expect(screen.getAllByText("Personal Structure Report").length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText("Annual Rhythm Report").length).toBeGreaterThanOrEqual(1);
    expect(screen.getByText("USD $5.6")).toBeInTheDocument();
    expect(screen.queryByText(/RMB/)).not.toBeInTheDocument();
  });

  it("does not expose DeepSeek key controls on the customer page", () => {
    render(<App />);

    expect(screen.queryByLabelText("服务端 DeepSeek Key")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "保存到后端" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "检查后端状态" })).not.toBeInTheDocument();
  });

  it("generates a report through the API without sending any API key from the page", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async (url) => {
      if (url === "/api/generate") {
        return new Response(
          JSON.stringify({
            ok: true,
            type: "bazi",
            content: "# 个人结构报告\n先知己。",
            paipan: {
              pillars: {
                year: { value: "丁卯" },
                month: { value: "癸丑" },
                day: { value: "戊辰" },
                hour: { value: "戊午" },
              },
            },
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        );
      }
      throw new Error(`Unexpected request: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await fillBirthProfile(user);
    await testUnlock(user, "个人结构报告");
    await user.click(screen.getByRole("button", { name: "生成个人结构报告" }));

    const generationReview = screen.getByRole("region", { name: "生成前确认" });
    expect(within(generationReview).getByText("个人结构报告")).toBeInTheDocument();
    expect(within(generationReview).getByText("1988年1月14日 11:25")).toBeInTheDocument();
    expect(within(generationReview).getByText("长春")).toBeInTheDocument();
    expect(within(generationReview).getByText("公历（阳历）")).toBeInTheDocument();
    expect(within(generationReview).getByText("确认后将使用 1 次个人结构报告权益")).toBeInTheDocument();
    expect(fetchMock).not.toHaveBeenCalled();

    await user.click(within(generationReview).getByRole("button", { name: "返回修改" }));
    expect(screen.queryByRole("region", { name: "生成前确认" })).not.toBeInTheDocument();
    expect(fetchMock).not.toHaveBeenCalled();

    await user.click(screen.getByRole("button", { name: "生成个人结构报告" }));
    await user.click(screen.getByRole("button", { name: "确认并生成" }));

    expect(window.location.pathname).toBe("/report");
    expect(screen.getByRole("heading", { name: "个人结构报告", level: 1 })).toBeInTheDocument();
    expect(await screen.findByText("丁卯 · 癸丑 · 戊辰 · 戊午")).toBeInTheDocument();
    expect(screen.getByText("报告已成")).toBeInTheDocument();
    expect(within(screen.getByLabelText("生成结果")).getByText("先知己")).toBeInTheDocument();
    expect(screen.getByText("先知己。")).toBeInTheDocument();
    expect(screen.queryByText("后面的判断，留给深度报告慢慢展开")).not.toBeInTheDocument();
    expect(document.querySelector(".generated-report pre")).not.toBeInTheDocument();

    const feedbackRegion = screen.getByRole("region", { name: "这份报告，贴合你的感受吗？" });
    expect(within(feedbackRegion).queryByRole("button", { name: "提交反馈" })).not.toBeInTheDocument();
    expect(within(feedbackRegion).queryByText("只记录评价和你主动填写的内容，不提交出生信息、具体问题或报告正文。")).not.toBeInTheDocument();

    await user.click(within(feedbackRegion).getByRole("button", { name: "比较贴合" }));
    expect(within(feedbackRegion).getByRole("button", { name: "提交反馈" })).toBeEnabled();
    expect(within(feedbackRegion).getByText("只记录评价和你主动填写的内容，不提交出生信息、具体问题或报告正文。")).toBeInTheDocument();
    await user.click(within(feedbackRegion).getByRole("button", { name: "像我" }));
    await user.type(within(feedbackRegion).getByLabelText("想再补充一句吗？（选填）"), "建议很具体");
    await user.click(within(feedbackRegion).getByRole("button", { name: "提交反馈" }));

    expect(await within(feedbackRegion).findByText("谢谢，反馈已保存在此设备。")).toBeInTheDocument();
    expect(within(feedbackRegion).getByText("已记录")).toBeInTheDocument();
    expect(within(feedbackRegion).getByText("像我")).toBeInTheDocument();
    const storedFeedback = Object.values(JSON.parse(window.localStorage.getItem("youshu:report-feedback")))[0];
    expect(storedFeedback).toMatchObject({
      reportType: "bazi",
      promptVersion: "report-v3",
      rating: "helpful",
      reasons: ["resonates"],
      comment: "建议很具体",
    });
    expect(storedFeedback).not.toHaveProperty("birthDate");
    expect(storedFeedback).not.toHaveProperty("content");
    expect(storedFeedback).not.toHaveProperty("question");

    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toMatchObject({
      type: "bazi",
      language: "zh-CN",
      birthDate: "1988-01-14",
      birthTime: "11:25",
      birthPlace: "长春",
      calendarType: "solar",
      isLeapMonth: false,
      useTrueSolarTime: false,
      ziHourConvention: "zi-chu",
    });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(fetchMock.mock.calls[0][0]).toBe("/api/generate");
    expect(fetchMock.mock.calls[0][1].body).not.toContain("sk-");
  });

  it("sends a one-matter question directly without asking for or submitting a direction", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async () =>
      new Response(
        JSON.stringify({
          ok: true,
          type: "question",
          content: "# 一事分析\n先看这件事本身。",
          paipan: {
            pillars: {
              year: { value: "丁卯" },
              month: { value: "癸丑" },
              day: { value: "戊辰" },
              hour: { value: "戊午" },
            },
          },
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      ),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await fillBirthProfile(user);
    await testUnlock(user, "一事分析");

    const readingRegion = screen.getByRole("region", { name: "结构校准" });
    expect(within(readingRegion).queryByLabelText("分析方向")).not.toBeInTheDocument();
    await user.type(within(readingRegion).getByLabelText("想分析的事"), "接下来半年适合换工作吗？");
    await user.click(within(readingRegion).getByRole("button", { name: "生成一事分析" }));

    const generationReview = screen.getByRole("region", { name: "生成前确认" });
    expect(within(generationReview).queryByText("关注方向")).not.toBeInTheDocument();
    expect(within(generationReview).getByText("具体事项")).toBeInTheDocument();
    expect(within(generationReview).getByText("接下来半年适合换工作吗？")).toBeInTheDocument();

    await user.click(within(generationReview).getByRole("button", { name: "确认并生成" }));

    const requestBody = JSON.parse(fetchMock.mock.calls[0][1].body);
    expect(requestBody).toMatchObject({
      type: "question",
      question: "接下来半年适合换工作吗？",
    });
    expect(requestBody).not.toHaveProperty("focus");
    expect(await screen.findByText("报告已成")).toBeInTheDocument();
    expect(screen.queryByText(/关注方向.*事业机会/)).not.toBeInTheDocument();
  });

  it("passes lunar-calendar data with the internal default calculation rules", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async () =>
      new Response(
        JSON.stringify({
          ok: true,
          type: "bazi",
          content: "# 个人结构报告\n先把历法口径定准。",
          paipan: {
            pillars: {
              year: { value: "己亥" },
              month: { value: "丁丑" },
              day: { value: "戊申" },
              hour: { value: "戊午" },
            },
          },
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      ),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await user.click(screen.getByRole("button", { name: "农历（阴历）" }));
    await user.click(screen.getByLabelText("闰月"));
    fireEvent.change(screen.getByLabelText("农历生日"), { target: { value: "2019-12-12" } });
    fireEvent.change(screen.getByLabelText("出生时间"), { target: { value: "23:30" } });
    await user.type(screen.getByLabelText("出生地"), "长春");
    await user.selectOptions(screen.getByLabelText("性别"), "female");

    expect(screen.queryByText("排盘口径")).not.toBeInTheDocument();
    expect(screen.queryByLabelText(/使用真太阳时/)).not.toBeInTheDocument();

    await testUnlock(user, "个人结构报告");
    await confirmGeneration(user, "生成个人结构报告");

    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toMatchObject({
      type: "bazi",
      birthDate: "2019-12-12",
      birthTime: "23:30",
      birthPlace: "长春",
      calendarType: "lunar",
      isLeapMonth: true,
      useTrueSolarTime: false,
      ziHourConvention: "zi-chu",
    });
    expect(await screen.findByText("报告已成")).toBeInTheDocument();
  });

  it("saves generated reports under My reports and opens a saved detail", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async () =>
      new Response(
        JSON.stringify({
          ok: true,
          type: "bazi",
          content: "# 个人结构报告\n先知己。\n\n## 用力方式\n先稳住节奏。",
          paipan: {
            pillars: {
              year: { value: "丁卯" },
              month: { value: "癸丑" },
              day: { value: "戊辰" },
              hour: { value: "戊午" },
            },
          },
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      ),
    );
    vi.stubGlobal("fetch", fetchMock);
    mockSignedInArchiveClient();
    render(<App />);

    await fillBirthProfile(user);
    await testUnlock(user, "个人结构报告");
    await confirmGeneration(user, "生成个人结构报告");
    await screen.findByText("报告已成");
    await user.click(await screen.findByRole("link", { name: "我的报告" }));

    expect(window.location.pathname).toBe("/reports");
    expect(screen.getByRole("heading", { name: "我的报告" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /个人结构报告/ })).toBeInTheDocument();
    expect(screen.getByText("1988/01/14 · 长春")).toBeInTheDocument();
    expect(screen.getByText("先知己。")).toBeInTheDocument();

    await user.click(screen.getByRole("button", { name: /个人结构报告/ }));

    expect(window.location.pathname).toBe("/report");
    expect(window.location.search).toMatch(/id=/);
    expect(screen.getByText("丁卯 · 癸丑 · 戊辰 · 戊午")).toBeInTheDocument();
    expect(screen.getByText("先稳住节奏。")).toBeInTheDocument();
    expect(screen.getByText("内容由人工智能生成，仅供参考")).toBeInTheDocument();
  });

  it("does not expose the last viewed report when a report URL contains an unknown id", () => {
    const savedReport = {
      id: "known-report",
      type: "bazi",
      content: "# 私密报告\n不应通过错误链接展示。",
      summary: "不应通过错误链接展示。",
    };
    window.sessionStorage.setItem("youshu:last-report", JSON.stringify(savedReport));
    window.localStorage.setItem("youshu:reports", JSON.stringify([savedReport]));
    window.history.pushState({}, "", "/report?id=unknown-report");

    render(<App />);

    expect(screen.getAllByText("还没有可查看的报告").length).toBeGreaterThanOrEqual(1);
    expect(screen.queryByText("不应通过错误链接展示。")).not.toBeInTheDocument();
  });

  it("lets a user delete an archived report and exposes the privacy request entry", async () => {
    const user = userEvent.setup();
    const report = {
      id: "delete-me",
      type: "bazi",
      title: "生成结果",
      content: "# 个人结构报告\n准备删除。",
      createdAt: "2026-07-28T08:00:00.000Z",
      summary: "准备删除。",
    };
    window.localStorage.setItem("youshu:reports", JSON.stringify([report]));
    vi.spyOn(window, "confirm").mockReturnValue(true);
    mockSignedInArchiveClient();

    render(<App />);
    await user.click(await screen.findByRole("link", { name: "我的报告" }));

    expect(screen.getByText("管理你的个人信息")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "提交个人信息请求" })).toHaveAttribute(
      "href",
      expect.stringContaining("mailto:qinyuneo@gmail.com"),
    );
    await user.click(screen.getByRole("button", { name: "删除报告：准备删除。" }));

    expect(screen.queryByText("准备删除。")).not.toBeInTheDocument();
    expect(JSON.parse(window.localStorage.getItem("youshu:reports"))).toEqual([]);
  });

  it("renders report markdown emphasis and lists without leaking raw markers", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async () =>
      new Response(
        JSON.stringify({
          ok: true,
          type: "bazi",
          content: "# 个人结构报告\n**先知己**，再谈选择。\n\n## 用力方式\n- 先稳住节奏\n1. 再看取舍",
          paipan: {
            pillars: {
              year: { value: "丁卯" },
              month: { value: "癸丑" },
              day: { value: "戊辰" },
              hour: { value: "戊午" },
            },
          },
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      ),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await testUnlock(user, "个人结构报告");
    await confirmGeneration(user, "生成个人结构报告");

    const reportCard = await screen.findByLabelText("生成结果");
    expect(reportCard).not.toHaveTextContent("**");
    expect(reportCard.querySelector(".report-body strong")).toHaveTextContent("先知己");
    expect(within(reportCard).getByText("先稳住节奏")).toBeInTheDocument();
    expect(within(reportCard).getByText("再看取舍")).toBeInTheDocument();
  });

  it("distinguishes report products in the archive and shows detail metadata", async () => {
    const reports = [
      {
        id: "annual-1",
        type: "annual",
        title: "生成结果",
        content: "# 年度节奏\n先看眼前。",
        createdAt: "2026-06-26T10:30:00.000Z",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        birthPlace: "长春",
        focus: "事业机会",
        summary: "先看眼前。",
      },
      {
        id: "question-1",
        type: "question",
        title: "生成结果",
        content: "# 一事分析\n此事宜稳。",
        createdAt: "2026-06-26T09:30:00.000Z",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        birthPlace: "长春",
        focus: "事业机会",
        question: "接下来半年适合换工作吗？",
        summary: "此事宜稳。",
      },
      {
        id: "bazi-1",
        type: "bazi",
        title: "生成结果",
        content: "# 个人结构报告\n先知己。",
        createdAt: "2026-06-26T08:30:00.000Z",
        birthDate: "1988-01-14",
        birthTime: "11:25",
        birthPlace: "长春",
        focus: "事业机会",
        summary: "先知己。",
      },
    ];
    window.localStorage.setItem("youshu:reports", JSON.stringify(reports));
    window.history.pushState({}, "", "/reports");
    const user = userEvent.setup();
    mockSignedInArchiveClient();

    render(<App />);

    expect(await screen.findByRole("heading", { name: "我的报告" })).toBeInTheDocument();
    expect(screen.getByText("3 份报告")).toBeInTheDocument();
    const archive = screen.getByRole("region", { name: "报告归档" });
    expect(within(archive).getByRole("button", { name: /年度节奏.*先看眼前/ })).toBeInTheDocument();
    expect(within(archive).getByRole("button", { name: /一事分析.*此事宜稳/ })).toBeInTheDocument();
    expect(within(archive).getByRole("button", { name: /个人结构报告.*先知己/ })).toBeInTheDocument();
    expect(screen.getByText("接下来半年适合换工作吗？")).toBeInTheDocument();

    await user.click(within(archive).getByRole("button", { name: /一事分析.*此事宜稳/ }));

    expect(window.location.pathname).toBe("/report");
    expect(screen.getAllByText("一事分析").length).toBeGreaterThanOrEqual(1);
    expect(screen.getByText(/生成于 2026\/06\/26 17:30/)).toBeInTheDocument();
    expect(screen.getByText(/出生信息 1988\/01\/14.*长春/)).toBeInTheDocument();
    expect(screen.queryByText(/关注方向.*事业机会/)).not.toBeInTheDocument();
    expect(screen.getByText("接下来半年适合换工作吗？")).toBeInTheDocument();
  });

  it("shows a lightweight sign-in panel when cloud reports are available but the user is signed out", async () => {
    const user = userEvent.setup();
    window.__youshuSupabaseClient = {
      auth: {
        getSession: vi.fn(async () => ({ data: { session: null }, error: null })),
        onAuthStateChange: vi.fn(() => ({ data: { subscription: { unsubscribe: vi.fn() } } })),
        signInWithOAuth: vi.fn(async () => ({ error: null })),
        signInWithOtp: vi.fn(async () => ({ error: null })),
        verifyOtp: vi.fn(async () => ({ error: null })),
      },
    };
    window.localStorage.setItem("youshu:reports", JSON.stringify([{
      id: "private-local-report",
      type: "bazi",
      summary: "不应在登录前展示",
      content: "# 私密报告",
    }]));
    render(<App />);

    await user.click(screen.getByRole("link", { name: "登录" }));

    expect(screen.getByRole("heading", { name: "登录后查看你的报告" })).toBeInTheDocument();
    expect(screen.getByText("登录后，报告会跟着你走。")).toBeInTheDocument();
    expect(screen.getByText("手机号登录")).toHaveClass("auth-method-heading");
    expect(screen.queryByRole("tab", { name: "邮箱登录" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Google 登录" })).not.toBeInTheDocument();
    expect(screen.queryByText("不应在登录前展示")).not.toBeInTheDocument();
    expect(screen.getByLabelText("短信验证码")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "登录并同步报告" })).toBeDisabled();

    await user.click(screen.getByRole("button", { name: "获取验证码" }));
    expect(screen.getByText("请输入正确的 11 位中国大陆手机号。")).toBeInTheDocument();
    expect(window.__youshuSupabaseClient.auth.signInWithOtp).not.toHaveBeenCalled();

    await user.type(screen.getByLabelText("中国大陆手机号"), "13812345678");
    await user.click(screen.getByRole("button", { name: "获取验证码" }));

    expect(window.__youshuSupabaseClient.auth.signInWithOtp).toHaveBeenCalledWith({
      phone: "+8613812345678",
    });
    await user.type(screen.getByLabelText("短信验证码"), "123456");
    expect(screen.getByRole("button", { name: "登录并同步报告" })).toBeEnabled();
    await user.click(screen.getByRole("button", { name: "登录并同步报告" }));
    expect(window.__youshuSupabaseClient.auth.verifyOtp).toHaveBeenCalledWith({
      phone: "+8613812345678",
      token: "123456",
      type: "sms",
    });

    expect(screen.queryByLabelText("邮箱验证码")).not.toBeInTheDocument();
  });

  it("saves generated reports to Supabase when a user is signed in", async () => {
    const user = userEvent.setup();
    const upsertMock = vi.fn(async () => ({ error: null }));
    window.__youshuSupabaseClient = {
      auth: {
        getSession: vi.fn(async () => ({
          data: {
            session: {
              access_token: "signed-in-access-token",
              user: { id: "user-1", email: "user@example.com" },
            },
          },
          error: null,
        })),
        onAuthStateChange: vi.fn(() => ({ data: { subscription: { unsubscribe: vi.fn() } } })),
      },
      from: vi.fn((table) => {
        if (table !== "reports") {
          throw new Error(`Unexpected table ${table}`);
        }
        return {
          select: () => ({
            eq: () => ({
              order: async () => ({ data: [], error: null }),
            }),
          }),
          upsert: upsertMock,
        };
      }),
    };
    const fetchMock = vi.fn(async () =>
      new Response(
        JSON.stringify({
          ok: true,
          type: "bazi",
          content: "# 个人结构报告\n先知己。",
          paipan: {
            pillars: {
              year: { value: "丁卯" },
              month: { value: "癸丑" },
              day: { value: "戊辰" },
              hour: { value: "戊午" },
            },
          },
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      ),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await testUnlock(user, "个人结构报告");
    await confirmGeneration(user, "生成个人结构报告");
    await screen.findByText("报告已成");

    expect(fetchMock.mock.calls[0][1].headers).toMatchObject({
      Authorization: "Bearer signed-in-access-token",
    });
    expect(upsertMock).toHaveBeenCalledWith([
      expect.objectContaining({
        user_id: "user-1",
        report_key: expect.any(String),
        report_type: "bazi",
        title: "生成结果",
        report_payload: expect.objectContaining({ content: "# 个人结构报告\n先知己。" }),
      }),
    ], { onConflict: "user_id,report_key" });
  });

  it("shows a localized support message when backend generation is not configured", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async () =>
      new Response(JSON.stringify({ error: "DeepSeek API key is not configured on the backend" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await testUnlock(user, "个人结构报告");
    await confirmGeneration(user, "生成个人结构报告");

    expect(await screen.findByRole("heading", { name: "有数报告", level: 1 })).toBeInTheDocument();
    expect(screen.getByText("服务端模型配置正在调整，请稍后再试或联系客服。")).toBeInTheDocument();
    expect(screen.queryByText(/DeepSeek API key is not configured/)).not.toBeInTheDocument();
  });

  it("keeps the homepage short after a generated report is available", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async () =>
      new Response(
        JSON.stringify({
          ok: true,
          type: "bazi",
          content: "# 个人结构报告\n先知己。",
          paipan: {
            pillars: {
              year: { value: "丁卯" },
              month: { value: "癸丑" },
              day: { value: "戊辰" },
              hour: { value: "戊午" },
            },
          },
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      ),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await testUnlock(user, "个人结构报告");
    await confirmGeneration(user, "生成个人结构报告");
    await screen.findByRole("heading", { name: "个人结构报告", level: 1 });
    await user.click(screen.getByRole("button", { name: "回到首页" }));

    expect(window.location.pathname).toBe("/");
    expect(screen.queryByRole("heading", { name: "报告已生成" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "打开报告页" })).not.toBeInTheDocument();
    expect(screen.queryByText("有数 · 结构关键词")).not.toBeInTheDocument();
    expect(screen.queryByText("先知己。")).not.toBeInTheDocument();
  });

  it("shows a transitional loading state while generating a report", async () => {
    const user = userEvent.setup();
    let resolveRequest;
    const fetchMock = vi.fn(
      () =>
        new Promise((resolve) => {
          resolveRequest = resolve;
        }),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await testUnlock(user, "个人结构报告");
    await confirmGeneration(user, "生成个人结构报告");

    expect(screen.getByText("正在把你的信息整理成报告")).toBeInTheDocument();
    expect(screen.getByText("先核对出生信息，再梳理结构与重点。完成后会自动进入报告页。")).toBeInTheDocument();
    expect(screen.getByText("确认历法、时间与出生地")).toBeInTheDocument();
    expect(screen.getByRole("region", { name: "结构校准" })).toHaveClass("is-generating");
    expect(
      within(screen.getByRole("article", { name: "正在把你的信息整理成报告" })).getByRole("list").children,
    ).toHaveLength(3);
    expect(screen.queryByText("后面的判断，留给深度报告慢慢展开")).not.toBeInTheDocument();

    resolveRequest(
      new Response(
        JSON.stringify({
          ok: true,
          type: "bazi",
          content: "# 个人结构报告\n先知己。",
          paipan: {
            pillars: {
              year: { value: "丁卯" },
              month: { value: "癸丑" },
              day: { value: "戊辰" },
              hour: { value: "戊午" },
            },
          },
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      ),
    );

    expect(await screen.findByText("报告已成")).toBeInTheDocument();
  });

  it("passes the selected language to report generation", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.fn(async (url) => {
      if (url === "/api/generate") {
        return new Response(
          JSON.stringify({
            ok: true,
            type: "annual",
            content: "# Annual Rhythm Report",
            paipan: {
              pillars: {
                year: { value: "丁卯" },
                month: { value: "癸丑" },
                day: { value: "戊辰" },
                hour: { value: "戊午" },
              },
            },
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        );
      }
      throw new Error(`Unexpected request: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);

    await user.selectOptions(screen.getByLabelText("语言 / Language"), "en");
    const readingRegion = screen.getByRole("region", { name: "Structure Check" });
    const modeSwitcher = within(readingRegion).getByLabelText("Choose a service");
    await user.click(within(modeSwitcher).getByRole("button", { name: /Annual Rhythm Report/ }));
    await user.click(within(readingRegion).getByRole("button", { name: "Test unlock current reading" }));
    await confirmGeneration(user, "Generate annual rhythm report", "Confirm and generate");

    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toMatchObject({
      type: "annual",
      language: "en",
    });
    expect(await screen.findByText("Report ready")).toBeInTheDocument();
    expect(window.location.pathname).toBe("/report");
  });
});
